import asyncio, json, websockets

async def connect(room_id, name):
    return await websockets.connect(f"ws://localhost:8765/ws/{room_id}?name={name}")

async def recv_all(ws, n=1, timeout=2):
    msgs = []
    for _ in range(n):
        try:
            raw = await asyncio.wait_for(ws.recv(), timeout=timeout)
            msgs.append(json.loads(raw))
        except asyncio.TimeoutError:
            break
    return msgs

async def main():
    ws1 = await connect(1, "Alice")
    await recv_all(ws1, 1)
    ws2 = await connect(1, "Bob")
    await recv_all(ws2, 1); await recv_all(ws1, 1)

    print("=== start_game ===")
    await ws1.send(json.dumps({"event": "start_game", "data": {}}))
    m1 = await recv_all(ws1, 5)
    m2 = await recv_all(ws2, 5)
    print("Alice recibio:", [x["event"] for x in m1])
    print("Bob recibio:", [x["event"] for x in m2])
    for x in m1:
        if x["event"] == "error":
            print("ERROR ALICE:", x["data"])

    print("=== chat publico ===")
    await ws1.send(json.dumps({"event": "send_chat", "data": {"channel": "general", "message": "hola a todos"}}))
    m1 = await recv_all(ws1, 2)
    m2 = await recv_all(ws2, 2)
    print("Alice recibio:", m1)
    print("Bob recibio:", m2)

    print("=== chat privado ===")
    gs = next((x for x in m1 + m2 if x["event"] == "game_started"), None)
    if not gs:
        # buscar en mensajes anteriores
        pass
    bob_id = None
    state_msgs = await recv_all(ws1, 0)
    # reconectar para obtener player list actual via game state
    await ws1.send(json.dumps({"event": "ping", "data": {}}))
    await recv_all(ws1, 1)

    await ws1.send(json.dumps({"event": "send_chat", "data": {"channel": "private", "message": "secreto", "recipient_id": 2}}))
    m1 = await recv_all(ws1, 2)
    m2 = await recv_all(ws2, 2)
    print("Alice recibio (privado):", m1)
    print("Bob recibio (privado):", m2)

    await ws1.close(); await ws2.close()

asyncio.run(main())
