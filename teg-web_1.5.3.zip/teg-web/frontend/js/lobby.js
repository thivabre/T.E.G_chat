/**
 * TEG Web - Lobby Logic
 * Handles room listing, creation, joining, and player name management
 */

import { $, $$, $$$, createElement, apiGet, apiPost, showToast, hideModal, showModal, escapeHtml, formatRelativeTime, storage, tabStorage, generateId, getPlayerColor, getContrastColor } from './utils.js?v=110';

// ============================================================================
// Lobby State
// ============================================================================

const lobbyState = {
  playerName: null,
  playerColor: null,
  rooms: [],
  refreshInterval: null,
  selectedRoom: null,
};

// ============================================================================
// DOM Elements
// ============================================================================

let elements = {};

function cacheElements() {
  console.log('[lobby.js] Caching elements...');
  console.log('[lobby.js] document.body:', !!document.body);
  console.log('[lobby.js] document.documentElement:', !!document.documentElement);
  
  // Try multiple ways to find elements
  const userInfo = document.getElementById('userInfo') || document.querySelector('[id="userInfo"]');
  console.log('[lobby.js] userInfo found:', !!userInfo);
  
  elements = {
    userInfo: userInfo,
    userAvatar: document.getElementById('userAvatar'),
    userName: document.getElementById('userName'),
    createRoomForm: document.getElementById('createRoomForm'),
    roomName: document.getElementById('roomName'),
    roomType: document.getElementById('roomType'),
    maxPlayers: document.getElementById('maxPlayers'),
    gameMode: document.getElementById('gameMode'),
    enableTimer: document.getElementById('enableTimer'),
    timerInput: document.getElementById('timerInput'),
    turnTime: document.getElementById('turnTime'),
    quickCreateBtn: document.getElementById('quickCreateBtn'),
    joinCodeBtn: document.getElementById('joinCodeBtn'),
    roomsList: document.getElementById('roomsList'),
    roomCount: document.getElementById('roomCount'),
    joinRoomModal: document.getElementById('joinRoomModal'),
    joinRoomForm: document.getElementById('joinRoomForm'),
    joinRoomName: document.getElementById('joinRoomName'),
    joinRoomCode: document.getElementById('joinRoomCode'),
    cancelJoinBtn: document.getElementById('cancelJoinBtn'),
    closeJoinModal: document.getElementById('closeJoinModal'),
    createRoomModal: document.getElementById('createRoomModal'),
    createRoomModalForm: document.getElementById('createRoomModalForm'),
    quickRoomName: document.getElementById('quickRoomName'),
    quickPlayerName: document.getElementById('quickPlayerName'),
    quickMaxPlayers: document.getElementById('quickMaxPlayers'),
    quickGameMode: document.getElementById('quickGameMode'),
    cancelCreateBtn: document.getElementById('cancelCreateBtn'),
    closeCreateModal: document.getElementById('closeCreateModal'),
    roomDetailModal: document.getElementById('roomDetailModal'),
    roomPlayersList: document.getElementById('roomPlayersList'),
    leaveRoomDetailBtn: document.getElementById('leaveRoomDetailBtn'),
    joinRoomDetailBtn: document.getElementById('joinRoomDetailBtn'),
    closeRoomDetailModal: document.getElementById('closeRoomDetailModal'),
  };
  console.log('[lobby.js] Elements cache complete. userInfo exists:', !!elements.userInfo, 'quickCreateBtn exists:', !!elements.quickCreateBtn);
}

// ============================================================================
// Initialization
// ============================================================================

export async function initLobby() {
  console.log('[lobby.js] initLobby() called');
  
  // Wait a bit to ensure DOM is fully loaded
  await new Promise(r => setTimeout(r, 100));
  
  cacheElements();
  console.log('[lobby.js] Elements cached');
  
  lobbyState.playerName = tabStorage.get('playerName');
  lobbyState.playerColor = tabStorage.get('playerColor') || getPlayerColor(Math.floor(Math.random() * 6));

  if (lobbyState.playerName) {
    showUserInfo();
  } else {
    showNamePrompt();
  }

  setupEventListeners();
  await loadPublicRooms();
  startAutoRefresh();
}

function showNamePrompt() {
  const name = prompt('Bienvenido a TEG Web!\n\nIngresa tu nombre para jugar:');
  if (name && name.trim()) {
    lobbyState.playerName = name.trim();
    tabStorage.set('playerName', lobbyState.playerName);
    tabStorage.set('playerColor', lobbyState.playerColor);
    showUserInfo();
  } else {
    showNamePrompt();
  }
}

function showUserInfo() {
  if (!elements.userInfo || !elements.userAvatar) {
    console.error('[lobby.js] userInfo or userAvatar not found');
    return;
  }
  elements.userInfo.style.display = 'flex';
  elements.userName.textContent = lobbyState.playerName;
  elements.userAvatar.textContent = lobbyState.playerName.charAt(0).toUpperCase();
  elements.userAvatar.style.background = 'linear-gradient(135deg, ' + lobbyState.playerColor + ', ' + adjustColor(lobbyState.playerColor, -20) + ')';
  elements.userAvatar.style.color = getContrastColor(lobbyState.playerColor);
}

function adjustColor(color, amount) {
  const hex = color.replace('#', '');
  const r = Math.max(0, Math.min(255, parseInt(hex.slice(0, 2), 16) + amount));
  const g = Math.max(0, Math.min(255, parseInt(hex.slice(2, 4), 16) + amount));
  const b = Math.max(0, Math.min(255, parseInt(hex.slice(4, 6), 16) + amount));
  return '#' + r.toString(16).padStart(2, '0') + g.toString(16).padStart(2, '0') + b.toString(16).padStart(2, '0');
}

// ============================================================================
// Room Management
// ============================================================================

async function loadPublicRooms() {
  try {
    const rooms = await apiGet('/rooms/public');
    lobbyState.rooms = rooms || [];
    renderRoomsList();
  } catch (error) {
    console.error('Error loading rooms:', error);
    showToast('Error cargando partidas', 'error');
  }
}

function renderRoomsList() {
  const container = elements.roomsList;

  if (lobbyState.rooms.length === 0) {
    container.innerHTML = '<div class="empty-rooms"><p>No hay partidas publicas disponibles</p></div>';
    elements.roomCount.textContent = '0 disponibles';
    return;
  }

  container.innerHTML = '';
  lobbyState.rooms.forEach(room => {
    const item = createRoomItem(room);
    container.appendChild(item);
  });

  elements.roomCount.textContent = lobbyState.rooms.length + ' disponible' + (lobbyState.rooms.length !== 1 ? 's' : '');
}

function createRoomItem(room) {
  const item = createElement('div', {
    class: 'room-item',
  });

  item.addEventListener('click', () => openRoomDetail(room));

  const playerCount = room.players ? room.players.length : 0;
  const maxPlayers = room.max_players || 6;
  const gameMode = room.game_mode === 'conquista' ? 'Conquista' : 'Objetivos';
  const timer = room.turn_time_limit ? ' - ' + room.turn_time_limit + 's' : '';
  const roomType = room.type === 'privada' ? 'Privada' : 'Publica';
  const badgeClass = room.type === 'privada' ? 'badge-warning' : 'badge-primary';

  item.innerHTML = '<div class="room-item-header"><span class="room-name">' + escapeHtml(room.name) + '</span><span class="room-badge ' + badgeClass + '">' + roomType + '</span></div><div class="room-info"><div class="room-players"><span>' + playerCount + '/' + maxPlayers + '</span></div><div class="room-host"><span>' + escapeHtml(room.host_name || 'Desconocido') + '</span></div></div><div class="room-mode">' + gameMode + timer + '</div>';

  return item;
}

function openRoomDetail(room) {
  lobbyState.selectedRoom = room;
  elements.roomDetailModal.querySelector('#roomDetailTitle').textContent = room.name;

  elements.roomPlayersList.innerHTML = '';
  const players = room.players || [];
  const playerCount = players.length;
  const maxPlayers = room.max_players || 6;
  
  players.forEach(player => {
    const playerEl = createElement('div', { class: 'player-item' });
    const avatarColor = player.color || getPlayerColor(Math.abs(hashCode(player.name)) % 6);
    const status = player.eliminated ? 'Eliminado' : 'En juego';
    playerEl.innerHTML = '<div class="player-avatar" style="background: ' + avatarColor + '">' + player.name.charAt(0).toUpperCase() + '</div><div class="player-details"><div class="player-name">' + escapeHtml(player.name) + (player.is_host ? ' HOST' : '') + '</div></div><div class="player-status"><span>' + status + '</span></div>';
    elements.roomPlayersList.appendChild(playerEl);
  });

  const canJoin = room.status === 'waiting' && playerCount < maxPlayers;
  elements.joinRoomDetailBtn.disabled = !canJoin;
  elements.joinRoomDetailBtn.textContent = canJoin ? 'Unirse' : 'Completa / En juego';

  showModal('roomDetailModal');
}

function hashCode(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

// ============================================================================
// Create Room
// ============================================================================

async function createRoom(data) {
  if (!data.name) {
    showToast('Ingresa un nombre para la partida', 'error');
    return;
  }

  if (!lobbyState.playerName) {
    showToast('Primero ingresa tu nombre', 'error');
    return;
  }

  try {
    const room = await apiPost('/rooms', {
      name: data.name,
      type: data.type,
      max_players: data.max_players,
      game_mode: data.game_mode,
      turn_time_limit: data.turn_time_limit,
      host_name: lobbyState.playerName,
    });

    showToast('Partida creada', 'success');
    hideModal('createRoomModal');
    joinRoom(room.id, room.code);
  } catch (error) {
    showToast('Error creando partida: ' + error.message, 'error');
  }
}

// ============================================================================
// Join Room
// ============================================================================

async function joinRoomByCode(code) {
  try {
    const room = await apiPost('/rooms/join-by-code', { code: code, player_name: lobbyState.playerName });
    showToast('Unido a la partida', 'success');
    hideModal('joinRoomModal');
    joinRoom(room.id, room.code);
  } catch (error) {
    showToast('Error uniendo a la partida: ' + error.message, 'error');
  }
}

function joinRoom(roomId, code) {
  const params = new URLSearchParams({
    room: roomId,
    name: lobbyState.playerName,
  });
  window.location.href = '/game.html?' + params.toString();
}

// ============================================================================
// Auto Refresh
// ============================================================================

function startAutoRefresh() {
  lobbyState.refreshInterval = setInterval(loadPublicRooms, 10000);
}

function stopAutoRefresh() {
  if (lobbyState.refreshInterval) {
    clearInterval(lobbyState.refreshInterval);
    lobbyState.refreshInterval = null;
  }
}

// ============================================================================
// Event Listeners
// ============================================================================

function setupEventListeners() {
  console.log('[lobby.js] Setting up event listeners');
  
  if (elements.createRoomForm) {
    elements.createRoomForm.addEventListener('submit', function(e) {
      e.preventDefault();
      console.log('[lobby.js] Create room form submitted');
      createRoom({
        name: elements.roomName.value.trim(),
        type: elements.roomType.value,
        max_players: parseInt(elements.maxPlayers.value),
        game_mode: elements.gameMode.value,
        turn_time_limit: elements.enableTimer.checked ? parseInt(elements.turnTime.value) : 0,
      });
    });
  }

  if (elements.createRoomModalForm) {
    elements.createRoomModalForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const name = elements.quickRoomName.value.trim() || 'Partida rapida';
      const playerName = elements.quickPlayerName.value.trim();

      if (!playerName) {
        showToast('Ingresa tu nombre', 'error');
        return;
      }

      lobbyState.playerName = playerName;
      tabStorage.set('playerName', playerName);
      showUserInfo();

      createRoom({
        name: name,
        type: 'publica',
        max_players: parseInt(elements.quickMaxPlayers.value),
        game_mode: elements.quickGameMode.value,
        turn_time_limit: 0,
      });
    });
  }

  if (elements.joinRoomForm) {
    elements.joinRoomForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const name = elements.joinRoomName.value.trim();
      const code = elements.joinRoomCode.value.trim().toUpperCase();

      if (!name) {
        showToast('Ingresa tu nombre', 'error');
        return;
      }

      lobbyState.playerName = name;
      tabStorage.set('playerName', name);
      showUserInfo();

      joinRoomByCode(code);
    });
  }

  if (elements.joinRoomDetailBtn) {
    elements.joinRoomDetailBtn.addEventListener('click', function() {
      if (!lobbyState.selectedRoom) return;

      if (!lobbyState.playerName) {
        const name = prompt('Ingresa tu nombre:');
        if (!name || !name.trim()) return;
        lobbyState.playerName = name.trim();
        tabStorage.set('playerName', lobbyState.playerName);
        showUserInfo();
      }

      joinRoom(lobbyState.selectedRoom.id, lobbyState.selectedRoom.code);
      hideModal('roomDetailModal');
    });
  }

  if (elements.enableTimer) {
    elements.enableTimer.addEventListener('change', function() {
      elements.timerInput.style.display = elements.enableTimer.checked ? 'flex' : 'none';
    });
  }

  if (elements.quickCreateBtn) {
    elements.quickCreateBtn.addEventListener('click', function() {
      console.log('[lobby.js] Quick create button clicked');
      showModal('createRoomModal');
    });
  }

  if (elements.joinCodeBtn) {
    elements.joinCodeBtn.addEventListener('click', function() {
      console.log('[lobby.js] Join code button clicked');
      showModal('joinRoomModal');
    });
  }

  if (elements.cancelJoinBtn) {
    elements.cancelJoinBtn.addEventListener('click', function() {
      hideModal('joinRoomModal');
    });
  }

  if (elements.closeJoinModal) {
    elements.closeJoinModal.addEventListener('click', function() {
      hideModal('joinRoomModal');
    });
  }

  if (elements.cancelCreateBtn) {
    elements.cancelCreateBtn.addEventListener('click', function() {
      hideModal('createRoomModal');
    });
  }

  if (elements.closeCreateModal) {
    elements.closeCreateModal.addEventListener('click', function() {
      hideModal('createRoomModal');
    });
  }

  if (elements.leaveRoomDetailBtn) {
    elements.leaveRoomDetailBtn.addEventListener('click', function() {
      hideModal('roomDetailModal');
    });
  }

  if (elements.closeRoomDetailModal) {
    elements.closeRoomDetailModal.addEventListener('click', function() {
      hideModal('roomDetailModal');
    });
  }

  setupModalClose('joinRoomModal', 'closeJoinModal');
  setupModalClose('createRoomModal', 'closeCreateModal');
  setupModalClose('roomDetailModal', 'closeRoomDetailModal');

  window.addEventListener('beforeunload', stopAutoRefresh);
}

function setupModalClose(modalId, closeBtnId) {
  const modal = $(modalId);
  const closeBtn = $(closeBtnId);

  if (modal) {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) hideModal(modalId);
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', function() {
      hideModal(modalId);
    });
  }

  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      const m = $(modalId);
      if (m && !m.classList.contains('hidden')) {
        hideModal(modalId);
      }
    }
  });
}
