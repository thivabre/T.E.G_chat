/**
 * TEG Web - Main Entry Point
 * Initializes the application based on current page
 */

import { storage } from './utils.js?v=110';

// ============================================================================
// Page Detection & Initialization
// ============================================================================

console.log('[main.js] Script loaded');

// Initialize immediately if DOM is already ready, otherwise wait
function initializeApp() {
  console.log('[main.js] Initializing app');
  const path = window.location.pathname;
  console.log('[main.js] Current path:', path);

  if (path === '/' || path === '/index.html' || path === '' || path.endsWith('/lobby')) {
    console.log('[main.js] Initializing Lobby');
    // Lobby page
    import('./lobby.js?v=110').then(({ initLobby }) => {
      console.log('[main.js] Calling initLobby()');
      initLobby();
      console.log('[main.js] initLobby() completed');
    }).catch(err => {
      console.error('[main.js] Error importing lobby.js:', err);
    });
  } else if (path === '/game.html' || path.endsWith('/game')) {
    console.log('[main.js] Initializing Game');
    // Game page
    import('./game.js?v=110').then(({ initGame }) => {
      console.log('[main.js] Calling initGame()');
      initGame();
      console.log('[main.js] initGame() completed');
    }).catch(err => {
      console.error('[main.js] Error importing game.js:', err);
    });
  }
}

// Check if DOM is ready
if (document.readyState === 'loading') {
  console.log('[main.js] DOM is still loading, waiting for DOMContentLoaded');
  document.addEventListener('DOMContentLoaded', initializeApp);
} else {
  console.log('[main.js] DOM is already ready');
  initializeApp();
}

// ============================================================================
// Global Error Handling
// ============================================================================

window.addEventListener('error', (event) => {
  console.error('Global error:', event.error);
});

window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled rejection:', event.reason);
});

// ============================================================================
// Service Worker Registration (for offline support)
// ============================================================================

// Service Worker disabled - using direct network fetch
// if ('serviceWorker' in navigator) {
//   window.addEventListener('load', () => {
//     navigator.serviceWorker.unregister();
//   });
// }

// ============================================================================
// Export for testing
// ============================================================================

export { storage };