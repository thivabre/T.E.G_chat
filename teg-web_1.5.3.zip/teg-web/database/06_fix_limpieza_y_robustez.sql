-- ============================================================================
-- TEG - MIGRACIÓN: limpieza automática de partidas + huecos de integridad
-- ============================================================================
-- Qué arregla:
--
--   1) HOY NADIE BORRA NUNCA UNA PARTIDA. El endpoint DELETE /api/rooms/{id}
--      existe pero jamás se llama desde el frontend, y ninguna FK tiene
--      ON DELETE CASCADE (por eso ese endpoint tiene que borrar 8 tablas a
--      mano). Resultado: cada partida que se juega (o que se crea y nunca
--      arranca) queda para siempre en la base.
--
--   2) Redefine las FKs con ON DELETE CASCADE para que borrar una Partida
--      (o un Usuario) arrastre automáticamente todo lo que depende de esa
--      fila, sin errores de foreign key.
--
--   3) Estadisticas se DESACOPLA de esas cascadas a propósito: es la única
--      tabla que sobrevive como historial aunque la partida se borre (así
--      el día de mañana se puede armar un ranking/historial de partidas
--      jugadas sin que la limpieza automática lo destruya).
--
--   4) Agrega un procedure que, cuando el último Usuario de una partida se
--      va, borra la Partida entera (y todo lo que cuelga de ella, excepto
--      Estadisticas). Nota importante: esto NO se hace con un simple
--      "AFTER DELETE ON Usuarios" que borre Partida directo, porque MySQL
--      prohíbe que un trigger disparado por una cascada de
--      DELETE FROM Partida vuelva a tocar la propia tabla Partida ("Cannot
--      update table X in stored function/trigger because it is already
--      used by statement which invoked this..."). Por eso la limpieza se
--      hace desde un procedure aparte, llamado por la aplicación después
--      de cada baja de jugador — no desde dentro del trigger de cascada.
--
--   5) Barrido de seguridad (sp_limpiar_partidas_abandonadas): por si algún
--      día un crash del servidor deja una sala fantasma sin que nadie
--      dispare la limpieza normal, este procedure se puede llamar
--      periódicamente y borra: salas 'esperando' abandonadas hace más de
--      24hs, partidas 'finalizada' de hace más de 7 días, y cualquier
--      Partida que haya quedado sin ningún Usuario.
--
--   6) Objetivos_Partida ya tenía UNIQUE(id_partida, id_usuario) desde el
--      esquema original (uq_objetivo_partida_usuario) — no hacía falta
--      agregar nada ahí, así que este script no la toca.
--
--   7) Trigger AFTER UPDATE en Usuarios: si al marcar a alguien 'eliminado'
--      queda un solo jugador activo en una partida 'en_curso', la cierra y
--      define ganador/perdedor a nivel de base — como red de seguridad
--      además de la lógica que ya existe en Python (unified_server.py),
--      por si algún día se toca Territorios_Partida por otra vía.
--
-- Esta migración es IDEMPOTENTE: se puede correr más de una vez, o sobre
-- una base que ya tenga alguno de estos cambios aplicados a mano, sin que
-- falle — cada paso chequea el estado actual antes de tocar nada.
--
-- Cómo correrlo:
--   mysql -h 127.0.0.1 -P 3307 -u teg_user -p teg_web < database/06_fix_limpieza_y_robustez.sql
-- ============================================================================

-- 1) FKs con ON DELETE CASCADE ---------------------------------------------
-- NOTA: cada FK se maneja como dos sentencias SUELTAS y directas (un
-- DROP condicional por dynamic SQL -- liviano, solo metadata -- seguido
-- de un ADD CONSTRAINT plano). A propósito NO se usa un procedure
-- genérico con parámetros para armar el ALTER TABLE ADD CONSTRAINT: en
-- algunos MariaDB de XAMPP, ese patrón (PREPARE/EXECUTE de un ALTER TABLE
-- ADD CONSTRAINT FOREIGN KEY dentro de un procedure) puede tirar abajo el
-- proceso del servidor. Con sentencias directas, si algo llegara a fallar,
-- el error queda acotado a una sola línea fácil de identificar.

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Usuarios'
      AND CONSTRAINT_NAME = 'fk_usuarios_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Usuarios` DROP FOREIGN KEY `fk_usuarios_partida`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Usuarios` ADD CONSTRAINT `fk_usuarios_partida` FOREIGN KEY (`id_partida`)
    REFERENCES `Partida`(`id_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Territorios_Partida'
      AND CONSTRAINT_NAME = 'fk_territorios_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Territorios_Partida` DROP FOREIGN KEY `fk_territorios_partida`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Territorios_Partida` ADD CONSTRAINT `fk_territorios_partida` FOREIGN KEY (`id_partida`)
    REFERENCES `Partida`(`id_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Territorios_Partida'
      AND CONSTRAINT_NAME = 'fk_territorios_usuario' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Territorios_Partida` DROP FOREIGN KEY `fk_territorios_usuario`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Territorios_Partida` ADD CONSTRAINT `fk_territorios_usuario` FOREIGN KEY (`id_usuario`)
    REFERENCES `Usuarios`(`id_usuario`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Cartas_Partida'
      AND CONSTRAINT_NAME = 'fk_cartaspartida_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Cartas_Partida` DROP FOREIGN KEY `fk_cartaspartida_partida`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Cartas_Partida` ADD CONSTRAINT `fk_cartaspartida_partida` FOREIGN KEY (`id_partida`)
    REFERENCES `Partida`(`id_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Cartas_Partida'
      AND CONSTRAINT_NAME = 'fk_cartaspartida_usuario' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Cartas_Partida` DROP FOREIGN KEY `fk_cartaspartida_usuario`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Cartas_Partida` ADD CONSTRAINT `fk_cartaspartida_usuario` FOREIGN KEY (`id_usuario`)
    REFERENCES `Usuarios`(`id_usuario`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Intercambios'
      AND CONSTRAINT_NAME = 'fk_intercambios_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Intercambios` DROP FOREIGN KEY `fk_intercambios_partida`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Intercambios` ADD CONSTRAINT `fk_intercambios_partida` FOREIGN KEY (`id_partida`)
    REFERENCES `Partida`(`id_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Intercambios'
      AND CONSTRAINT_NAME = 'fk_intercambios_usuario' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Intercambios` DROP FOREIGN KEY `fk_intercambios_usuario`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Intercambios` ADD CONSTRAINT `fk_intercambios_usuario` FOREIGN KEY (`id_usuario`)
    REFERENCES `Usuarios`(`id_usuario`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Intercambios'
      AND CONSTRAINT_NAME = 'fk_intercambios_carta1' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Intercambios` DROP FOREIGN KEY `fk_intercambios_carta1`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Intercambios` ADD CONSTRAINT `fk_intercambios_carta1` FOREIGN KEY (`id_carta_partida1`)
    REFERENCES `Cartas_Partida`(`id_carta_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Intercambios'
      AND CONSTRAINT_NAME = 'fk_intercambios_carta2' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Intercambios` DROP FOREIGN KEY `fk_intercambios_carta2`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Intercambios` ADD CONSTRAINT `fk_intercambios_carta2` FOREIGN KEY (`id_carta_partida2`)
    REFERENCES `Cartas_Partida`(`id_carta_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Intercambios'
      AND CONSTRAINT_NAME = 'fk_intercambios_carta3' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Intercambios` DROP FOREIGN KEY `fk_intercambios_carta3`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Intercambios` ADD CONSTRAINT `fk_intercambios_carta3` FOREIGN KEY (`id_carta_partida3`)
    REFERENCES `Cartas_Partida`(`id_carta_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Objetivos_Partida'
      AND CONSTRAINT_NAME = 'fk_objetivospartida_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Objetivos_Partida` DROP FOREIGN KEY `fk_objetivospartida_partida`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Objetivos_Partida` ADD CONSTRAINT `fk_objetivospartida_partida` FOREIGN KEY (`id_partida`)
    REFERENCES `Partida`(`id_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Objetivos_Partida'
      AND CONSTRAINT_NAME = 'fk_objetivospartida_usuario' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Objetivos_Partida` DROP FOREIGN KEY `fk_objetivospartida_usuario`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Objetivos_Partida` ADD CONSTRAINT `fk_objetivospartida_usuario` FOREIGN KEY (`id_usuario`)
    REFERENCES `Usuarios`(`id_usuario`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Turnos'
      AND CONSTRAINT_NAME = 'fk_turnos_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Turnos` DROP FOREIGN KEY `fk_turnos_partida`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Turnos` ADD CONSTRAINT `fk_turnos_partida` FOREIGN KEY (`id_partida`)
    REFERENCES `Partida`(`id_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Turnos'
      AND CONSTRAINT_NAME = 'fk_turnos_usuario' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Turnos` DROP FOREIGN KEY `fk_turnos_usuario`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Turnos` ADD CONSTRAINT `fk_turnos_usuario` FOREIGN KEY (`id_usuario`)
    REFERENCES `Usuarios`(`id_usuario`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Chat'
      AND CONSTRAINT_NAME = 'fk_chat_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Chat` DROP FOREIGN KEY `fk_chat_partida`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Chat` ADD CONSTRAINT `fk_chat_partida` FOREIGN KEY (`id_partida`)
    REFERENCES `Partida`(`id_partida`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Chat'
      AND CONSTRAINT_NAME = 'fk_chat_emisor' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Chat` DROP FOREIGN KEY `fk_chat_emisor`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Chat` ADD CONSTRAINT `fk_chat_emisor` FOREIGN KEY (`id_emisor`)
    REFERENCES `Usuarios`(`id_usuario`) ON DELETE CASCADE;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Chat'
      AND CONSTRAINT_NAME = 'fk_chat_receptor' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE `Chat` DROP FOREIGN KEY `fk_chat_receptor`', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE `Chat` ADD CONSTRAINT `fk_chat_receptor` FOREIGN KEY (`id_receptor`)
    REFERENCES `Usuarios`(`id_usuario`) ON DELETE CASCADE;

-- fk_objetivospartida_objetivo (-> Objetivos) queda sin cascada a propósito:
-- Objetivos es un catálogo fijo, nunca se borra por borrar una partida.

-- Estadisticas: se DESACOPLA a propósito (ver punto 3 de arriba). Sin FK,
-- id_usuario/id_partida quedan como referencia histórica aunque la partida
-- ya no exista. Se agregan índices para no perder performance de consulta
-- al no tener más las FKs. Todo con chequeo de existencia para poder
-- correr este script más de una vez sin que falle.
SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Estadisticas'
      AND CONSTRAINT_NAME = 'fk_estadisticas_usuario' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE Estadisticas DROP FOREIGN KEY fk_estadisticas_usuario', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @v := (
    SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Estadisticas'
      AND CONSTRAINT_NAME = 'fk_estadisticas_partida' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql := IF(@v > 0, 'ALTER TABLE Estadisticas DROP FOREIGN KEY fk_estadisticas_partida', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @v := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Estadisticas' AND INDEX_NAME = 'idx_estadisticas_usuario'
);
SET @sql := IF(@v = 0, 'ALTER TABLE Estadisticas ADD INDEX idx_estadisticas_usuario (id_usuario)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @v := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Estadisticas' AND INDEX_NAME = 'idx_estadisticas_partida'
);
SET @sql := IF(@v = 0, 'ALTER TABLE Estadisticas ADD INDEX idx_estadisticas_partida (id_partida)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2) Procedure: borra la partida completa si ya no le queda ningún Usuario -
DROP PROCEDURE IF EXISTS sp_finalizar_partida_si_vacia;
DELIMITER $$
CREATE PROCEDURE sp_finalizar_partida_si_vacia (
    IN p_id_partida INT
)
BEGIN
    DECLARE v_restantes INT;

    SELECT COUNT(*) INTO v_restantes FROM Usuarios WHERE id_partida = p_id_partida;

    IF v_restantes = 0 THEN
        -- Gracias al ON DELETE CASCADE de arriba, este único DELETE se
        -- lleva puesto Territorios_Partida, Cartas_Partida, Intercambios,
        -- Objetivos_Partida, Turnos y Chat de esta partida. Estadisticas
        -- queda intacta (se desacopló a propósito).
        DELETE FROM Partida WHERE id_partida = p_id_partida;
    END IF;
END$$
DELIMITER ;

-- 3) Barrido de seguridad para salas fantasma -------------------------------
DROP PROCEDURE IF EXISTS sp_limpiar_partidas_abandonadas;
DELIMITER $$
CREATE PROCEDURE sp_limpiar_partidas_abandonadas ()
BEGIN
    -- a) Salas de espera creadas hace más de 24hs que nunca arrancaron
    --    (típicamente porque todos se fueron sin que la limpieza normal
    --    llegara a correr, ej. si el proceso del servidor se reinició).
    DELETE FROM Partida
    WHERE estado = 'esperando' AND fecha_creacion < (NOW() - INTERVAL 24 HOUR);

    -- b) Partidas terminadas hace más de 7 días: ya cumplieron su función,
    --    Estadisticas conserva el historial igual (no tiene FK a Partida).
    DELETE FROM Partida
    WHERE estado = 'finalizada' AND fecha_creacion < (NOW() - INTERVAL 7 DAY);

    -- c) Cualquier Partida que haya quedado sin ningún Usuario (por
    --    cualquier motivo) se borra directamente, sin importar su edad.
    DELETE p FROM Partida p
    LEFT JOIN Usuarios u ON u.id_partida = p.id_partida
    WHERE u.id_usuario IS NULL;
END$$
DELIMITER ;

-- 4) Robustez extra: cerrar la partida a nivel de base cuando queda un
--    solo jugador activo (además de la lógica ya existente en Python) ------
DROP TRIGGER IF EXISTS trg_usuarios_after_update_finaliza;
DELIMITER $$
CREATE TRIGGER trg_usuarios_after_update_finaliza
AFTER UPDATE ON Usuarios
FOR EACH ROW
BEGIN
    DECLARE v_estado_partida VARCHAR(20);
    DECLARE v_activos INT;
    DECLARE v_ganador INT;

    IF NEW.estado = 'eliminado' AND OLD.estado <> 'eliminado' THEN
        SELECT estado INTO v_estado_partida FROM Partida WHERE id_partida = NEW.id_partida;

        IF v_estado_partida = 'en_curso' THEN
            SELECT COUNT(*) INTO v_activos
            FROM Usuarios WHERE id_partida = NEW.id_partida AND estado = 'activo';

            IF v_activos = 1 THEN
                SELECT id_usuario INTO v_ganador
                FROM Usuarios WHERE id_partida = NEW.id_partida AND estado = 'activo' LIMIT 1;

                UPDATE Partida SET estado = 'finalizada'
                WHERE id_partida = NEW.id_partida AND estado <> 'finalizada';

                UPDATE Estadisticas SET resultado = 'ganador'
                WHERE id_partida = NEW.id_partida AND id_usuario = v_ganador;

                UPDATE Estadisticas SET resultado = 'perdedor'
                WHERE id_partida = NEW.id_partida AND id_usuario <> v_ganador AND resultado = 'en_curso';
            END IF;
        END IF;
    END IF;
END$$
DELIMITER ;

SELECT 'Migración de limpieza y robustez aplicada correctamente' AS resultado;
