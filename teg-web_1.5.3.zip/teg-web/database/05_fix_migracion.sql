-- ============================================================================
-- TEG - MIGRACIÓN DE ARREGLOS (correr una sola vez sobre la base ya existente)
-- ============================================================================
-- Qué arregla:
--   1) Persistir modo de juego (objetivos/conquista) y límite de tiempo por
--      turno, que existían en el formulario del frontend pero nunca se
--      guardaban en la base (por eso nunca se veía el timer, y el modo
--      "conquista" no se distinguía de "objetivos").
--   2) Reparto de países 100% aleatorio al iniciar la partida (antes era
--      rotativo por id_pais, siempre el mismo orden).
--   3) Catálogo de objetivos variado (antes había UNA sola fila en la tabla
--      Objetivos, por eso "todos" sacaban siempre "conquistar 30 países").
--      Ahora hay 9 objetivos de ocupación con distintos umbrales, y en modo
--      "conquista" no se asigna objetivo individual (gana el que sobrevive).
--   4) El trigger de victoria por objetivo usaba 30 hardcodeado sin mirar el
--      objetivo real asignado; ahora lee el umbral de cada objetivo.
--
-- Cómo correrlo (PowerShell, con el MySQL en el puerto 3307 del proyecto):
--   mysql -h 127.0.0.1 -P 3307 -u teg_user -p teg_web < database/05_fix_migracion.sql
-- ============================================================================

-- 1) Nuevas columnas en Partida --------------------------------------------
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Partida' AND COLUMN_NAME = 'game_mode'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE Partida ADD COLUMN game_mode ENUM(''objetivos'',''conquista'') NOT NULL DEFAULT ''conquista''',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Partida' AND COLUMN_NAME = 'turn_time_limit'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE Partida ADD COLUMN turn_time_limit INT NOT NULL DEFAULT 0',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2) Nueva columna en Objetivos: cuántos países hacen falta para cumplirlo -
SET @col_exists := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Objetivos' AND COLUMN_NAME = 'paises_requeridos'
);
SET @sql := IF(@col_exists = 0,
    'ALTER TABLE Objetivos ADD COLUMN paises_requeridos INT NULL',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- El objetivo original (30 países) pasa a tener su umbral explícito
UPDATE Objetivos SET paises_requeridos = 30
WHERE tipo = 'ocupacion' AND paises_requeridos IS NULL
  AND descripcion LIKE '%30%';

-- 3) Catálogo de objetivos variado (solo inserta los que falten) -----------
INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 18 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 18 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 20 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 20 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 22 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 22 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 24 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 24 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 26 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 26 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 28 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 28 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 32 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 32 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 34 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 34 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

INSERT INTO Objetivos (descripcion, tipo, paises_requeridos)
SELECT * FROM (SELECT 'Conquistar al menos 16 países, sin importar el continente' AS descripcion, 'ocupacion' AS tipo, 16 AS paises_requeridos) t
WHERE NOT EXISTS (SELECT 1 FROM Objetivos WHERE descripcion = t.descripcion);

-- 4) sp_crear_partida: ahora también recibe y guarda modo y límite de tiempo
DROP PROCEDURE IF EXISTS sp_crear_partida;
DELIMITER $$
CREATE PROCEDURE sp_crear_partida (
    IN p_nombre_partida VARCHAR(100),
    IN p_tipo ENUM('publica','privada'),
    IN p_codigo_acceso VARCHAR(10),
    IN p_max_jugadores INT,
    IN p_game_mode ENUM('objetivos','conquista'),
    IN p_turn_time_limit INT
)
BEGIN
    INSERT INTO Partida (nombre_partida, tipo, codigo_acceso, max_jugadores, game_mode, turn_time_limit)
    VALUES (p_nombre_partida, p_tipo, p_codigo_acceso, p_max_jugadores,
            COALESCE(p_game_mode, 'conquista'), COALESCE(p_turn_time_limit, 0));

    SELECT LAST_INSERT_ID() AS id_partida;
END$$
DELIMITER ;

-- 5) sp_iniciar_partida: reparto de países ALEATORIO + objetivos según modo
DROP PROCEDURE IF EXISTS sp_iniciar_partida;
DELIMITER $$
CREATE PROCEDURE sp_iniciar_partida (
    IN p_id_partida INT
)
BEGIN
    DECLARE v_num_jugadores INT;
    DECLARE v_num_objetivos INT;
    DECLARE v_game_mode VARCHAR(20);

    SELECT game_mode INTO v_game_mode FROM Partida WHERE id_partida = p_id_partida;

    SELECT COUNT(*) INTO v_num_jugadores
    FROM Usuarios WHERE id_partida = p_id_partida AND estado = 'activo';

    -- Reparto ALEATORIO y rotativo de todos los países entre los jugadores
    -- activos (antes se ordenaba por id_pais, siempre daba el mismo reparto
    -- en cada partida — ahora se baraja con ORDER BY RAND() en cada llamada).
    INSERT INTO Territorios_Partida (id_partida, id_pais, id_usuario, cantidad_ejercitos)
    SELECT p_id_partida, pa.id_pais, u.id_usuario, 1
    FROM (
        SELECT id_pais, ROW_NUMBER() OVER (ORDER BY RAND()) AS rn
        FROM Paises
    ) pa
    JOIN (
        SELECT id_usuario, ROW_NUMBER() OVER (ORDER BY RAND()) AS rn
        FROM Usuarios
        WHERE id_partida = p_id_partida AND estado = 'activo'
    ) u ON u.rn = ((pa.rn - 1) % v_num_jugadores) + 1;

    -- Pone todas las cartas de la partida disponibles en el mazo
    INSERT INTO Cartas_Partida (id_partida, id_carta, estado)
    SELECT p_id_partida, id_carta, 'mazo' FROM Cartas;

    -- Objetivos: en modo "conquista" (mundial) no se asigna objetivo
    -- individual — se gana siendo el último jugador activo. En modo
    -- "objetivos" cada jugador recibe uno DISTINTO (se barajan jugadores
    -- y objetivos por separado y se emparejan 1 a 1, así nadie repite
    -- mientras haya al menos tantos objetivos como jugadores).
    IF v_game_mode = 'objetivos' THEN
        SELECT COUNT(*) INTO v_num_objetivos FROM Objetivos WHERE tipo = 'ocupacion';

        INSERT INTO Objetivos_Partida (id_partida, id_objetivo, id_usuario)
        SELECT p_id_partida, obj.id_objetivo, u.id_usuario
        FROM (
            SELECT id_usuario, ROW_NUMBER() OVER (ORDER BY RAND()) AS rn
            FROM Usuarios
            WHERE id_partida = p_id_partida AND estado = 'activo'
        ) u
        JOIN (
            SELECT id_objetivo, ROW_NUMBER() OVER (ORDER BY RAND()) AS rn
            FROM Objetivos
            WHERE tipo = 'ocupacion'
        ) obj ON obj.rn = ((u.rn - 1) % v_num_objetivos) + 1;
    END IF;

    -- Crea una fila de estadísticas por jugador
    INSERT INTO Estadisticas (id_usuario, id_partida)
    SELECT id_usuario, p_id_partida
    FROM Usuarios
    WHERE id_partida = p_id_partida AND estado = 'activo';

    UPDATE Partida SET estado = 'en_curso' WHERE id_partida = p_id_partida;

    -- Crea el primer turno para el jugador con orden_turno = 1
    INSERT INTO Turnos (id_partida, id_usuario, numero_turno, fase, fecha_inicio)
    SELECT p_id_partida, id_usuario, 1, 'refuerzo', NOW()
    FROM Usuarios
    WHERE id_partida = p_id_partida AND estado = 'activo'
    ORDER BY orden_turno LIMIT 1;
END$$
DELIMITER ;

-- 6) Trigger de victoria por objetivo: usa el umbral real del objetivo,
--    no un 30 fijo (así funciona con cualquiera de los objetivos nuevos).
DROP TRIGGER IF EXISTS trg_territorios_partida_after_update;
DELIMITER $$
CREATE TRIGGER trg_territorios_partida_after_update
AFTER UPDATE ON Territorios_Partida
FOR EACH ROW
BEGIN
    DECLARE v_territorios_restantes INT;
    DECLARE v_tipo_objetivo VARCHAR(20);
    DECLARE v_paises_requeridos INT;
    DECLARE v_paises_control INT;

    IF OLD.id_usuario IS NOT NULL
       AND (NEW.id_usuario IS NULL OR NEW.id_usuario <> OLD.id_usuario) THEN

        SELECT COUNT(*) INTO v_territorios_restantes
        FROM Territorios_Partida
        WHERE id_partida = OLD.id_partida AND id_usuario = OLD.id_usuario;

        IF v_territorios_restantes = 0 THEN
            UPDATE Usuarios
            SET estado = 'eliminado'
            WHERE id_usuario = OLD.id_usuario AND id_partida = OLD.id_partida;

            UPDATE Estadisticas
            SET resultado = 'perdedor'
            WHERE id_usuario = OLD.id_usuario AND id_partida = OLD.id_partida;

            UPDATE Cartas_Partida
            SET estado = 'descartada', id_usuario = NULL
            WHERE id_partida = OLD.id_partida AND id_usuario = OLD.id_usuario AND estado = 'mano';
        END IF;
    END IF;

    IF NEW.id_usuario IS NOT NULL
       AND (OLD.id_usuario IS NULL OR NEW.id_usuario <> OLD.id_usuario) THEN

        SELECT o.tipo, o.paises_requeridos INTO v_tipo_objetivo, v_paises_requeridos
        FROM Objetivos_Partida op JOIN Objetivos o ON o.id_objetivo = op.id_objetivo
        WHERE op.id_partida = NEW.id_partida AND op.id_usuario = NEW.id_usuario AND op.cumplido = FALSE
        LIMIT 1;

        IF v_tipo_objetivo = 'ocupacion' THEN
            SELECT COUNT(*) INTO v_paises_control
            FROM Territorios_Partida
            WHERE id_partida = NEW.id_partida AND id_usuario = NEW.id_usuario;

            IF v_paises_control >= COALESCE(v_paises_requeridos, 30) THEN
                UPDATE Objetivos_Partida
                SET cumplido = TRUE
                WHERE id_partida = NEW.id_partida AND id_usuario = NEW.id_usuario;

                UPDATE Partida
                SET estado = 'finalizada'
                WHERE id_partida = NEW.id_partida AND estado <> 'finalizada';

                UPDATE Estadisticas
                SET resultado = 'ganador'
                WHERE id_partida = NEW.id_partida AND id_usuario = NEW.id_usuario;

                UPDATE Estadisticas
                SET resultado = 'perdedor'
                WHERE id_partida = NEW.id_partida AND id_usuario <> NEW.id_usuario AND resultado = 'en_curso';
            END IF;
        END IF;
    END IF;
END$$
DELIMITER ;

SELECT 'Migración aplicada correctamente' AS resultado;
