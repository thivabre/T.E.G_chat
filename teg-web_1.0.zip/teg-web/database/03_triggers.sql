-- ============================================================================
-- TEG - TRIGGERS
-- Complementan a los stored procedures: automatizan reglas del juego que
-- deben cumplirse sin importar qué procedure (o qué INSERT/UPDATE directo)
-- haya originado el cambio.
-- Motor: MySQL
-- ============================================================================

DELIMITER $$

-- 3.1 Validar cupo y estado de la partida antes de que un jugador se una
CREATE TRIGGER trg_usuarios_before_insert
BEFORE INSERT ON Usuarios
FOR EACH ROW
BEGIN
    DECLARE v_estado VARCHAR(20);
    DECLARE v_max INT;
    DECLARE v_actuales INT;

    SELECT estado, max_jugadores INTO v_estado, v_max
    FROM Partida WHERE id_partida = NEW.id_partida;

    SELECT COUNT(*) INTO v_actuales
    FROM Usuarios WHERE id_partida = NEW.id_partida AND estado = 'activo';

    IF v_estado <> 'esperando' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No se puede unir a una partida que ya empezó o finalizó';
    ELSEIF v_actuales >= v_max THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La partida está completa';
    END IF;
END$$


-- 3.2 Evitar que un territorio quede con ejércitos negativos
CREATE TRIGGER trg_territorios_valida_ejercitos_ins
BEFORE INSERT ON Territorios_Partida
FOR EACH ROW
BEGIN
    IF NEW.cantidad_ejercitos < 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un territorio no puede tener ejércitos negativos';
    END IF;
END$$

CREATE TRIGGER trg_territorios_valida_ejercitos_upd
BEFORE UPDATE ON Territorios_Partida
FOR EACH ROW
BEGIN
    IF NEW.cantidad_ejercitos < 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un territorio no puede tener ejércitos negativos';
    END IF;
END$$


-- 3.3 Tras una conquista: eliminar automáticamente al jugador que se quedó
--     sin territorios, y verificar si el nuevo dueño cumplió su objetivo
--     de ocupación (esto no reemplaza el conteo de paises_conquistados,
--     que sigue a cargo de sp_realizar_ataque)
CREATE TRIGGER trg_territorios_partida_after_update
AFTER UPDATE ON Territorios_Partida
FOR EACH ROW
BEGIN
    DECLARE v_territorios_restantes INT;
    DECLARE v_tipo_objetivo VARCHAR(20);
    DECLARE v_paises_control INT;

    IF OLD.id_usuario IS NOT NULL
       AND (NEW.id_usuario IS NULL OR NEW.id_usuario <> OLD.id_usuario) THEN

        SELECT COUNT(*) INTO v_territorios_restantes
        FROM Territorios_Partida
        WHERE id_partida = OLD.id_partida AND id_usuario = OLD.id_usuario;

        IF v_territorios_restantes = 0 THEN
            UPDATE Usuarios
            SET estado = 'eliminado'
            WHERE id_usuario = OLD.id_usuario AND id_partida = OLD.id_partida;

            UPDATE Estadisticas
            SET resultado = 'perdedor'
            WHERE id_usuario = OLD.id_usuario AND id_partida = OLD.id_partida;

            UPDATE Cartas_Partida
            SET estado = 'descartada', id_usuario = NULL
            WHERE id_partida = OLD.id_partida AND id_usuario = OLD.id_usuario AND estado = 'mano';
        END IF;
    END IF;

    IF NEW.id_usuario IS NOT NULL
       AND (OLD.id_usuario IS NULL OR NEW.id_usuario <> OLD.id_usuario) THEN

        SELECT o.tipo INTO v_tipo_objetivo
        FROM Objetivos_Partida op JOIN Objetivos o ON o.id_objetivo = op.id_objetivo
        WHERE op.id_partida = NEW.id_partida AND op.id_usuario = NEW.id_usuario AND op.cumplido = FALSE
        LIMIT 1;

        IF v_tipo_objetivo = 'ocupacion' THEN
            SELECT COUNT(*) INTO v_paises_control
            FROM Territorios_Partida
            WHERE id_partida = NEW.id_partida AND id_usuario = NEW.id_usuario;

            IF v_paises_control >= 30 THEN
                UPDATE Objetivos_Partida
                SET cumplido = TRUE
                WHERE id_partida = NEW.id_partida AND id_usuario = NEW.id_usuario;

                UPDATE Partida
                SET estado = 'finalizada'
                WHERE id_partida = NEW.id_partida AND estado <> 'finalizada';

                UPDATE Estadisticas
                SET resultado = 'ganador'
                WHERE id_partida = NEW.id_partida AND id_usuario = NEW.id_usuario;

                UPDATE Estadisticas
                SET resultado = 'perdedor'
                WHERE id_partida = NEW.id_partida AND id_usuario <> NEW.id_usuario AND resultado = 'en_curso';
            END IF;
        END IF;
    END IF;
END$$


-- 3.4 Validar que las 3 cartas de un intercambio sean distintas, del
--     jugador que canjea, y estén en su mano (sp_intercambiar_cartas no
--     lo valida antes de descartarlas)
CREATE TRIGGER trg_intercambios_before_insert
BEFORE INSERT ON Intercambios
FOR EACH ROW
BEGIN
    DECLARE v_validas INT;

    IF NEW.id_carta_partida1 = NEW.id_carta_partida2
       OR NEW.id_carta_partida1 = NEW.id_carta_partida3
       OR NEW.id_carta_partida2 = NEW.id_carta_partida3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Las 3 cartas del intercambio deben ser distintas';
    END IF;

    SELECT COUNT(*) INTO v_validas
    FROM Cartas_Partida
    WHERE id_carta_partida IN (NEW.id_carta_partida1, NEW.id_carta_partida2, NEW.id_carta_partida3)
      AND id_partida = NEW.id_partida
      AND id_usuario = NEW.id_usuario
      AND estado = 'mano';

    IF v_validas <> 3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Las cartas deben pertenecer al jugador y estar en su mano';
    END IF;
END$$


-- 3.5 Reforzar la regla de chat privado vs. general a nivel de tabla
CREATE TRIGGER trg_chat_before_insert
BEFORE INSERT ON Chat
FOR EACH ROW
BEGIN
    IF NEW.tipo = 'general' AND NEW.id_receptor IS NOT NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un mensaje general no debe tener receptor';
    END IF;

    IF NEW.tipo = 'privado' THEN
        IF NEW.id_receptor IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un mensaje privado necesita un receptor';
        ELSEIF NEW.id_receptor = NEW.id_emisor THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El receptor no puede ser el mismo emisor';
        ELSEIF NOT EXISTS (
            SELECT 1 FROM Usuarios
            WHERE id_usuario = NEW.id_receptor AND id_partida = NEW.id_partida
        ) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El receptor no pertenece a esta partida';
        END IF;
    END IF;
END$$


-- 3.6 Evitar que se abra un turno nuevo mientras otro sigue activo
CREATE TRIGGER trg_turnos_before_insert
BEFORE INSERT ON Turnos
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1 FROM Turnos
        WHERE id_partida = NEW.id_partida AND fecha_fin IS NULL
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ya existe un turno abierto en esta partida';
    END IF;
END$$


-- 3.7 Mantener simétrica la adyacencia entre países al cargar el tablero
CREATE TRIGGER trg_limitrofes_simetria
AFTER INSERT ON Paises_Limitrofes
FOR EACH ROW
BEGIN
    INSERT IGNORE INTO Paises_Limitrofes (id_pais_origen, id_pais_destino)
    VALUES (NEW.id_pais_destino, NEW.id_pais_origen);
END$$

DELIMITER ;
