"""
TEG Web - Initial Database Schema Migration
Creates all tables for the TEG game
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql

# revision identifiers
revision = '0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create enums first
    room_type_enum = sa.Enum('publica', 'privada', name='room_type_enum')
    room_status_enum = sa.Enum('waiting', 'in_progress', 'finished', name='room_status_enum')
    player_status_enum = sa.Enum('active', 'eliminated', 'surrendered', name='player_status_enum')
    game_mode_enum = sa.Enum('objetivos', 'conquista', name='game_mode_enum')
    game_phase_enum = sa.Enum('setup', 'reinforcement', 'attack', 'fortify', 'trade_cards', 'finished', name='game_phase_enum')
    card_type_enum = sa.Enum('infantry', 'cavalry', 'artillery', 'joker', name='card_type_enum')
    objective_type_enum = sa.Enum('occupation', 'destruction', name='objective_type_enum')
    chat_type_enum = sa.Enum('general', 'private', name='chat_type_enum')

    room_type_enum.create(op.get_bind(), checkfirst=True)
    room_status_enum.create(op.get_bind(), checkfirst=True)
    player_status_enum.create(op.get_bind(), checkfirst=True)
    game_mode_enum.create(op.get_bind(), checkfirst=True)
    game_phase_enum.create(op.get_bind(), checkfirst=True)
    card_type_enum.create(op.get_bind(), checkfirst=True)
    objective_type_enum.create(op.get_bind(), checkfirst=True)
    chat_type_enum.create(op.get_bind(), checkfirst=True)

    # Continents table
    op.create_table(
        'continents',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(50), nullable=False),
        sa.Column('bonus_armies', sa.Integer(), nullable=False),
        sa.Column('color', sa.String(7), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name', name='uq_continent_name'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )

    # Countries table
    op.create_table(
        'countries',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(50), nullable=False),
        sa.Column('continent_id', sa.Integer(), nullable=False),
        sa.Column('svg_path', sa.Text(), nullable=False),
        sa.Column('x_coord', sa.Integer(), nullable=False),
        sa.Column('y_coord', sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name', name='uq_country_name'),
        sa.ForeignKeyConstraint(['continent_id'], ['continents.id'], ondelete='RESTRICT'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )

    # Borders table
    op.create_table(
        'borders',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('country_from_id', sa.Integer(), nullable=False),
        sa.Column('country_to_id', sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('country_from_id', 'country_to_id', name='uq_border'),
        sa.ForeignKeyConstraint(['country_from_id'], ['countries.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['country_to_id'], ['countries.id'], ondelete='CASCADE'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )

    # Cards table
    op.create_table(
        'cards',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('country_id', sa.Integer(), nullable=False),
        sa.Column('type', card_type_enum, nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['country_id'], ['countries.id'], ondelete='RESTRICT'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )

    # Objectives table
    op.create_table(
        'objectives',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('description', sa.Text(), nullable=False),
        sa.Column('type', objective_type_enum, nullable=False),
        sa.Column('target_count', sa.Integer(), nullable=False, default=0),
        sa.Column('target_continent_id', sa.Integer(), nullable=True),
        sa.Column('target_player_color', sa.String(20), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['target_continent_id'], ['continents.id'], ondelete='SET NULL'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )

    # Players table (must be before rooms due to FK references from rooms to players)
    op.create_table(
        'players',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('room_id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(50), nullable=False),
        sa.Column('color', sa.String(7), nullable=False),
        sa.Column('position', sa.Integer(), nullable=False),
        sa.Column('status', player_status_enum, nullable=False, default='active'),
        sa.Column('armies_in_hand', sa.Integer(), nullable=False, default=0),
        sa.Column('is_host', sa.Boolean(), nullable=False, default=False),
        sa.Column('is_ready', sa.Boolean(), nullable=False, default=False),
        sa.Column('joined_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('eliminated_at', sa.DateTime(), nullable=True),
        sa.Column('eliminated_by', sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('room_id', 'name', name='uq_player_name_per_room'),
        sa.UniqueConstraint('room_id', 'position', name='uq_player_position_per_room'),
        sa.ForeignKeyConstraint(['room_id'], ['rooms.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['eliminated_by'], ['players.id'], ondelete='SET NULL'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )
    op.create_index('ix_players_room_id', 'players', ['room_id'], unique=False)

    # Rooms table
    op.create_table(
        'rooms',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('code', sa.String(6), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('type', room_type_enum, nullable=False, default='publica'),
        sa.Column('status', room_status_enum, nullable=False, default='waiting'),
        sa.Column('max_players', sa.Integer(), nullable=False, default=6),
        sa.Column('game_mode', game_mode_enum, nullable=False, default='objetivos'),
        sa.Column('turn_time_limit', sa.Integer(), nullable=False, default=0),
        sa.Column('host_id', sa.Integer(), nullable=True),
        sa.Column('winner_id', sa.Integer(), nullable=True),
        sa.Column('current_turn_player_id', sa.Integer(), nullable=True),
        sa.Column('current_phase', game_phase_enum, nullable=False, default='setup'),
        sa.Column('turn_number', sa.Integer(), nullable=False, default=0),
        sa.Column('trade_count', sa.Integer(), nullable=False, default=0),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('started_at', sa.DateTime(), nullable=True),
        sa.Column('finished_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('code', name='uq_room_code'),
        sa.ForeignKeyConstraint(['host_id'], ['players.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['winner_id'], ['players.id'], ondelete='SET NULL'),
        sa.ForeignKeyConstraint(['current_turn_player_id'], ['players.id'], ondelete='SET NULL'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )
    op.create_index('ix_rooms_code', 'rooms', ['code'], unique=False)

    # Spectators table
    op.create_table(
        'spectators',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('room_id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(50), nullable=False),
        sa.Column('joined_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('left_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('room_id', 'name', name='uq_spectator_name_per_room'),
        sa.ForeignKeyConstraint(['room_id'], ['rooms.id'], ondelete='CASCADE'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )

    # Game Countries table
    op.create_table(
        'game_countries',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('room_id', sa.Integer(), nullable=False),
        sa.Column('country_id', sa.Integer(), nullable=False),
        sa.Column('player_id', sa.Integer(), nullable=True),
        sa.Column('armies', sa.Integer(), nullable=False, default=0),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('room_id', 'country_id', name='uq_game_country'),
        sa.ForeignKeyConstraint(['room_id'], ['rooms.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['country_id'], ['countries.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['player_id'], ['players.id'], ondelete='SET NULL'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )
    op.create_index('ix_game_countries_room_id', 'game_countries', ['room_id'], unique=False)
    op.create_index('ix_game_countries_player_id', 'game_countries', ['player_id'], unique=False)

    # Game Cards table
    op.create_table(
        'game_cards',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('room_id', sa.Integer(), nullable=False),
        sa.Column('card_id', sa.Integer(), nullable=False),
        sa.Column('player_id', sa.Integer(), nullable=True),
        sa.Column('in_deck', sa.Boolean(), nullable=False, default=True),
        sa.Column('drawn_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('room_id', 'card_id', name='uq_game_card'),
        sa.ForeignKeyConstraint(['room_id'], ['rooms.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['card_id'], ['cards.id'], ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['player_id'], ['players.id'], ondelete='SET NULL'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )
    op.create_index('ix_game_cards_room_id', 'game_cards', ['room_id'], unique=False)
    op.create_index('ix_game_cards_player_id', 'game_cards', ['player_id'], unique=False)

    # Player Objectives table
    op.create_table(
        'player_objectives',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('room_id', sa.Integer(), nullable=False),
        sa.Column('player_id', sa.Integer(), nullable=False),
        sa.Column('objective_id', sa.Integer(), nullable=False),
        sa.Column('completed', sa.Boolean(), nullable=False, default=False),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('room_id', 'player_id', name='uq_player_objective'),
        sa.ForeignKeyConstraint(['room_id'], ['rooms.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['player_id'], ['players.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['objective_id'], ['objectives.id'], ondelete='RESTRICT'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )
    op.create_index('ix_player_objectives_room_id', 'player_objectives', ['room_id'], unique=False)

    # Chat Messages table
    op.create_table(
        'chat_messages',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('room_id', sa.Integer(), nullable=False),
        sa.Column('sender_id', sa.Integer(), nullable=False),
        sa.Column('recipient_id', sa.Integer(), nullable=True),
        sa.Column('type', chat_type_enum, nullable=False, default='general'),
        sa.Column('message', sa.Text(), nullable=False),
        sa.Column('sent_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['room_id'], ['rooms.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['sender_id'], ['players.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['recipient_id'], ['players.id'], ondelete='SET NULL'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )
    op.create_index('ix_chat_messages_room_id', 'chat_messages', ['room_id'], unique=False)
    op.create_index('ix_chat_messages_recipient_id', 'chat_messages', ['recipient_id'], unique=False)

    # Turn Timers table
    op.create_table(
        'turn_timers',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('room_id', sa.Integer(), nullable=False),
        sa.Column('player_id', sa.Integer(), nullable=False),
        sa.Column('phase', game_phase_enum, nullable=False),
        sa.Column('started_at', sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column('expires_at', sa.DateTime(), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=False, default=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['room_id'], ['rooms.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['player_id'], ['players.id'], ondelete='CASCADE'),
        mysql_charset='utf8mb4',
        mysql_collate='utf8mb4_unicode_ci'
    )
    op.create_index('idx_active_timer', 'turn_timers', ['room_id', 'is_active'], unique=False)


def downgrade() -> None:
    # Drop tables in reverse order
    op.drop_table('turn_timers')
    op.drop_table('chat_messages')
    op.drop_table('player_objectives')
    op.drop_table('game_cards')
    op.drop_table('game_countries')
    op.drop_table('spectators')
    op.drop_table('players')
    op.drop_table('rooms')
    op.drop_table('objectives')
    op.drop_table('cards')
    op.drop_table('borders')
    op.drop_table('countries')
    op.drop_table('continents')

    # Drop enums
    chat_type_enum = sa.Enum('general', 'private', name='chat_type_enum')
    objective_type_enum = sa.Enum('occupation', 'destruction', name='objective_type_enum')
    card_type_enum = sa.Enum('infantry', 'cavalry', 'artillery', 'joker', name='card_type_enum')
    game_phase_enum = sa.Enum('setup', 'reinforcement', 'attack', 'fortify', 'trade_cards', 'finished', name='game_phase_enum')
    game_mode_enum = sa.Enum('objetivos', 'conquista', name='game_mode_enum')
    player_status_enum = sa.Enum('active', 'eliminated', 'surrendered', name='player_status_enum')
    room_status_enum = sa.Enum('waiting', 'in_progress', 'finished', name='room_status_enum')
    room_type_enum = sa.Enum('publica', 'privada', name='room_type_enum')

    chat_type_enum.drop(op.get_bind(), checkfirst=True)
    objective_type_enum.drop(op.get_bind(), checkfirst=True)
    card_type_enum.drop(op.get_bind(), checkfirst=True)
    game_phase_enum.drop(op.get_bind(), checkfirst=True)
    game_mode_enum.drop(op.get_bind(), checkfirst=True)
    player_status_enum.drop(op.get_bind(), checkfirst=True)
    room_status_enum.drop(op.get_bind(), checkfirst=True)
    room_type_enum.drop(op.get_bind(), checkfirst=True)