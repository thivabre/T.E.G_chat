import asyncio
import sys
import traceback
sys.path.insert(0, r'C:\Users\Thiago\teg-web\backend')

from app.database import get_db
from app.models import Room, Player, RoomTypeEnum, RoomStatusEnum, GameModeEnum, PlayerStatusEnum
from sqlalchemy import select

async def test():
    try:
        async for db in get_db():
            import random
            import string
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
            room = Room(
                code=code,
                name='Test Room',
                type=RoomTypeEnum.publica,
                max_players=4,
                game_mode=GameModeEnum.objetivos,
                status=RoomStatusEnum.waiting,
            )
            db.add(room)
            await db.flush()
            print(f'Room created: {room.id}, {room.code}')

            host = Player(
                room_id=room.id,
                name='Player1',
                color='#e74c3c',
                position=1,
                status=PlayerStatusEnum.active,
                is_host=True,
                is_ready=True,
            )
            db.add(host)
            await db.flush()
            print(f'Host created: {host.id}')

            room.host_id = host.id
            await db.commit()
            print('Commit successful')

            # Verify
            result = await db.execute(select(Room).where(Room.id == room.id))
            r = result.scalar_one()
            print(f'Verified: {r.id}, {r.code}, host_id={r.host_id}')
    except Exception as e:
        traceback.print_exc()

asyncio.run(test())