import asyncio
import sys
sys.path.insert(0, r'C:\Users\Thiago\teg-web\backend')

from app.database import get_db
from app.models import Room, Player, RoomTypeEnum, RoomStatusEnum, GameModeEnum, PlayerStatusEnum
from sqlalchemy import select, func

async def test():
    async for db in get_db():
        # Check rooms table
        result = await db.execute(select(Room))
        rooms = result.scalars().all()
        print(f"Rooms: {len(rooms)}")
        for r in rooms:
            print(f"  Room: {r.id}, {r.code}, {r.name}, {r.status}")

        # Check players table
        result = await db.execute(select(Player))
        players = result.scalars().all()
        print(f"Players: {len(players)}")
        for p in players:
            print(f"  Player: {p.id}, {p.name}, room={p.room_id}")

asyncio.run(test())