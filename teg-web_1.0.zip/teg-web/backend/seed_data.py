#!/usr/bin/env python3
"""
TEG Web - Database Seed Script
Populates the database with TEG game data: continents, countries, borders, cards, objectives
"""

import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import select

from app.config import settings
from app.models import (
    Base, Continent, Country, Border, Card, Objective,
    CardTypeEnum, ObjectiveTypeEnum
)

# TEG Game Data
CONTINENTS = [
    {"name": "América del Norte", "bonus_armies": 5, "color": "#e74c3c"},
    {"name": "América del Sur", "bonus_armies": 2, "color": "#2ecc71"},
    {"name": "Europa", "bonus_armies": 5, "color": "#3498db"},
    {"name": "África", "bonus_armies": 3, "color": "#f1c40f"},
    {"name": "Asia", "bonus_armies": 7, "color": "#9b59b6"},
    {"name": "Oceanía", "bonus_armies": 2, "color": "#e67e22"},
]

COUNTRIES = [
    # América del Norte (9 countries)
    {"name": "Alaska", "continent": "América del Norte", "x": 50, "y": 80},
    {"name": "Noroeste", "continent": "América del Norte", "x": 100, "y": 80},
    {"name": "Groenlandia", "continent": "América del Norte", "x": 180, "y": 40},
    {"name": "Alberta", "continent": "América del Norte", "x": 100, "y": 120},
    {"name": "Ontario", "continent": "América del Norte", "x": 140, "y": 110},
    {"name": "Quebec", "continent": "América del Norte", "x": 180, "y": 100},
    {"name": "Estados Unidos del Oeste", "continent": "América del Norte", "x": 100, "y": 150},
    {"name": "Estados Unidos del Este", "continent": "América del Norte", "x": 140, "y": 140},
    {"name": "América Central", "continent": "América del Norte", "x": 100, "y": 180},

    # América del Sur (4 countries)
    {"name": "Venezuela", "continent": "América del Sur", "x": 120, "y": 220},
    {"name": "Perú", "continent": "América del Sur", "x": 120, "y": 280},
    {"name": "Brasil", "continent": "América del Sur", "x": 160, "y": 250},
    {"name": "Argentina", "continent": "América del Sur", "x": 140, "y": 320},

    # Europa (7 countries)
    {"name": "Islandia", "continent": "Europa", "x": 260, "y": 40},
    {"name": "Gran Bretaña", "continent": "Europa", "x": 280, "y": 70},
    {"name": "Escandinavia", "continent": "Europa", "x": 320, "y": 40},
    {"name": "Europa del Norte", "continent": "Europa", "x": 320, "y": 70},
    {"name": "Europa del Sur", "continent": "Europa", "x": 320, "y": 110},
    {"name": "Europa del Este", "continent": "Europa", "x": 360, "y": 70},
    {"name": "Ucrania", "continent": "Europa", "x": 380, "y": 70},

    # África (6 countries)
    {"name": "África del Norte", "continent": "África", "x": 300, "y": 140},
    {"name": "Egipto", "continent": "África", "x": 340, "y": 140},
    {"name": "África Oriental", "continent": "África", "x": 360, "y": 180},
    {"name": "Congo", "continent": "África", "x": 320, "y": 200},
    {"name": "África del Sur", "continent": "África", "x": 300, "y": 260},
    {"name": "Madagascar", "continent": "África", "x": 380, "y": 240},

    # Asia (12 countries)
    {"name": "Urales", "continent": "Asia", "x": 400, "y": 40},
    {"name": "Siberia", "continent": "Asia", "x": 440, "y": 40},
    {"name": "Yakutsk", "continent": "Asia", "x": 480, "y": 40},
    {"name": "Kamchatka", "continent": "Asia", "x": 520, "y": 40},
    {"name": "Irkutsk", "continent": "Asia", "x": 460, "y": 70},
    {"name": "Mongolia", "continent": "Asia", "x": 460, "y": 90},
    {"name": "Japón", "continent": "Asia", "x": 520, "y": 80},
    {"name": "China", "continent": "Asia", "x": 460, "y": 110},
    {"name": "Medio Oriente", "continent": "Asia", "x": 380, "y": 110},
    {"name": "India", "continent": "Asia", "x": 420, "y": 130},
    {"name": "Sudeste Asiático", "continent": "Asia", "x": 440, "y": 150},
    {"name": "Afganistán", "continent": "Asia", "x": 400, "y": 90},

    # Oceanía (4 countries)
    {"name": "Indonesia", "continent": "Oceanía", "x": 440, "y": 180},
    {"name": "Nueva Guinea", "continent": "Oceanía", "x": 480, "y": 180},
    {"name": "Australia Occidental", "continent": "Oceanía", "x": 460, "y": 220},
    {"name": "Australia Oriental", "continent": "Oceanía", "x": 500, "y": 220},
]

# Borders (adjacent countries by name)
BORDERS = [
    # América del Norte
    ("Alaska", "Noroeste"), ("Alaska", "Alberta"), ("Alaska", "Kamchatka"),
    ("Noroeste", "Alaska"), ("Noroeste", "Alberta"), ("Noroeste", "Ontario"), ("Noroeste", "Groenlandia"),
    ("Groenlandia", "Noroeste"), ("Groenlandia", "Ontario"), ("Groenlandia", "Quebec"), ("Groenlandia", "Islandia"),
    ("Alberta", "Alaska"), ("Alberta", "Noroeste"), ("Alberta", "Ontario"), ("Alberta", "Estados Unidos del Oeste"),
    ("Ontario", "Noroeste"), ("Ontario", "Groenlandia"), ("Ontario", "Alberta"), ("Ontario", "Estados Unidos del Oeste"), ("Ontario", "Estados Unidos del Este"), ("Ontario", "Quebec"),
    ("Quebec", "Groenlandia"), ("Quebec", "Ontario"), ("Quebec", "Estados Unidos del Este"),
    ("Estados Unidos del Oeste", "Alberta"), ("Estados Unidos del Oeste", "Ontario"), ("Estados Unidos del Oeste", "Estados Unidos del Este"), ("Estados Unidos del Oeste", "América Central"),
    ("Estados Unidos del Este", "Ontario"), ("Estados Unidos del Este", "Quebec"), ("Estados Unidos del Este", "Estados Unidos del Oeste"), ("Estados Unidos del Este", "América Central"),
    ("América Central", "Estados Unidos del Oeste"), ("América Central", "Estados Unidos del Este"), ("América Central", "Venezuela"),

    # América del Sur
    ("Venezuela", "América Central"), ("Venezuela", "Perú"), ("Venezuela", "Brasil"),
    ("Perú", "Venezuela"), ("Perú", "Brasil"), ("Perú", "Argentina"),
    ("Brasil", "Venezuela"), ("Brasil", "Perú"), ("Brasil", "Argentina"), ("Brasil", "África del Norte"),
    ("Argentina", "Perú"), ("Argentina", "Brasil"),

    # Europa
    ("Islandia", "Groenlandia"), ("Islandia", "Gran Bretaña"), ("Islandia", "Escandinavia"),
    ("Gran Bretaña", "Islandia"), ("Gran Bretaña", "Escandinavia"), ("Gran Bretaña", "Europa del Norte"), ("Gran Bretaña", "Europa del Sur"),
    ("Escandinavia", "Islandia"), ("Escandinavia", "Gran Bretaña"), ("Escandinavia", "Europa del Norte"), ("Escandinavia", "Urales"), ("Escandinavia", "Ucrania"),
    ("Europa del Norte", "Gran Bretaña"), ("Europa del Norte", "Escandinavia"), ("Europa del Norte", "Europa del Sur"), ("Europa del Norte", "Europa del Este"),
    ("Europa del Sur", "Gran Bretaña"), ("Europa del Sur", "Europa del Norte"), ("Europa del Sur", "Europa del Este"), ("Europa del Sur", "Medio Oriente"), ("Europa del Sur", "Egipto"), ("Europa del Sur", "África del Norte"),
    ("Europa del Este", "Escandinavia"), ("Europa del Este", "Europa del Norte"), ("Europa del Este", "Europa del Sur"), ("Europa del Este", "Urales"), ("Europa del Este", "Ucrania"), ("Europa del Este", "Medio Oriente"),
    ("Ucrania", "Escandinavia"), ("Ucrania", "Europa del Este"), ("Ucrania", "Urales"), ("Ucrania", "Afganistán"), ("Ucrania", "Medio Oriente"),

    # África
    ("África del Norte", "Europa del Sur"), ("África del Norte", "Egipto"), ("África del Norte", "Congo"), ("África del Norte", "África Oriental"), ("África del Norte", "Brasil"),
    ("Egipto", "Europa del Sur"), ("Egipto", "África del Norte"), ("Egipto", "África Oriental"), ("Egipto", "Medio Oriente"),
    ("África Oriental", "Egipto"), ("África Oriental", "África del Norte"), ("África Oriental", "Congo"), ("África Oriental", "Madagascar"), ("África Oriental", "Medio Oriente"), ("África Oriental", "India"),
    ("Congo", "África del Norte"), ("Congo", "África Oriental"), ("Congo", "África del Sur"),
    ("África del Sur", "Congo"), ("África del Sur", "Madagascar"),
    ("Madagascar", "África Oriental"), ("Madagascar", "África del Sur"),

    # Asia
    ("Urales", "Escandinavia"), ("Urales", "Europa del Este"), ("Urales", "Ucrania"), ("Urales", "Siberia"), ("Urales", "Afganistán"), ("Urales", "China"),
    ("Siberia", "Urales"), ("Siberia", "Yakutsk"), ("Siberia", "Irkutsk"), ("Siberia", "Mongolia"), ("Siberia", "China"),
    ("Yakutsk", "Siberia"), ("Yakutsk", "Irkutsk"), ("Yakutsk", "Kamchatka"),
    ("Kamchatka", "Yakutsk"), ("Kamchatka", "Irkutsk"), ("Kamchatka", "Mongolia"), ("Kamchatka", "Japón"), ("Kamchatka", "Alaska"),
    ("Irkutsk", "Siberia"), ("Irkutsk", "Yakutsk"), ("Irkutsk", "Kamchatka"), ("Irkutsk", "Mongolia"), ("Irkutsk", "China"),
    ("Mongolia", "Siberia"), ("Mongolia", "Irkutsk"), ("Mongolia", "Kamchatka"), ("Mongolia", "Japón"), ("Mongolia", "China"),
    ("Japón", "Kamchatka"), ("Japón", "Mongolia"),
    ("China", "Urales"), ("China", "Siberia"), ("China", "Irkutsk"), ("China", "Mongolia"), ("China", "Afganistán"), ("China", "India"), ("China", "Sudeste Asiático"),
    ("Medio Oriente", "Europa del Sur"), ("Medio Oriente", "Europa del Este"), ("Medio Oriente", "Ucrania"), ("Medio Oriente", "Afganistán"), ("Medio Oriente", "India"), ("Medio Oriente", "Egipto"), ("Medio Oriente", "África Oriental"),
    ("India", "Medio Oriente"), ("India", "China"), ("India", "Sudeste Asiático"), ("India", "Afganistán"),
    ("Sudeste Asiático", "China"), ("Sudeste Asiático", "India"), ("Sudeste Asiático", "Indonesia"),
    ("Afganistán", "Urales"), ("Afganistán", "Ucrania"), ("Afganistán", "China"), ("Afganistán", "Medio Oriente"), ("Afganistán", "India"),

    # Oceanía
    ("Indonesia", "Sudeste Asiático"), ("Indonesia", "Nueva Guinea"), ("Indonesia", "Australia Occidental"),
    ("Nueva Guinea", "Indonesia"), ("Nueva Guinea", "Australia Occidental"), ("Nueva Guinea", "Australia Oriental"),
    ("Australia Occidental", "Indonesia"), ("Australia Occidental", "Nueva Guinea"), ("Australia Occidental", "Australia Oriental"),
    ("Australia Oriental", "Nueva Guinea"), ("Australia Oriental", "Australia Occidental"),
]

# Cards (42 countries + 2 jokers = 44 cards)
# Distribution: 14 infantry, 14 cavalry, 14 artillery, 2 jokers
CARD_TYPES = [
    "infantry", "cavalry", "artillery", "infantry", "cavalry", "artillery",
    "infantry", "cavalry", "artillery", "infantry", "cavalry", "artillery",
    "infantry", "cavalry", "artillery", "infantry", "cavalry", "artillery",
    "infantry", "cavalry", "artillery", "infantry", "cavalry", "artillery",
    "infantry", "cavalry", "artillery", "infantry", "cavalry", "artillery",
    "infantry", "cavalry", "artillery", "infantry", "cavalry", "artillery",
    "infantry", "cavalry", "artillery", "infantry", "cavalry", "artillery",
    "joker", "joker",
]

OBJECTIVES = [
    # Occupation objectives
    {"description": "Ocupar 24 países a tu elección", "type": "occupation", "target_count": 24, "target_continent_id": None, "target_player_color": None},
    {"description": "Ocupar 18 países y tener al menos 2 ejércitos en cada uno", "type": "occupation", "target_count": 18, "target_continent_id": None, "target_player_color": None},
    {"description": "Ocupar 3 continentes completos", "type": "occupation", "target_count": 3, "target_continent_id": None, "target_player_color": None},
    {"description": "Ocupar América del Norte y África", "type": "occupation", "target_count": 0, "target_continent_id": None, "target_player_color": None},  # Special: 2 continents
    {"description": "Ocupar Europa y Oceanía", "type": "occupation", "target_count": 0, "target_continent_id": None, "target_player_color": None},
    {"description": "Ocupar Asia y América del Sur", "type": "occupation", "target_count": 0, "target_continent_id": None, "target_player_color": None},
    {"description": "Ocupar América del Norte y Oceanía", "type": "occupation", "target_count": 0, "target_continent_id": None, "target_player_color": None},
    {"description": "Ocupar Europa y América del Sur", "type": "occupation", "target_count": 0, "target_continent_id": None, "target_player_color": None},
    {"description": "Ocupar África y Asia", "type": "occupation", "target_count": 0, "target_continent_id": None, "target_player_color": None},

    # Destruction objectives
    {"description": "Destruir al jugador Rojo", "type": "destruction", "target_count": 0, "target_continent_id": None, "target_player_color": "#e74c3c"},
    {"description": "Destruir al jugador Azul", "type": "destruction", "target_count": 0, "target_continent_id": None, "target_player_color": "#3498db"},
    {"description": "Destruir al jugador Verde", "type": "destruction", "target_count": 0, "target_continent_id": None, "target_player_color": "#2ecc71"},
    {"description": "Destruir al jugador Amarillo", "type": "destruction", "target_count": 0, "target_continent_id": None, "target_player_color": "#f1c40f"},
    {"description": "Destruir al jugador Naranja", "type": "destruction", "target_count": 0, "target_continent_id": None, "target_player_color": "#e67e22"},
    {"description": "Destruir al jugador Violeta", "type": "destruction", "target_count": 0, "target_continent_id": None, "target_player_color": "#9b59b6"},
]


async def seed_database():
    """Seed the database with TEG game data."""
    engine = create_async_engine(
        settings.DATABASE_URL,
        pool_pre_ping=False,
        echo=False,
    )

    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with async_session() as session:
        # Check if already seeded
        result = await session.execute(select(Continent))
        if result.scalars().first():
            print("Database already seeded, skipping...")
            return

        print("Seeding continents...")
        continent_map = {}
        for cont_data in CONTINENTS:
            cont = Continent(**cont_data)
            session.add(cont)
            await session.flush()
            continent_map[cont_data["name"]] = cont.id

        print("Seeding countries...")
        country_map = {}
        for i, country_data in enumerate(COUNTRIES):
            cont_id = continent_map[country_data["continent"]]
            country = Country(
                name=country_data["name"],
                continent_id=cont_id,
                svg_path=f"M{country_data['x']},{country_data['y']} h40 v30 h-40 z",  # Simple placeholder
                x_coord=country_data["x"],
                y_coord=country_data["y"],
            )
            session.add(country)
            await session.flush()
            country_map[country_data["name"]] = country.id

        print("Seeding borders...")
        for from_name, to_name in BORDERS:
            from_id = country_map.get(from_name)
            to_id = country_map.get(to_name)
            if from_id and to_id:
                border = Border(country_from_id=from_id, country_to_id=to_id)
                session.add(border)

        print("Seeding cards...")
        for i, country_data in enumerate(COUNTRIES):
            country_id = country_map[country_data["name"]]
            card_type = CardTypeEnum(CARD_TYPES[i % len(CARD_TYPES)])
            card = Card(country_id=country_id, type=card_type)
            session.add(card)

        print("Seeding objectives...")
        for obj_data in OBJECTIVES:
            obj = Objective(**obj_data)
            session.add(obj)

        await session.commit()
        print("Database seeded successfully!")

    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(seed_database())