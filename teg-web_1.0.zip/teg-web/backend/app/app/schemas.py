"""
TEG Web - Pydantic Schemas
API request/response models and WebSocket event definitions
"""

from datetime import datetime
from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field, ConfigDict
from enum import Enum


# ============================================================================
# Enums (matching database)
# ============================================================================

class RoomType(str, Enum):
    publica = "publica"
    privada = "privada"


class RoomStatus(str, Enum):
    waiting = "waiting"
    in_progress = "in_progress"
    finished = "finished"


class PlayerStatus(str, Enum):
    active = "active"
    eliminated = "eliminated"
    surrendered = "surrendered"


class GameMode(str, Enum):
    objetivos = "objetivos"
    conquista = "conquista"


class GamePhase(str, Enum):
    setup = "setup"
    reinforcement = "reinforcement"
    attack = "attack"
    fortify = "fortify"
    trade_cards = "trade_cards"
    finished = "finished"


class CardType(str, Enum):
    infantry = "infantry"
    cavalry = "cavalry"
    artillery = "artillery"
    joker = "joker"


class ObjectiveType(str, Enum):
    occupation = "occupation"
    destruction = "destruction"


class ChatType(str, Enum):
    general = "general"
    private = "private"


# ============================================================================
# Base Models
# ============================================================================

class BaseSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ============================================================================
# Room Schemas
# ============================================================================

class RoomCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    type: RoomType = RoomType.publica
    max_players: int = Field(..., ge=2, le=6)
    game_mode: GameMode = GameMode.objetivos
    turn_time_limit: int = Field(0, ge=0, le=300)  # 0 = no timer
    host_name: str = Field(..., min_length=1, max_length=50)


class RoomJoin(BaseModel):
    code: str = Field(..., min_length=6, max_length=6)
    player_name: str = Field(..., min_length=1, max_length=50)


class RoomResponse(BaseSchema):
    id: int
    code: str
    name: str
    type: RoomType
    status: RoomStatus
    max_players: int
    game_mode: GameMode
    turn_time_limit: int
    host_id: Optional[int]
    host_name: Optional[str]
    current_turn_player_id: Optional[int]
    current_phase: GamePhase
    turn_number: int
    trade_count: int
    created_at: datetime
    started_at: Optional[datetime]
    finished_at: Optional[datetime]


class RoomDetailResponse(RoomResponse):
    players: List["PlayerResponse"]
    spectators: List["SpectatorResponse"]


class RoomSummaryResponse(BaseSchema):
    id: int
    code: str
    name: str
    type: RoomType
    status: RoomStatus
    max_players: int
    game_mode: GameMode
    turn_time_limit: int
    player_count: int
    spectator_count: int
    host_name: str
    created_at: datetime


# ============================================================================
# Player Schemas
# ============================================================================

class PlayerResponse(BaseSchema):
    id: int
    room_id: int
    name: str
    color: str
    position: int
    status: PlayerStatus
    armies_in_hand: int
    is_host: bool
    is_ready: bool
    joined_at: datetime
    eliminated_at: Optional[datetime]
    eliminated_by: Optional[int]


class SpectatorResponse(BaseSchema):
    id: int
    room_id: int
    name: str
    joined_at: datetime
    left_at: Optional[datetime]


# ============================================================================
# Game Country Schemas
# ============================================================================

class GameCountryResponse(BaseSchema):
    id: int
    room_id: int
    country_id: int
    country_name: Optional[str] = None
    continent_name: Optional[str] = None
    player_id: Optional[int]
    player_name: Optional[str] = None
    player_color: Optional[str] = None
    armies: int


class CountryInfo(BaseModel):
    id: int
    name: str
    continent_id: int
    continent_name: str
    svg_path: str
    x_coord: int
    y_coord: int
    borders: List[int]  # adjacent country IDs


class ContinentInfo(BaseModel):
    id: int
    name: str
    bonus_armies: int
    color: str
    countries: List[int]  # country IDs


# ============================================================================
# Card Schemas
# ============================================================================

class CardResponse(BaseSchema):
    id: int
    country_id: int
    country_name: str
    type: CardType


class GameCardResponse(BaseSchema):
    id: int
    room_id: int
    card_id: int
    card: CardResponse
    player_id: Optional[int]
    player_name: Optional[str] = None
    in_deck: bool
    drawn_at: Optional[datetime]


class TradeCardsRequest(BaseModel):
    card_ids: List[int] = Field(..., min_length=3, max_length=3)


class TradeCardsResponse(BaseModel):
    success: bool
    armies_received: int
    new_trade_count: int
    cards_returned: List[GameCardResponse]


# ============================================================================
# Objective Schemas
# ============================================================================

class ObjectiveResponse(BaseSchema):
    id: int
    description: str
    type: ObjectiveType
    target_count: int
    target_continent_id: Optional[int]
    target_player_color: Optional[str]


class PlayerObjectiveResponse(BaseSchema):
    id: int
    room_id: int
    player_id: int
    objective: ObjectiveResponse
    completed: bool
    completed_at: Optional[datetime]


# ============================================================================
# Combat Schemas
# ============================================================================

class AttackRequest(BaseModel):
    from_country_id: int
    to_country_id: int
    attacker_dice: int = Field(..., ge=1, le=3)


class CombatResult(BaseModel):
    attacker_rolls: List[int]
    defender_rolls: List[int]
    attacker_losses: int
    defender_losses: int
    conquered: bool
    attacker_remaining: int
    defender_remaining: int


# ============================================================================
# Fortify Schemas
# ============================================================================

class FortifyRequest(BaseModel):
    from_country_id: int
    to_country_id: int
    armies: int = Field(..., ge=1)


# ============================================================================
# Reinforcement Schemas
# ============================================================================

class ReinforceRequest(BaseModel):
    country_id: int
    armies: int = Field(..., ge=1)


# ============================================================================
# Chat Schemas
# ============================================================================

class ChatMessageSend(BaseModel):
    type: ChatType = ChatType.general
    message: str = Field(..., min_length=1, max_length=500)
    recipient_id: Optional[int] = None


class ChatMessageResponse(BaseSchema):
    id: int
    room_id: int
    sender_id: int
    sender_name: str
    sender_color: str
    recipient_id: Optional[int]
    type: ChatType
    message: str
    sent_at: datetime


# ============================================================================
# Game State Schemas
# ============================================================================

class PlayerGameState(BaseModel):
    id: int
    name: str
    color: str
    position: int
    status: PlayerStatus
    armies_in_hand: int
    countries_count: int
    total_armies: int
    cards_count: int
    cards: List[CardResponse]
    objective: Optional[PlayerObjectiveResponse] = None
    is_host: bool
    is_current_turn: bool


class GameStateResponse(BaseModel):
    room: RoomResponse
    current_phase: GamePhase
    current_turn_player_id: Optional[int]
    players: List[PlayerGameState]
    countries: List[GameCountryResponse]
    turn_number: int
    trade_count: int
    timer_expires_at: Optional[datetime] = None
    can_trade_cards: bool = False
    must_trade_cards: bool = False


# ============================================================================
# WebSocket Events
# ============================================================================

# Client -> Server events
class WSClientEvent(BaseModel):
    event: str
    data: Dict[str, Any] = {}


class WSJoinRoom(BaseModel):
    event: Literal["join_room"]
    data: dict = {}


class WSLeaveRoom(BaseModel):
    event: Literal["leave_room"]
    data: dict = {}


class WSStartGame(BaseModel):
    event: Literal["start_game"]
    data: dict = {}


class WSPlaceArmies(BaseModel):
    event: Literal["place_armies"]
    data: dict = {"country_id": 0}


class WSReinforce(BaseModel):
    event: Literal["reinforce"]
    data: ReinforceRequest


class WSAttack(BaseModel):
    event: Literal["attack"]
    data: AttackRequest


class WSFortify(BaseModel):
    event: Literal["fortify"]
    data: FortifyRequest


class WSTradeCards(BaseModel):
    event: Literal["trade_cards"]
    data: TradeCardsRequest


class WSEndTurn(BaseModel):
    event: Literal["end_turn"]
    data: dict = {}


class WSSendChat(BaseModel):
    event: Literal["send_chat"]
    data: ChatMessageSend


class WSRequestState(BaseModel):
    event: Literal["request_state"]
    data: dict = {}


class WSSpectate(BaseModel):
    event: Literal["spectate"]
    data: dict = {"player_name": ""}


# Union of all client events
WSClientEvents = WSJoinRoom | WSLeaveRoom | WSStartGame | WSPlaceArmies | WSReinforce | WSAttack | WSFortify | WSTradeCards | WSEndTurn | WSSendChat | WSRequestState | WSSpectate


# Server -> Client events
class WSServerEvent(BaseModel):
    event: str
    data: Dict[str, Any] = {}


class WSRoomUpdate(BaseModel):
    event: Literal["room_update"]
    data: RoomDetailResponse


class WSGameStarted(BaseModel):
    event: Literal["game_started"]
    data: GameStateResponse


class WSStateUpdate(BaseModel):
    event: Literal["state_update"]
    data: GameStateResponse


class WSTurnChange(BaseModel):
    event: Literal["turn_change"]
    data: dict = {
        "current_player_id": 0,
        "phase": GamePhase.reinforcement,
        "timer_expires_at": None,
        "turn_number": 0,
    }


class WSPhaseChange(BaseModel):
    event: Literal["phase_change"]
    data: dict = {"phase": GamePhase.reinforcement, "timer_expires_at": None}


class WSCombatResult(BaseModel):
    event: Literal["combat_result"]
    data: CombatResult


class WSCardDrawn(BaseModel):
    event: Literal["card_drawn"]
    data: GameCardResponse


class WSCardsTraded(BaseModel):
    event: Literal["cards_traded"]
    data: TradeCardsResponse


class WSObjectiveComplete(BaseModel):
    event: Literal["objective_complete"]
    data: PlayerObjectiveResponse


class WSGameOver(BaseModel):
    event: Literal["game_over"]
    data: dict = {"winner_id": 0, "winner_name": ""}


class WSChatMessage(BaseModel):
    event: Literal["chat_message"]
    data: ChatMessageResponse


class WSPlayerEliminated(BaseModel):
    event: Literal["player_eliminated"]
    data: dict = {"player_id": 0, "eliminated_by": 0, "conquered_countries": []}


class WSError(BaseModel):
    event: Literal["error"]
    data: dict = {"message": "", "code": ""}


# Union of all server events
WSServerEvents = WSRoomUpdate | WSGameStarted | WSStateUpdate | WSTurnChange | WSPhaseChange | WSCombatResult | WSCardDrawn | WSCardsTraded | WSObjectiveComplete | WSGameOver | WSChatMessage | WSPlayerEliminated | WSError


# ============================================================================
# Helper for forward references
# ============================================================================

RoomDetailResponse.model_rebuild()