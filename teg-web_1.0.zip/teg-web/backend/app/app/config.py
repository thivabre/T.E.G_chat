"""
TEG Web - Configuration Settings
"""

from pydantic_settings import BaseSettings
from typing import List, Optional
import os


class Settings(BaseSettings):
    # App
    APP_NAME: str = "TEG Web"
    DEBUG: bool = os.getenv("DEBUG", "true").lower() == "true"
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "mysql+aiomysql://teg_user:teg_password@mysql:3306/teg_web")
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20

    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # CORS
    CORS_ORIGINS: List[str] = ["*"]

    # WebSocket
    WS_HEARTBEAT_INTERVAL: int = 30  # seconds

    # Game Constants
    MIN_PLAYERS: int = 2
    MAX_PLAYERS: int = 6
    MAX_SPECTATORS: int = 50

    # Player Colors (6 players max)
    PLAYER_COLORS: List[str] = [
        "#e74c3c",  # Red
        "#3498db",  # Blue
        "#2ecc71",  # Green
        "#f1c40f",  # Yellow
        "#e67e22",  # Orange
        "#9b59b6",  # Purple
    ]

    # Turn Timer (configurable per room, in seconds)
    DEFAULT_TURN_TIME_LIMIT: int = 120
    MIN_TURN_TIME_LIMIT: int = 60
    MAX_TURN_TIME_LIMIT: int = 300

    # Card Trade Values (escalating)
    INITIAL_TRADE_VALUES: List[int] = [5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25]

    # Reinforcement
    MIN_REINFORCEMENT: int = 3
    COUNTRIES_PER_REINFORCEMENT: int = 3

    # Combat
    MAX_ATTACKER_DICE: int = 3
    MAX_DEFENDER_DICE: int = 2

    # Setup Phase
    INITIAL_ARMIES_PER_COUNTRY: int = 1

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
