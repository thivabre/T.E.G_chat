"""
TEG Web - WebSocket Connection Manager
Manages WebSocket connections per room, separating players and spectators
"""

import json
import asyncio
from typing import Dict, List, Set, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from fastapi import WebSocket

from .events import (
    ServerEvent, ServerEventType, serialize_event,
    RoomUpdatePayload, GameStartedPayload, StateUpdatePayload,
    TurnChangePayload, PhaseChangePayload, CombatResultPayload,
    CardDrawnPayload, CardsTradedPayload, ObjectiveCompletePayload,
    GameOverPayload, ChatMessagePayload, PlayerEliminatedPayload,
    ErrorPayload, PongPayload, TimerUpdatePayload
)


@dataclass(eq=False)
class Connection:
    """Represents a WebSocket connection with metadata."""
    websocket: WebSocket
    room_id: int
    player_id: Optional[int] = None
    spectator_id: Optional[int] = None
    is_spectator: bool = False
    connected_at: datetime = field(default_factory=datetime.utcnow)
    last_ping: datetime = field(default_factory=datetime.utcnow)


class ConnectionManager:
    """
    Manages WebSocket connections grouped by room.
    Separates players and spectators for targeted messaging.
    """

    def __init__(self):
        # room_id -> {player_id -> Connection}
        self.player_connections: Dict[int, Dict[int, Connection]] = {}
        # room_id -> {spectator_id -> Connection}
        self.spectator_connections: Dict[int, Dict[int, Connection]] = {}
        # room_id -> Set of all connections (for broadcasting)
        self.all_connections: Dict[int, Set[Connection]] = {}

    # ========================================================================
    # Connection Management
    # ========================================================================

    async def connect_player(
        self,
        websocket: WebSocket,
        room_id: int,
        player_id: int
    ) -> Connection:
        """Register a player connection."""
        await websocket.accept()

        conn = Connection(
            websocket=websocket,
            room_id=room_id,
            player_id=player_id,
            is_spectator=False
        )

        if room_id not in self.player_connections:
            self.player_connections[room_id] = {}
        if room_id not in self.all_connections:
            self.all_connections[room_id] = set()

        self.player_connections[room_id][player_id] = conn
        self.all_connections[room_id].add(conn)

        return conn

    async def connect_spectator(
        self,
        websocket: WebSocket,
        room_id: int,
        spectator_id: int
    ) -> Connection:
        """Register a spectator connection."""
        await websocket.accept()

        conn = Connection(
            websocket=websocket,
            room_id=room_id,
            spectator_id=spectator_id,
            is_spectator=True
        )

        if room_id not in self.spectator_connections:
            self.spectator_connections[room_id] = {}
        if room_id not in self.all_connections:
            self.all_connections[room_id] = set()

        self.spectator_connections[room_id][spectator_id] = conn
        self.all_connections[room_id].add(conn)

        return conn

    def disconnect(self, connection: Connection) -> None:
        """Remove a connection."""
        room_id = connection.room_id

        if connection.is_spectator and connection.spectator_id:
            if room_id in self.spectator_connections:
                self.spectator_connections[room_id].pop(connection.spectator_id, None)
        elif connection.player_id:
            if room_id in self.player_connections:
                self.player_connections[room_id].pop(connection.player_id, None)

        if room_id in self.all_connections:
            self.all_connections[room_id].discard(connection)

        # Cleanup empty rooms
        if room_id in self.all_connections and not self.all_connections[room_id]:
            del self.all_connections[room_id]
            self.player_connections.pop(room_id, None)
            self.spectator_connections.pop(room_id, None)

    # ========================================================================
    # Sending Messages
    # ========================================================================

    async def send_to_connection(self, connection: Connection, event: ServerEvent) -> bool:
        """Send an event to a specific connection. Returns success."""
        try:
            await connection.websocket.send_text(serialize_event(event))
            return True
        except Exception as e:
            print(f"Error sending to connection: {e}")
            return False

    async def send_to_player(self, room_id: int, player_id: int, event: ServerEvent) -> bool:
        """Send event to a specific player."""
        conn = self.player_connections.get(room_id, {}).get(player_id)
        if conn:
            return await self.send_to_connection(conn, event)
        return False

    async def send_to_spectator(self, room_id: int, spectator_id: int, event: ServerEvent) -> bool:
        """Send event to a specific spectator."""
        conn = self.spectator_connections.get(room_id, {}).get(spectator_id)
        if conn:
            return await self.send_to_connection(conn, event)
        return False

    async def broadcast_to_room(self, room_id: int, event: ServerEvent, exclude: Optional[Connection] = None) -> int:
        """Broadcast event to all connections in a room (players + spectators)."""
        sent = 0
        connections = self.all_connections.get(room_id, set()).copy()

        for conn in connections:
            if conn != exclude:
                if await self.send_to_connection(conn, event):
                    sent += 1
                else:
                    # Connection failed, schedule disconnect
                    self.disconnect(conn)

        return sent

    async def broadcast_to_players(self, room_id: int, event: ServerEvent, exclude_player: Optional[int] = None) -> int:
        """Broadcast event to all players in a room."""
        sent = 0
        players = self.player_connections.get(room_id, {})

        for player_id, conn in players.items():
            if player_id != exclude_player:
                if await self.send_to_connection(conn, event):
                    sent += 1
                else:
                    self.disconnect(conn)

        return sent

    async def broadcast_to_spectators(self, room_id: int, event: ServerEvent) -> int:
        """Broadcast event to all spectators in a room."""
        sent = 0
        spectators = self.spectator_connections.get(room_id, {})

        for conn in spectators.values():
            if await self.send_to_connection(conn, event):
                sent += 1
            else:
                self.disconnect(conn)

        return sent

    # ========================================================================
    # High-Level Event Helpers
    # ========================================================================

    async def send_room_update(
        self,
        room_id: int,
        room_data: Dict,
        players: List[Dict],
        spectators: List[Dict]
    ) -> None:
        """Send room update to all in room."""
        event = ServerEvent(
            event=ServerEventType.ROOM_UPDATE,
            data=RoomUpdatePayload(
                room=room_data,
                players=players,
                spectators=spectators
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_game_started(
        self,
        room_id: int,
        game_state: Dict
    ) -> None:
        """Send game started event to all in room."""
        event = ServerEvent(
            event=ServerEventType.GAME_STARTED,
            data=GameStartedPayload(**game_state).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_state_update(
        self,
        room_id: int,
        game_state: Dict
    ) -> None:
        """Send full state update to all in room."""
        event = ServerEvent(
            event=ServerEventType.STATE_UPDATE,
            data=StateUpdatePayload(**game_state).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_turn_change(
        self,
        room_id: int,
        current_player_id: int,
        current_player_name: str,
        current_player_color: str,
        phase: str,
        timer_expires_at: Optional[datetime],
        turn_number: int,
        reinforcement_armies: int
    ) -> None:
        """Send turn change to all in room."""
        event = ServerEvent(
            event=ServerEventType.TURN_CHANGE,
            data=TurnChangePayload(
                current_player_id=current_player_id,
                current_player_name=current_player_name,
                current_player_color=current_player_color,
                phase=phase,
                timer_expires_at=timer_expires_at,
                turn_number=turn_number,
                reinforcement_armies=reinforcement_armies
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_phase_change(
        self,
        room_id: int,
        phase: str,
        timer_expires_at: Optional[datetime]
    ) -> None:
        """Send phase change to all in room."""
        event = ServerEvent(
            event=ServerEventType.PHASE_CHANGE,
            data=PhaseChangePayload(
                phase=phase,
                timer_expires_at=timer_expires_at
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_combat_result(
        self,
        room_id: int,
        attacker_rolls: List[int],
        defender_rolls: List[int],
        attacker_losses: int,
        defender_losses: int,
        conquered: bool,
        attacker_remaining: int,
        defender_remaining: int,
        from_country_id: int,
        to_country_id: int
    ) -> None:
        """Send combat result to all in room."""
        event = ServerEvent(
            event=ServerEventType.COMBAT_RESULT,
            data=CombatResultPayload(
                attacker_rolls=attacker_rolls,
                defender_rolls=defender_rolls,
                attacker_losses=attacker_losses,
                defender_losses=defender_losses,
                conquered=conquered,
                attacker_remaining=attacker_remaining,
                defender_remaining=defender_remaining,
                from_country_id=from_country_id,
                to_country_id=to_country_id
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_card_drawn(
        self,
        room_id: int,
        card_data: Dict,
        player_id: int
    ) -> None:
        """Send card drawn event to all in room."""
        event = ServerEvent(
            event=ServerEventType.CARD_DRAWN,
            data=CardDrawnPayload(
                card=card_data,
                player_id=player_id
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_cards_traded(
        self,
        room_id: int,
        success: bool,
        armies_received: int,
        new_trade_count: int,
        cards_returned: List[Dict]
    ) -> None:
        """Send cards traded event to all in room."""
        event = ServerEvent(
            event=ServerEventType.CARDS_TRADED,
            data=CardsTradedPayload(
                success=success,
                armies_received=armies_received,
                new_trade_count=new_trade_count,
                cards_returned=cards_returned
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_objective_complete(
        self,
        room_id: int,
        player_id: int,
        player_name: str,
        objective: Dict,
        completed_at: datetime
    ) -> None:
        """Send objective complete to all in room."""
        event = ServerEvent(
            event=ServerEventType.OBJECTIVE_COMPLETE,
            data=ObjectiveCompletePayload(
                player_id=player_id,
                player_name=player_name,
                objective=objective,
                completed_at=completed_at
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_game_over(
        self,
        room_id: int,
        winner_id: int,
        winner_name: str,
        winner_color: str,
        game_mode: str
    ) -> None:
        """Send game over to all in room."""
        event = ServerEvent(
            event=ServerEventType.GAME_OVER,
            data=GameOverPayload(
                winner_id=winner_id,
                winner_name=winner_name,
                winner_color=winner_color,
                game_mode=game_mode
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_chat_message(
        self,
        room_id: int,
        message_data: Dict,
        exclude_sender: bool = True,
        sender_player_id: Optional[int] = None
    ) -> None:
        """Send chat message to room (or specific recipient for private)."""
        event = ServerEvent(
            event=ServerEventType.CHAT_MESSAGE,
            data=ChatMessagePayload(**message_data).model_dump()
        )

        if message_data.get("type") == "private":
            # Private message: send only to sender and recipient
            recipient_id = message_data.get("recipient_id")
            if sender_player_id:
                await self.send_to_player(room_id, sender_player_id, event)
            if recipient_id:
                await self.send_to_player(room_id, recipient_id, event)
        else:
            # General chat: broadcast to all
            await self.broadcast_to_room(room_id, event)

    async def send_player_eliminated(
        self,
        room_id: int,
        player_id: int,
        player_name: str,
        eliminated_by: int,
        eliminated_by_name: str,
        conquered_countries: List[int]
    ) -> None:
        """Send player eliminated event."""
        event = ServerEvent(
            event=ServerEventType.PLAYER_ELIMINATED,
            data=PlayerEliminatedPayload(
                player_id=player_id,
                player_name=player_name,
                eliminated_by=eliminated_by,
                eliminated_by_name=eliminated_by_name,
                conquered_countries=conquered_countries
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    async def send_error(
        self,
        connection: Connection,
        message: str,
        code: str,
        original_event: Optional[str] = None
    ) -> None:
        """Send error to a specific connection."""
        event = ServerEvent(
            event=ServerEventType.ERROR,
            data=ErrorPayload(
                message=message,
                code=code,
                original_event=original_event
            ).model_dump()
        )
        await self.send_to_connection(connection, event)

    async def send_pong(self, connection: Connection, client_timestamp: datetime) -> None:
        """Send pong response."""
        event = ServerEvent(
            event=ServerEventType.PONG,
            data=PongPayload(
                timestamp=client_timestamp,
                server_time=datetime.utcnow()
            ).model_dump()
        )
        await self.send_to_connection(connection, event)

    async def send_timer_update(
        self,
        room_id: int,
        time_remaining: int,
        phase: str,
        player_id: int
    ) -> None:
        """Send timer update to all in room."""
        event = ServerEvent(
            event=ServerEventType.TIMER_UPDATE,
            data=TimerUpdatePayload(
                time_remaining=time_remaining,
                phase=phase,
                player_id=player_id
            ).model_dump()
        )
        await self.broadcast_to_room(room_id, event)

    # ========================================================================
    # Connection Queries
    # ========================================================================

    def get_player_connection(self, room_id: int, player_id: int) -> Optional[Connection]:
        """Get a player's connection."""
        return self.player_connections.get(room_id, {}).get(player_id)

    def get_spectator_connection(self, room_id: int, spectator_id: int) -> Optional[Connection]:
        """Get a spectator's connection."""
        return self.spectator_connections.get(room_id, {}).get(spectator_id)

    def get_room_player_count(self, room_id: int) -> int:
        """Get number of connected players in a room."""
        return len(self.player_connections.get(room_id, {}))

    def get_room_spectator_count(self, room_id: int) -> int:
        """Get number of connected spectators in a room."""
        return len(self.spectator_connections.get(room_id, {}))

    def get_room_connections(self, room_id: int) -> List[Connection]:
        """Get all connections in a room."""
        return list(self.all_connections.get(room_id, []))

    def is_player_connected(self, room_id: int, player_id: int) -> bool:
        """Check if a player is connected."""
        return player_id in self.player_connections.get(room_id, {})

    # ========================================================================
    # Heartbeat
    # ========================================================================

    async def handle_ping(self, connection: Connection, timestamp: datetime) -> None:
        """Handle ping from client."""
        connection.last_ping = datetime.utcnow()
        await self.send_pong(connection, timestamp)

    async def check_stale_connections(self, timeout_seconds: int = 60) -> List[Connection]:
        """Find connections that haven't pinged recently."""
        stale = []
        now = datetime.utcnow()

        for connections in self.all_connections.values():
            for conn in connections:
                if (now - conn.last_ping).total_seconds() > timeout_seconds:
                    stale.append(conn)

        return stale


# Global manager instance
manager = ConnectionManager()