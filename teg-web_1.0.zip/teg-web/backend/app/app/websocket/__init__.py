"""
TEG Web - WebSocket Package
"""

from .manager import ConnectionManager, manager
from .events import ClientEvent, ServerEvent
from .handlers import WebSocketHandler

__all__ = [
    "ConnectionManager",
    "manager",
    "ClientEvent",
    "ServerEvent",
    "WebSocketHandler",
]