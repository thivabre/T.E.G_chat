"""
TEG Web - WebSocket Event Definitions
Defines all client->server and server->client event types
"""

from enum import Enum
from typing import Dict, Any, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime


# ============================================================================
# Event Types
# ============================================================================

class ClientEventType(str, Enum):
    """Events sent from client to server."""
    JOIN_ROOM = "join_room"
    LEAVE_ROOM = "leave_room"
    START_GAME = "start_game"
    PLACE_ARMIES = "place_armies"
    REINFORCE = "reinforce"
    ATTACK = "attack"
    FORTIFY = "fortify"
    TRADE_CARDS = "trade_cards"
    END_TURN = "end_turn"
    SEND_CHAT = "send_chat"
    REQUEST_STATE = "request_state"
    SPECTATE = "spectate"
    PING = "ping"


class ServerEventType(str, Enum):
    """Events sent from server to client."""
    ROOM_UPDATE = "room_update"
    GAME_STARTED = "game_started"
    STATE_UPDATE = "state_update"
    TURN_CHANGE = "turn_change"
    PHASE_CHANGE = "phase_change"
    COMBAT_RESULT = "combat_result"
    CARD_DRAWN = "card_drawn"
    CARDS_TRADED = "cards_traded"
    OBJECTIVE_COMPLETE = "objective_complete"
    GAME_OVER = "game_over"
    CHAT_MESSAGE = "chat_message"
    PLAYER_ELIMINATED = "player_eliminated"
    ERROR = "error"
    PONG = "pong"
    TIMER_UPDATE = "timer_update"


# ============================================================================
# Client -> Server Payloads
# ============================================================================

class JoinRoomPayload(BaseModel):
    room_id: int
    player_name: str
    as_spectator: bool = False


class LeaveRoomPayload(BaseModel):
    room_id: int


class StartGamePayload(BaseModel):
    room_id: int


class PlaceArmiesPayload(BaseModel):
    room_id: int
    country_id: int


class ReinforcePayload(BaseModel):
    room_id: int
    country_id: int
    armies: int = Field(..., ge=1)


class AttackPayload(BaseModel):
    room_id: int
    from_country_id: int
    to_country_id: int
    attacker_dice: int = Field(..., ge=1, le=3)


class FortifyPayload(BaseModel):
    room_id: int
    from_country_id: int
    to_country_id: int
    armies: int = Field(..., ge=1)


class TradeCardsPayload(BaseModel):
    room_id: int
    card_ids: list[int] = Field(..., min_length=3, max_length=3)


class EndTurnPayload(BaseModel):
    room_id: int


class SendChatPayload(BaseModel):
    room_id: int
    type: Literal["general", "private"] = "general"
    message: str = Field(..., min_length=1, max_length=500)
    recipient_id: Optional[int] = None


class RequestStatePayload(BaseModel):
    room_id: int


class SpectatePayload(BaseModel):
    room_id: int
    spectator_name: str


class PingPayload(BaseModel):
    timestamp: datetime


# ============================================================================
# Server -> Client Payloads
# ============================================================================

class RoomUpdatePayload(BaseModel):
    room: Dict[str, Any]  # RoomDetailResponse
    players: list[Dict[str, Any]]
    spectators: list[Dict[str, Any]]


class GameStartedPayload(BaseModel):
    room: Dict[str, Any]
    current_phase: str
    current_turn_player_id: int
    players: list[Dict[str, Any]]
    countries: list[Dict[str, Any]]
    continents: list[Dict[str, Any]] = []
    borders: list[Dict[str, Any]] = []
    map_svg: str = ""
    turn_number: int = 0
    trade_count: int = 0
    timer_expires_at: Optional[datetime] = None
    can_trade_cards: bool = False
    must_trade_cards: bool = False


class StateUpdatePayload(BaseModel):
    room: Dict[str, Any]
    current_phase: str
    current_turn_player_id: Optional[int]
    players: list[Dict[str, Any]]
    countries: list[Dict[str, Any]]
    turn_number: int
    trade_count: int
    timer_expires_at: Optional[datetime]
    can_trade_cards: bool
    must_trade_cards: bool


class TurnChangePayload(BaseModel):
    current_player_id: int
    current_player_name: str
    current_player_color: str
    phase: str
    timer_expires_at: Optional[datetime]
    turn_number: int
    reinforcement_armies: int


class PhaseChangePayload(BaseModel):
    phase: str
    timer_expires_at: Optional[datetime]


class CombatResultPayload(BaseModel):
    attacker_rolls: list[int]
    defender_rolls: list[int]
    attacker_losses: int
    defender_losses: int
    conquered: bool
    attacker_remaining: int
    defender_remaining: int
    from_country_id: int
    to_country_id: int


class CardDrawnPayload(BaseModel):
    card: Dict[str, Any]
    player_id: int


class CardsTradedPayload(BaseModel):
    success: bool
    armies_received: int
    new_trade_count: int
    cards_returned: list[Dict[str, Any]]


class ObjectiveCompletePayload(BaseModel):
    player_id: int
    player_name: str
    objective: Dict[str, Any]
    completed_at: datetime


class GameOverPayload(BaseModel):
    winner_id: int
    winner_name: str
    winner_color: str
    game_mode: str


class ChatMessagePayload(BaseModel):
    id: int
    sender_id: int
    sender_name: str
    sender_color: str
    recipient_id: Optional[int]
    type: Literal["general", "private"]
    message: str
    sent_at: datetime


class PlayerEliminatedPayload(BaseModel):
    player_id: int
    player_name: str
    eliminated_by: int
    eliminated_by_name: str
    conquered_countries: list[int]


class ErrorPayload(BaseModel):
    message: str
    code: str
    original_event: Optional[str] = None


class PongPayload(BaseModel):
    timestamp: datetime
    server_time: datetime


class TimerUpdatePayload(BaseModel):
    time_remaining: int
    phase: str
    player_id: int


# ============================================================================
# Event Wrapper Classes
# ============================================================================

class ClientEvent(BaseModel):
    """Wrapper for client events."""
    event: ClientEventType
    data: Dict[str, Any] = {}
    request_id: Optional[str] = None  # For request-response correlation


class ServerEvent(BaseModel):
    """Wrapper for server events."""
    event: ServerEventType
    data: Dict[str, Any] = {}
    request_id: Optional[str] = None  # Echo back for correlation


# ============================================================================
# Event Factory Functions
# ============================================================================

def create_client_event(event_type: ClientEventType, data: Dict[str, Any], request_id: str = None) -> ClientEvent:
    """Create a client event."""
    return ClientEvent(event=event_type, data=data, request_id=request_id)


def create_server_event(event_type: ServerEventType, data: Dict[str, Any], request_id: str = None) -> ServerEvent:
    """Create a server event."""
    return ServerEvent(event=event_type, data=data, request_id=request_id)


# ============================================================================
# Serialization Helpers
# ============================================================================

def serialize_event(event: ServerEvent) -> str:
    """Serialize a server event to JSON string."""
    return event.model_dump_json()


def deserialize_client_event(data: str) -> ClientEvent:
    """Deserialize a client event from JSON string."""
    return ClientEvent.model_validate_json(data)