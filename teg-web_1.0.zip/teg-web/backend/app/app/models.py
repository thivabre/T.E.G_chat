"""
TEG Web - SQLAlchemy ORM Models
Matches the database schema from init.sql
"""

import enum
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime, Enum, ForeignKey,
    UniqueConstraint, CheckConstraint, Index, func, ARRAY
)
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy.dialects.mysql import JSON

from .database import Base


# ============================================================================
# Enums
# ============================================================================

class RoomTypeEnum(str, enum.Enum):
    publica = "publica"
    privada = "privada"


class RoomStatusEnum(str, enum.Enum):
    waiting = "waiting"
    in_progress = "in_progress"
    finished = "finished"


class PlayerStatusEnum(str, enum.Enum):
    active = "active"
    eliminated = "eliminated"
    surrendered = "surrendered"


class GameModeEnum(str, enum.Enum):
    objetivos = "objetivos"
    conquista = "conquista"


class GamePhaseEnum(str, enum.Enum):
    setup = "setup"
    reinforcement = "reinforcement"
    attack = "attack"
    fortify = "fortify"
    trade_cards = "trade_cards"
    finished = "finished"


class CardTypeEnum(str, enum.Enum):
    infantry = "infantry"
    cavalry = "cavalry"
    artillery = "artillery"
    joker = "joker"


class ObjectiveTypeEnum(str, enum.Enum):
    occupation = "occupation"
    destruction = "destruction"


class ChatTypeEnum(str, enum.Enum):
    general = "general"
    private = "private"


# ============================================================================
# Models
# ============================================================================

class Continent(Base):
    __tablename__ = "continents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    bonus_armies: Mapped[int] = mapped_column(Integer, nullable=False)
    color: Mapped[str] = mapped_column(String(7), nullable=False)  # hex color

    countries= relationship("Country", back_populates="continent")


class Country(Base):
    __tablename__ = "countries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    continent_id: Mapped[int] = mapped_column(Integer, ForeignKey("continents.id"), nullable=False)
    svg_path: Mapped[str] = mapped_column(Text, nullable=False)
    x_coord: Mapped[int] = mapped_column(Integer, nullable=False)
    y_coord: Mapped[int] = mapped_column(Integer, nullable=False)

    continent= relationship("Continent", back_populates="countries")
    borders_from= relationship("Border", foreign_keys="Border.country_from_id", back_populates="country_from")
    borders_to= relationship("Border", foreign_keys="Border.country_to_id", back_populates="country_to")
    game_countries= relationship("GameCountry", back_populates="country")


class Border(Base):
    __tablename__ = "borders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    country_from_id: Mapped[int] = mapped_column(Integer, ForeignKey("countries.id"), nullable=False)
    country_to_id: Mapped[int] = mapped_column(Integer, ForeignKey("countries.id"), nullable=False)

    country_from= relationship("Country", foreign_keys=[country_from_id], back_populates="borders_from")
    country_to= relationship("Country", foreign_keys=[country_to_id], back_populates="borders_to")

    __table_args__ = (
        UniqueConstraint("country_from_id", "country_to_id", name="uq_border"),
    )


class Card(Base):
    __tablename__ = "cards"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    country_id: Mapped[int] = mapped_column(Integer, ForeignKey("countries.id"), nullable=False)
    type: Mapped[CardTypeEnum] = mapped_column(Enum(CardTypeEnum), nullable=False)

    country= relationship("Country")
    game_cards= relationship("GameCard", back_populates="card")


class Objective(Base):
    __tablename__ = "objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    type: Mapped[ObjectiveTypeEnum] = mapped_column(Enum(ObjectiveTypeEnum), nullable=False)
    target_count: Mapped[int] = mapped_column(Integer, default=0)
    target_continent_id: int = mapped_column(Integer, ForeignKey("continents.id"), nullable=True)
    target_player_color: str = mapped_column(String(20), nullable=True)  # For destruction objectives

    target_continent= relationship("Continent", foreign_keys=[target_continent_id])


class Room(Base):
    __tablename__ = "rooms"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(6), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    type: Mapped[RoomTypeEnum] = mapped_column(Enum(RoomTypeEnum), nullable=False, default=RoomTypeEnum.publica)
    status: Mapped[RoomStatusEnum] = mapped_column(Enum(RoomStatusEnum), nullable=False, default=RoomStatusEnum.waiting)
    max_players: Mapped[int] = mapped_column(Integer, nullable=False, default=6)
    game_mode: Mapped[GameModeEnum] = mapped_column(Enum(GameModeEnum), nullable=False, default=GameModeEnum.objetivos)
    turn_time_limit: Mapped[int] = mapped_column(Integer, nullable=False, default=0)  # 0 = no timer
    host_id: Mapped[int] = mapped_column(Integer, ForeignKey("players.id"), nullable=True)
    winner_id: int = mapped_column(Integer, ForeignKey("players.id"), nullable=True)
    current_turn_player_id: int = mapped_column(Integer, ForeignKey("players.id"), nullable=True)
    current_phase: Mapped[GamePhaseEnum] = mapped_column(Enum(GamePhaseEnum), nullable=False, default=GamePhaseEnum.setup)
    turn_number: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    trade_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=func.now())
    started_at: datetime = mapped_column(DateTime, nullable=True)
    finished_at: datetime = mapped_column(DateTime, nullable=True)

    host= relationship("Player", foreign_keys=[host_id])

    @property
    def host_name(self) -> str:
        return self.host.name if self.host else None
    winner= relationship("Player", foreign_keys=[winner_id])
    current_turn_player= relationship("Player", foreign_keys=[current_turn_player_id])
    players= relationship("Player", back_populates="room", foreign_keys="Player.room_id")
    spectators= relationship("Spectator", back_populates="room")
    game_countries= relationship("GameCountry", back_populates="room")
    game_cards= relationship("GameCard", back_populates="room")
    player_objectives= relationship("PlayerObjective", back_populates="room")
    chat_messages= relationship("ChatMessage", back_populates="room")
    turn_timers = relationship("TurnTimer", back_populates="room")


class Player(Base):
    __tablename__ = "players"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[int] = mapped_column(Integer, ForeignKey("rooms.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(50), nullable=False)
    color: Mapped[str] = mapped_column(String(7), nullable=False)  # hex color
    position: Mapped[int] = mapped_column(Integer, nullable=False)  # turn order
    status: Mapped[PlayerStatusEnum] = mapped_column(Enum(PlayerStatusEnum), nullable=False, default=PlayerStatusEnum.active)
    armies_in_hand: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    is_host: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_ready: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    joined_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=func.now())
    eliminated_at: datetime = mapped_column(DateTime, nullable=True)
    eliminated_by: int = mapped_column(Integer, ForeignKey("players.id"), nullable=True)

    room: Mapped["Room"] = relationship("Room", back_populates="players", foreign_keys=[room_id])
    game_countries= relationship("GameCountry", back_populates="player")
    game_cards= relationship("GameCard", back_populates="player")
    objectives= relationship("PlayerObjective", back_populates="player")
    sent_messages= relationship("ChatMessage", foreign_keys="ChatMessage.sender_id", back_populates="sender")
    received_messages= relationship("ChatMessage", foreign_keys="ChatMessage.recipient_id", back_populates="recipient")
    eliminated_by_player= relationship("Player", foreign_keys=[eliminated_by], remote_side=[id])

    __table_args__ = (
        UniqueConstraint("room_id", "name", name="uq_player_name_per_room"),
        UniqueConstraint("room_id", "position", name="uq_player_position_per_room"),
    )


class Spectator(Base):
    __tablename__ = "spectators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[int] = mapped_column(Integer, ForeignKey("rooms.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(50), nullable=False)
    joined_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=func.now())
    left_at: datetime = mapped_column(DateTime, nullable=True)

    room: Mapped["Room"] = relationship("Room", back_populates="spectators")

    __table_args__ = (
        UniqueConstraint("room_id", "name", name="uq_spectator_name_per_room"),
    )


class GameCountry(Base):
    __tablename__ = "game_countries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[int] = mapped_column(Integer, ForeignKey("rooms.id"), nullable=False, index=True)
    country_id: Mapped[int] = mapped_column(Integer, ForeignKey("countries.id"), nullable=False)
    player_id: int = mapped_column(Integer, ForeignKey("players.id"), nullable=True, index=True)
    armies: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    room: Mapped["Room"] = relationship("Room", back_populates="game_countries")
    country= relationship("Country", back_populates="game_countries")
    player= relationship("Player", back_populates="game_countries")

    __table_args__ = (
        UniqueConstraint("room_id", "country_id", name="uq_game_country"),
    )


class GameCard(Base):
    __tablename__ = "game_cards"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[int] = mapped_column(Integer, ForeignKey("rooms.id"), nullable=False, index=True)
    card_id: Mapped[int] = mapped_column(Integer, ForeignKey("cards.id"), nullable=False)
    player_id: int = mapped_column(Integer, ForeignKey("players.id"), nullable=True, index=True)
    in_deck: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    drawn_at: datetime = mapped_column(DateTime, nullable=True)

    room: Mapped["Room"] = relationship("Room", back_populates="game_cards")
    card: Mapped["Card"] = relationship("Card", back_populates="game_cards")
    player= relationship("Player", back_populates="game_cards")

    __table_args__ = (
        UniqueConstraint("room_id", "card_id", name="uq_game_card"),
    )


class PlayerObjective(Base):
    __tablename__ = "player_objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[int] = mapped_column(Integer, ForeignKey("rooms.id"), nullable=False, index=True)
    player_id: Mapped[int] = mapped_column(Integer, ForeignKey("players.id"), nullable=False)
    objective_id: Mapped[int] = mapped_column(Integer, ForeignKey("objectives.id"), nullable=False)
    completed: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    completed_at: datetime = mapped_column(DateTime, nullable=True)

    room: Mapped["Room"] = relationship("Room", back_populates="player_objectives")
    player= relationship("Player", back_populates="objectives")
    objective: Mapped["Objective"] = relationship("Objective")

    __table_args__ = (
        UniqueConstraint("room_id", "player_id", name="uq_player_objective"),
    )


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[int] = mapped_column(Integer, ForeignKey("rooms.id"), nullable=False, index=True)
    sender_id: Mapped[int] = mapped_column(Integer, ForeignKey("players.id"), nullable=False)
    recipient_id: int = mapped_column(Integer, ForeignKey("players.id"), nullable=True, index=True)
    type: Mapped[ChatTypeEnum] = mapped_column(Enum(ChatTypeEnum), nullable=False, default=ChatTypeEnum.general)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    sent_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=func.now())

    room: Mapped["Room"] = relationship("Room", back_populates="chat_messages")
    sender= relationship("Player", foreign_keys=[sender_id], back_populates="sent_messages")
    recipient= relationship("Player", foreign_keys=[recipient_id], back_populates="received_messages")


class TurnTimer(Base):
    __tablename__ = "turn_timers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    room_id: Mapped[int] = mapped_column(Integer, ForeignKey("rooms.id"), nullable=False, index=True)
    player_id: Mapped[int] = mapped_column(Integer, ForeignKey("players.id"), nullable=False)
    phase: Mapped[GamePhaseEnum] = mapped_column(Enum(GamePhaseEnum), nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=func.now())
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    room: Mapped["Room"] = relationship("Room", back_populates="turn_timers")
    player= relationship("Player")

    __table_args__ = (
        Index("idx_active_timer", "room_id", "is_active"),
    )


# ============================================================================
# Views (as models for querying)
# ============================================================================

class RoomSummary(Base):
    """View for lobby room listing."""
    __tablename__ = "v_room_summary"
    __table_args__ = {"info": {"is_view": True}}

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(6))
    name: Mapped[str] = mapped_column(String(100))
    type: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(20))
    max_players: Mapped[int] = mapped_column(Integer)
    game_mode: Mapped[str] = mapped_column(String(20))
    turn_time_limit: Mapped[int] = mapped_column(Integer)
    player_count: Mapped[int] = mapped_column(Integer)
    spectator_count: Mapped[int] = mapped_column(Integer)
    host_name: Mapped[str] = mapped_column(String(50))
    created_at: Mapped[datetime] = mapped_column(DateTime)


class GameState(Base):
    """View for current game state."""
    __tablename__ = "v_game_state"
    __table_args__ = {"info": {"is_view": True}}

    room_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    room_code: Mapped[str] = mapped_column(String(6))
    room_name: Mapped[str] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(20))
    game_mode: Mapped[str] = mapped_column(String(20))
    current_turn_player_id: int = mapped_column(Integer)
    current_turn_player_name: str = mapped_column(String(50))
    current_turn_player_color: str = mapped_column(String(7))
    current_phase: Mapped[str] = mapped_column(String(20))
    turn_number: Mapped[int] = mapped_column(Integer)
    trade_count: Mapped[int] = mapped_column(Integer)
    winner_name: str = mapped_column(String(50))


class PlayerSummary(Base):
    """View for player summary in a game."""
    __tablename__ = "v_player_summary"
    __table_args__ = {"info": {"is_view": True}}

    player_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    room_id: Mapped[int] = mapped_column(Integer)
    name: Mapped[str] = mapped_column(String(50))
    color: Mapped[str] = mapped_column(String(7))
    position: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20))
    armies_in_hand: Mapped[int] = mapped_column(Integer)
    countries_count: Mapped[int] = mapped_column(Integer)
    total_armies: Mapped[int] = mapped_column(Integer)
    cards_count: Mapped[int] = mapped_column(Integer)
    objective_description: str = mapped_column(Text)
    objective_completed: Mapped[bool] = mapped_column(Boolean)
    is_host: Mapped[bool] = mapped_column(Boolean)