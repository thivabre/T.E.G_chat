"""
TEG Web - Turn Manager
Handles turn progression, phases, and turn timer
"""

from datetime import datetime, timedelta
from typing import List, Optional, Tuple
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import (
    Room, Player, GameCountry, GamePhaseEnum, PlayerStatusEnum, TurnTimer
)
from ..config import settings
from .board import BoardManager
from .reinforcement import ReinforcementManager


class TurnManager:
    """Manages turn flow, phases, and timers."""

    def __init__(self, session: AsyncSession):
        self.session = session
        self.board_manager = BoardManager(session)
        self.reinforcement_manager = ReinforcementManager(session)

    # ========================================================================
    # Turn Initialization
    # ========================================================================

    async def start_game(self, room: Room) -> Tuple[Player, int]:
        """
        Start the game: determine first player, set initial phase.
        Returns (first_player, armies_for_first_turn).
        """
        # Get active players in turn order
        result = await self.session.execute(
            select(Player).where(
                Player.room_id == room.id,
                Player.status == PlayerStatusEnum.active
            ).order_by(Player.position)
        )
        players = result.scalars().all()

        if len(players) < 2:
            raise ValueError("Need at least 2 players to start")

        # First player is position 1
        first_player = players[0]

        # Update room state
        room.status = "in_progress"
        room.current_turn_player_id = first_player.id
        room.current_phase = GamePhaseEnum.setup
        room.turn_number = 1
        room.started_at = func.now()

        # Calculate initial armies for first player
        initial_armies = await self.reinforcement_manager.calculate_reinforcement(
            room.id, first_player.id
        )

        first_player.armies_in_hand = initial_armies

        # Start timer if enabled
        if room.turn_time_limit > 0:
            await self.start_turn_timer(room, first_player.id, GamePhaseEnum.setup)

        await self.session.flush()
        return first_player, initial_armies

    # ========================================================================
    # Phase Management
    # ========================================================================

    PHASE_ORDER = [
        GamePhaseEnum.reinforcement,
        GamePhaseEnum.attack,
        GamePhaseEnum.fortify,
    ]

    async def next_phase(self, room: Room, player: Player) -> GamePhaseEnum:
        """Advance to the next phase for the current player."""
        current_idx = self.PHASE_ORDER.index(room.current_phase) if room.current_phase in self.PHASE_ORDER else -1
        next_idx = (current_idx + 1) % len(self.PHASE_ORDER)
        next_phase = self.PHASE_ORDER[next_idx]

        room.current_phase = next_phase

        # Handle phase-specific logic
        if next_phase == GamePhaseEnum.reinforcement:
            # Calculate and grant reinforcement armies
            armies = await self.reinforcement_manager.calculate_reinforcement(room.id, player.id)
            player.armies_in_hand = armies

            # Check for mandatory card trade
            # (handled separately via can_trade/must_trade flags)

        # Update timer
        if room.turn_time_limit > 0:
            await self.start_turn_timer(room, player.id, next_phase)
        else:
            await self.clear_turn_timer(room.id)

        await self.session.flush()
        return next_phase

    async def end_turn(self, room: Room) -> Tuple[Player, GamePhaseEnum, int]:
        """
        End current player's turn, move to next player.
        Returns (next_player, next_phase, reinforcement_armies).
        """
        # Clear current timer
        await self.clear_turn_timer(room.id)

        # Get active players in order
        result = await self.session.execute(
            select(Player).where(
                Player.room_id == room.id,
                Player.status == PlayerStatusEnum.active
            ).order_by(Player.position)
        )
        players = result.scalars().all()

        if not players:
            raise ValueError("No active players")

        # Find current player index
        current_idx = next(
            (i for i, p in enumerate(players) if p.id == room.current_turn_player_id),
            0
        )

        # Next player
        next_idx = (current_idx + 1) % len(players)
        next_player = players[next_idx]

        # Update room
        room.current_turn_player_id = next_player.id
        room.current_phase = GamePhaseEnum.reinforcement
        room.turn_number += 1

        # Calculate reinforcement for next player
        armies = await self.reinforcement_manager.calculate_reinforcement(room.id, next_player.id)
        next_player.armies_in_hand = armies

        # Start timer for next player
        if room.turn_time_limit > 0:
            await self.start_turn_timer(room, next_player.id, GamePhaseEnum.reinforcement)

        await self.session.flush()
        return next_player, GamePhaseEnum.reinforcement, armies

    async def skip_to_fortify(self, room: Room, player: Player) -> GamePhaseEnum:
        """Skip attack phase, go directly to fortify."""
        room.current_phase = GamePhaseEnum.fortify

        if room.turn_time_limit > 0:
            await self.start_turn_timer(room, player.id, GamePhaseEnum.fortify)
        else:
            await self.clear_turn_timer(room.id)

        await self.session.flush()
        return GamePhaseEnum.fortify

    # ========================================================================
    # Turn Timer
    # ========================================================================

    async def start_turn_timer(self, room: Room, player_id: int, phase: GamePhaseEnum) -> TurnTimer:
        """Start a turn timer for a player in a specific phase."""
        # Clear any existing timer
        await self.clear_turn_timer(room.id)

        expires_at = datetime.utcnow() + timedelta(seconds=room.turn_time_limit)

        timer = TurnTimer(
            room_id=room.id,
            player_id=player_id,
            phase=phase,
            started_at=func.now(),
            expires_at=expires_at,
            is_active=True
        )
        self.session.add(timer)
        await self.session.flush()
        return timer

    async def clear_turn_timer(self, room_id: int) -> None:
        """Deactivate all timers for a room."""
        result = await self.session.execute(
            select(TurnTimer).where(
                TurnTimer.room_id == room_id,
                TurnTimer.is_active == True
            )
        )
        timers = result.scalars().all()
        for t in timers:
            t.is_active = False
        await self.session.flush()

    async def get_turn_timer(self, room_id: int) -> Optional[TurnTimer]:
        """Get the active turn timer for a room."""
        result = await self.session.execute(
            select(TurnTimer).where(
                TurnTimer.room_id == room_id,
                TurnTimer.is_active == True
            ).order_by(TurnTimer.id.desc())
        )
        return result.scalar_one_or_none()

    async def check_timer_expired(self, room_id: int) -> bool:
        """Check if the current turn timer has expired."""
        timer = await self.get_turn_timer(room_id)
        if not timer:
            return False

        if datetime.utcnow() >= timer.expires_at:
            timer.is_active = False
            await self.session.flush()
            return True

        return False

    async def get_time_remaining(self, room_id: int) -> Optional[int]:
        """Get seconds remaining on current timer."""
        timer = await self.get_turn_timer(room_id)
        if not timer:
            return None

        remaining = (timer.expires_at - datetime.utcnow()).total_seconds()
        return max(0, int(remaining))

    # ========================================================================
    # Setup Phase
    # ========================================================================

    async def is_setup_complete(self, room: Room) -> bool:
        """Check if all countries have been claimed (setup phase done)."""
        result = await self.session.execute(
            select(func.count(GameCountry.id)).where(
                GameCountry.room_id == room.id,
                GameCountry.player_id.is_(None)
            )
        )
        unclaimed = result.scalar() or 0
        return unclaimed == 0

    async def complete_setup(self, room: Room) -> Tuple[Player, int]:
        """Transition from setup to first reinforcement phase."""
        # Get first player (already set in start_game)
        result = await self.session.execute(
            select(Player).where(Player.id == room.current_turn_player_id)
        )
        player = result.scalar_one()

        room.current_phase = GamePhaseEnum.reinforcement

        # Calculate reinforcement
        armies = await self.reinforcement_manager.calculate_reinforcement(room.id, player.id)
        player.armies_in_hand = armies

        # Start timer
        if room.turn_time_limit > 0:
            await self.start_turn_timer(room, player.id, GamePhaseEnum.reinforcement)

        await self.session.flush()
        return player, armies

    # ========================================================================
    # Valid Actions per Phase
    # ========================================================================

    def get_valid_actions(self, phase: GamePhaseEnum, player: Player, room: Room) -> List[str]:
        """Get list of valid actions for the current phase."""
        actions = []

        if phase == GamePhaseEnum.setup:
            actions.append("place_army")
        elif phase == GamePhaseEnum.reinforcement:
            if player.armies_in_hand > 0:
                actions.append("reinforce")
            actions.append("end_reinforcement")  # Can end early
            # Check card trading
            actions.append("trade_cards")  # Will validate server-side
        elif phase == GamePhaseEnum.attack:
            actions.append("attack")
            actions.append("end_attack")
        elif phase == GamePhaseEnum.fortify:
            actions.append("fortify")
            actions.append("end_turn")

        return actions

    def can_perform_action(self, phase: GamePhaseEnum, action: str, player: Player, room: Room) -> Tuple[bool, str]:
        """Check if a player can perform a specific action in the current phase."""
        if phase == GamePhaseEnum.setup:
            if action == "place_army":
                return True, ""
            return False, "Solo puedes colocar ejércitos en la fase de preparación"

        if phase == GamePhaseEnum.reinforcement:
            if action == "reinforce":
                if player.armies_in_hand > 0:
                    return True, ""
                return False, "No tienes ejércitos para colocar"
            if action == "trade_cards":
                return True, ""  # Validated in card manager
            if action == "end_reinforcement":
                return True, ""
            return False, "Acción no válida en fase de refuerzo"

        if phase == GamePhaseEnum.attack:
            if action in ("attack", "end_attack"):
                return True, ""
            return False, "Acción no válida en fase de ataque"

        if phase == GamePhaseEnum.fortify:
            if action in ("fortify", "end_turn"):
                return True, ""
            return False, "Acción no válida en fase de fortificación"

        return False, "Fase no reconocida"

    # ========================================================================
    # Player Order Helpers
    # ========================================================================

    async def get_turn_order(self, room_id: int) -> List[Player]:
        """Get active players in turn order."""
        result = await self.session.execute(
            select(Player).where(
                Player.room_id == room_id,
                Player.status == PlayerStatusEnum.active
            ).order_by(Player.position)
        )
        return result.scalars().all()

    async def get_next_player(self, room: Room) -> Optional[Player]:
        """Get the player who plays after the current one."""
        players = await self.get_turn_order(room.id)
        if not players:
            return None

        current_idx = next(
            (i for i, p in enumerate(players) if p.id == room.current_turn_player_id),
            0
        )
        next_idx = (current_idx + 1) % len(players)
        return players[next_idx]

    async def get_previous_player(self, room: Room) -> Optional[Player]:
        """Get the player who played before the current one."""
        players = await self.get_turn_order(room.id)
        if not players:
            return None

        current_idx = next(
            (i for i, p in enumerate(players) if p.id == room.current_turn_player_id),
            0
        )
        prev_idx = (current_idx - 1) % len(players)
        return players[prev_idx]