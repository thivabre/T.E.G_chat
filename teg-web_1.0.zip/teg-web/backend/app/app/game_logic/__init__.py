"""
TEG Web - Game Logic Package
"""

from .board import BoardManager
from .cards import CardManager
from .combat import CombatManager
from .objectives import ObjectiveManager
from .turns import TurnManager
from .reinforcement import ReinforcementManager

__all__ = [
    "BoardManager",
    "CardManager",
    "CombatManager",
    "ObjectiveManager",
    "TurnManager",
    "ReinforcementManager",
]