"""
TEG Web - Combat Manager
Handles dice rolling and combat resolution (Risk/TEG rules)
"""

import random
from typing import List, Tuple, Optional
from dataclasses import dataclass

from ..config import settings


@dataclass
class CombatRoll:
    """Result of a single combat roll."""
    attacker_rolls: List[int]
    defender_rolls: List[int]
    attacker_losses: int
    defender_losses: int


@dataclass
class CombatResult:
    """Final result of a combat sequence."""
    rolls: List[CombatRoll]
    total_attacker_losses: int
    total_defender_losses: int
    conquered: bool
    attacker_remaining: int
    defender_remaining: int


class CombatManager:
    """Manages combat resolution using standard Risk/TEG dice rules."""

    MAX_ATTACKER_DICE = settings.MAX_ATTACKER_DICE  # 3
    MAX_DEFENDER_DICE = settings.MAX_DEFENDER_DICE  # 2

    def __init__(self):
        pass

    def roll_dice(self, count: int) -> List[int]:
        """Roll 'count' dice (1-6), return sorted descending."""
        rolls = [random.randint(1, 6) for _ in range(count)]
        return sorted(rolls, reverse=True)

    def resolve_round(self, attacker_dice: int, defender_dice: int) -> CombatRoll:
        """
        Resolve a single round of combat.
        Rules:
        - Attacker rolls up to 3 dice (must have at least attacker_dice + 1 armies)
        - Defender rolls up to 2 dice (must have at least defender_dice armies)
        - Compare highest die, then second highest
        - Defender wins ties
        """
        # Clamp to valid ranges
        attacker_dice = max(1, min(attacker_dice, self.MAX_ATTACKER_DICE))
        defender_dice = max(1, min(defender_dice, self.MAX_DEFENDER_DICE))

        # Roll dice
        attacker_rolls = self.roll_dice(attacker_dice)
        defender_rolls = self.roll_dice(defender_dice)

        # Compare pairs
        attacker_losses = 0
        defender_losses = 0

        pairs = min(len(attacker_rolls), len(defender_rolls))
        for i in range(pairs):
            if attacker_rolls[i] > defender_rolls[i]:
                defender_losses += 1
            else:
                # Defender wins ties
                attacker_losses += 1

        return CombatRoll(
            attacker_rolls=attacker_rolls,
            defender_rolls=defender_rolls,
            attacker_losses=attacker_losses,
            defender_losses=defender_losses
        )

    def simulate_combat(
        self,
        attacker_armies: int,
        defender_armies: int,
        max_attacker_dice: Optional[int] = None,
        max_defender_dice: Optional[int] = None
    ) -> CombatResult:
        """
        Simulate full combat until attacker stops or one side eliminated.
        Note: In actual game, attacker chooses dice each round.
        This simulates with maximum dice each round.
        """
        if max_attacker_dice is None:
            max_attacker_dice = self.MAX_ATTACKER_DICE
        if max_defender_dice is None:
            max_defender_dice = self.MAX_DEFENDER_DICE

        rolls = []
        total_attacker_losses = 0
        total_defender_losses = 0

        current_attacker = attacker_armies
        current_defender = defender_armies

        while current_attacker > 1 and current_defender > 0:
            # Attacker can use up to 3 dice, but must leave at least 1 army behind
            # So max dice = min(3, current_attacker - 1)
            a_dice = min(max_attacker_dice, current_attacker - 1)
            # Defender can use up to 2 dice
            d_dice = min(max_defender_dice, current_defender)

            if a_dice <= 0 or d_dice <= 0:
                break

            roll = self.resolve_round(a_dice, d_dice)
            rolls.append(roll)

            total_attacker_losses += roll.attacker_losses
            total_defender_losses += roll.defender_losses

            current_attacker -= roll.attacker_losses
            current_defender -= roll.defender_losses

        conquered = current_defender <= 0
        attacker_remaining = max(1, current_attacker)  # At least 1 must stay
        defender_remaining = max(0, current_defender)

        return CombatResult(
            rolls=rolls,
            total_attacker_losses=total_attacker_losses,
            total_defender_losses=total_defender_losses,
            conquered=conquered,
            attacker_remaining=attacker_remaining,
            defender_remaining=defender_remaining
        )

    def calculate_max_attacker_dice(self, armies: int) -> int:
        """Calculate max dice attacker can use given their armies."""
        # Must leave at least 1 army behind
        return min(self.MAX_ATTACKER_DICE, max(1, armies - 1))

    def calculate_max_defender_dice(self, armies: int) -> int:
        """Calculate max dice defender can use given their armies."""
        return min(self.MAX_DEFENDER_DICE, armies)

    def validate_attack(self, attacker_armies: int, defender_armies: int, attacker_dice: int) -> Tuple[bool, str]:
        """
        Validate an attack action.
        Returns (is_valid, error_message).
        """
        if attacker_armies < 2:
            return False, "Necesitas al menos 2 ejércitos para atacar (uno debe quedar)"

        if defender_armies < 1:
            return False, "El territorio defensor no tiene ejércitos"

        max_attack_dice = self.calculate_max_attacker_dice(attacker_armies)
        if attacker_dice < 1 or attacker_dice > max_attack_dice:
            return False, f"Dados de ataque inválidos (1-{max_attack_dice})"

        max_defend_dice = self.calculate_max_defender_dice(defender_armies)
        # Defender dice is determined by defender's armies, not attacker's choice

        return True, ""

    def get_combat_preview(
        self,
        attacker_armies: int,
        defender_armies: int,
        attacker_dice: int
    ) -> dict:
        """
        Get a preview of possible outcomes for UI display.
        Returns probabilities for different outcomes.
        """
        # This is a simplified preview - in practice you'd run many simulations
        max_defender_dice = self.calculate_max_defender_dice(defender_armies)

        # Run a few simulations to estimate
        wins = 0
        losses = 0
        simulations = 1000

        for _ in range(simulations):
            result = self.simulate_combat(
                attacker_armies,
                defender_armies,
                max_attacker_dice=attacker_dice,
                max_defender_dice=max_defender_dice
            )
            if result.conquered:
                wins += 1
            else:
                losses += 1

        return {
            "attacker_armies": attacker_armies,
            "defender_armies": defender_armies,
            "attacker_dice": attacker_dice,
            "defender_dice": max_defender_dice,
            "win_probability": wins / simulations,
            "loss_probability": losses / simulations,
            "expected_attacker_remaining": attacker_armies * (wins / simulations) + 1 * (losses / simulations),
        }


# Singleton instance
combat_manager = CombatManager()