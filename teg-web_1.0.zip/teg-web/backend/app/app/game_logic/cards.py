"""
TEG Web - Card Manager
Handles card deck, drawing, trading, and escalating trade values
"""

import random
from typing import List, Optional, Tuple, Dict, Set
from dataclasses import dataclass
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import Room, Player, GameCard, Card, CardTypeEnum, GamePhaseEnum
from ..config import settings


@dataclass
class CardSet:
    """Represents a valid set of 3 cards for trading."""
    card_ids: List[int]
    set_type: str  # "three_same", "three_different", "with_joker"
    card_types: List[CardTypeEnum]


class CardManager:
    """Manages card operations: deck, drawing, trading."""

    # Escalating trade values: 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25...
    TRADE_VALUES = settings.INITIAL_TRADE_VALUES

    def __init__(self, session: AsyncSession):
        self.session = session

    # ========================================================================
    # Deck Operations
    # ========================================================================

    async def get_deck(self, room_id: int) -> List[GameCard]:
        """Get all cards currently in the deck (in_deck=True, player_id=None)."""
        result = await self.session.execute(
            select(GameCard).where(
                GameCard.room_id == room_id,
                GameCard.in_deck == True,
                GameCard.player_id.is_(None)
            ).order_by(GameCard.id)
        )
        return result.scalars().all()

    async def get_discard_pile(self, room_id: int) -> List[GameCard]:
        """Get cards that have been traded in (in_deck=True, but were previously held)."""
        result = await self.session.execute(
            select(GameCard).where(
                GameCard.room_id == room_id,
                GameCard.in_deck == True,
                GameCard.player_id.is_not(None)  # Were held by a player
            ).order_by(GameCard.drawn_at.desc())
        )
        return result.scalars().all()

    async def get_player_cards(self, room_id: int, player_id: int) -> List[GameCard]:
        """Get all cards held by a player."""
        result = await self.session.execute(
            select(GameCard).where(
                GameCard.room_id == room_id,
                GameCard.player_id == player_id,
                GameCard.in_deck == False
            ).order_by(GameCard.drawn_at)
        )
        return result.scalars().all()

    async def shuffle_deck(self, room_id: int) -> None:
        """Shuffle the deck by randomizing card order."""
        deck = await self.get_deck(room_id)
        if not deck:
            return

        card_ids = [c.id for c in deck]
        random.shuffle(card_ids)

        # Reassign IDs to randomize draw order
        for i, gc in enumerate(deck):
            gc.id = card_ids[i]  # This is a hack - better to add a sort_order column

        await self.session.flush()

    # ========================================================================
    # Drawing Cards
    # ========================================================================

    async def draw_card(self, room_id: int, player_id: int) -> Optional[GameCard]:
        """
        Draw a card from the deck for a player.
        Returns the drawn GameCard with card details loaded.
        """
        deck = await self.get_deck(room_id)

        if not deck:
            # Reshuffle discard pile into deck
            await self._reshuffle_discard(room_id)
            deck = await self.get_deck(room_id)

        if not deck:
            return None  # No cards at all (shouldn't happen)

        # Draw the first card
        drawn = deck[0]
        drawn.player_id = player_id
        drawn.in_deck = False
        drawn.drawn_at = func.now()

        await self.session.flush()

        # Load the card relationship
        await self.session.refresh(drawn, ["card"])
        return drawn

    async def _reshuffle_discard(self, room_id: int) -> None:
        """Move discard pile back into deck and shuffle."""
        discard = await self.get_discard_pile(room_id)

        for gc in discard:
            gc.player_id = None
            gc.in_deck = True
            gc.drawn_at = None

        await self.session.flush()
        await self.shuffle_deck(room_id)

    # ========================================================================
    # Card Trading
    # ========================================================================

    def validate_card_set(self, cards: List[GameCard]) -> Tuple[bool, str, Optional[CardSet]]:
        """
        Validate if 3 cards form a valid set for trading.
        Returns (is_valid, error_message, CardSet if valid).
        """
        if len(cards) != 3:
            return False, "Se requieren exactamente 3 cartas", None

        card_types = [c.card.type for c in cards]

        # Count jokers
        joker_count = card_types.count(CardTypeEnum.joker)
        non_joker_types = [t for t in card_types if t != CardTypeEnum.joker]

        # Case 1: Three of a kind (with or without jokers)
        if len(set(non_joker_types)) == 1:
            if len(non_joker_types) >= 1:  # At least one non-joker
                set_type = "three_same"
                if joker_count > 0:
                    set_type = "with_joker"
                return True, "", CardSet(
                    card_ids=[c.id for c in cards],
                    set_type=set_type,
                    card_types=card_types
                )

        # Case 2: Three different (infantry, cavalry, artillery)
        # Jokers can substitute for missing types
        unique_types = set(non_joker_types)
        required = {CardTypeEnum.infantry, CardTypeEnum.cavalry, CardTypeEnum.artillery}
        missing = required - unique_types

        if len(missing) <= joker_count:
            return True, "", CardSet(
                card_ids=[c.id for c in cards],
                set_type="three_different",
                card_types=card_types
            )

        return False, "Las cartas no forman un conjunto válido (3 iguales, 3 diferentes, o con comodín)", None

    def calculate_trade_value(self, trade_count: int) -> int:
        """Calculate armies received for a trade based on trade count."""
        if trade_count < len(self.TRADE_VALUES):
            return self.TRADE_VALUES[trade_count]
        # After the list, increase by 5 each time (25, 30, 35, 40...)
        return self.TRADE_VALUES[-1] + (trade_count - len(self.TRADE_VALUES) + 1) * 5

    async def trade_cards(self, room_id: int, player_id: int, card_ids: List[int]) -> Tuple[bool, str, int, List[GameCard]]:
        """
        Trade in a set of 3 cards for armies.
        Returns (success, message, armies_received, returned_cards).
        """
        # Get the cards
        result = await self.session.execute(
            select(GameCard).where(
                GameCard.room_id == room_id,
                GameCard.id.in_(card_ids),
                GameCard.player_id == player_id,
                GameCard.in_deck == False
            )
        )
        cards = result.scalars().all()

        if len(cards) != 3:
            return False, "No tienes esas 3 cartas", 0, []

        # Load card details
        for c in cards:
            await self.session.refresh(c, ["card"])

        # Validate set
        valid, msg, card_set = self.validate_card_set(cards)
        if not valid:
            return False, msg, 0, []

        # Calculate trade value
        room_result = await self.session.execute(select(Room).where(Room.id == room_id))
        room = room_result.scalar_one()

        armies = self.calculate_trade_value(room.trade_count)

        # Return cards to deck (discard pile)
        returned_cards = []
        for gc in cards:
            gc.player_id = None
            gc.in_deck = True
            gc.drawn_at = None
            returned_cards.append(gc)

        # Increment trade count
        room.trade_count += 1

        await self.session.flush()

        return True, f"¡Canjeaste cartas por {armies} ejércitos!", armies, returned_cards

    async def can_trade_cards(self, room_id: int, player_id: int) -> Tuple[bool, str]:
        """Check if player can/must trade cards."""
        player_cards = await self.get_player_cards(room_id, player_id)

        if len(player_cards) < 3:
            return False, "Necesitas al menos 3 cartas"

        if len(player_cards) >= 5:
            return True, "Debes canjear cartas (tienes 5 o más)"

        # Check if any valid combination exists
        from itertools import combinations
        for combo in combinations(player_cards, 3):
            for c in combo:
                await self.session.refresh(c, ["card"])
            valid, _, _ = self.validate_card_set(list(combo))
            if valid:
                return True, "Puedes canjear cartas"

        return False, "No tienes un conjunto válido de 3 cartas"

    async def get_valid_trade_combinations(self, room_id: int, player_id: int) -> List[List[int]]:
        """Get all valid 3-card combinations for trading."""
        player_cards = await self.get_player_cards(room_id, player_id)

        # Load card details
        for c in player_cards:
            await self.session.refresh(c, ["card"])

        from itertools import combinations
        valid_combos = []

        for combo in combinations(player_cards, 3):
            valid, _, _ = self.validate_card_set(list(combo))
            if valid:
                valid_combos.append([c.id for c in combo])

        return valid_combos

    # ========================================================================
    # Card Info for UI
    # ========================================================================

    async def get_card_display_info(self, game_card: GameCard) -> Dict:
        """Get display info for a game card."""
        await self.session.refresh(game_card, ["card", "card.country"])
        card = game_card.card

        type_labels = {
            CardTypeEnum.infantry: "Infantería",
            CardTypeEnum.cavalry: "Caballería",
            CardTypeEnum.artillery: "Artillería",
            CardTypeEnum.joker: "Comodín",
        }

        type_icons = {
            CardTypeEnum.infantry: "👣",
            CardTypeEnum.cavalry: "🐎",
            CardTypeEnum.artillery: "💣",
            CardTypeEnum.joker: "⭐",
        }

        return {
            "id": game_card.id,
            "card_id": card.id,
            "country_name": card.country.name,
            "type": card.type.value,
            "type_label": type_labels[card.type],
            "type_icon": type_icons[card.type],
            "continent": card.country.continent_id,  # Would need continent name
        }