"""
TEG Web - Reinforcement Manager
Calculates reinforcement armies based on territories, continents, and cards
"""

from typing import Dict, List, Set, Tuple
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import (
    Room, Player, GameCountry, Country, Continent, GameCard, Card, CardTypeEnum,
    PlayerStatusEnum
)
from ..config import settings


class ReinforcementManager:
    """Calculates reinforcement armies for players."""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def calculate_reinforcement(self, room_id: int, player_id: int) -> int:
        """
        Calculate total reinforcement armies for a player.
        Formula: max(3, countries/3) + continent bonuses
        """
        # Get player's countries
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            )
        )
        countries = result.scalars().all()

        country_count = len(countries)

        # Base armies from countries (min 3)
        base_armies = max(settings.MIN_REINFORCEMENT, country_count // settings.COUNTRIES_PER_REINFORCEMENT)

        # Continent bonuses
        continent_bonus = await self._calculate_continent_bonus(room_id, player_id)

        total = base_armies + continent_bonus
        return total

    async def _calculate_continent_bonus(self, room_id: int, player_id: int) -> int:
        """Calculate bonus armies from controlled continents."""
        # Get player's countries with continent info
        result = await self.session.execute(
            select(GameCountry, Country.continent_id).join(
                Country, GameCountry.country_id == Country.id
            ).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            )
        )
        player_territories = result.all()

        # Count countries per continent
        continent_counts: Dict[int, int] = {}
        for gc, cont_id in player_territories:
            continent_counts[cont_id] = continent_counts.get(cont_id, 0) + 1

        # Get total countries per continent
        cont_result = await self.session.execute(
            select(Country.continent_id, func.count(Country.id)).group_by(Country.continent_id)
        )
        continent_totals = {row[0]: row[1] for row in cont_result.all()}

        # Check which continents are fully controlled
        bonus = 0
        for cont_id, count in continent_counts.items():
            if count == continent_totals.get(cont_id, 0):
                # Get continent bonus
                cont = await self.session.get(Continent, cont_id)
                if cont:
                    bonus += cont.bonus_armies

        return bonus

    async def get_reinforcement_breakdown(self, room_id: int, player_id: int) -> Dict:
        """Get detailed breakdown of reinforcement calculation."""
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            )
        )
        countries = result.scalars().all()

        country_count = len(countries)
        base_armies = max(settings.MIN_REINFORCEMENT, country_count // settings.COUNTRIES_PER_REINFORCEMENT)

        # Continent details
        result = await self.session.execute(
            select(GameCountry, Country.continent_id, Country.name).join(
                Country, GameCountry.country_id == Country.id
            ).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            )
        )
        player_territories = result.all()

        continent_counts: Dict[int, int] = {}
        continent_names: Dict[int, str] = {}
        for gc, cont_id, cont_name in player_territories:
            continent_counts[cont_id] = continent_counts.get(cont_id, 0) + 1
            continent_names[cont_id] = cont_name

        cont_result = await self.session.execute(
            select(Continent.id, Continent.name, Continent.bonus_armies, func.count(Country.id)).join(
                Country, Continent.id == Country.continent_id
            ).group_by(Continent.id, Continent.name, Continent.bonus_armies)
        )
        all_continents = cont_result.all()

        continent_details = []
        total_bonus = 0

        for cont_id, cont_name, bonus, total in all_continents:
            owned = continent_counts.get(cont_id, 0)
            controlled = owned == total
            if controlled:
                total_bonus += bonus

            continent_details.append({
                "id": cont_id,
                "name": cont_name,
                "bonus": bonus,
                "owned": owned,
                "total": total,
                "controlled": controlled,
            })

        return {
            "country_count": country_count,
            "base_armies": base_armies,
            "continent_bonus": total_bonus,
            "total": base_armies + total_bonus,
            "continents": continent_details,
        }

    async def validate_reinforcement(self, room_id: int, player_id: int, country_id: int, armies: int) -> Tuple[bool, str]:
        """
        Validate a reinforcement action.
        Returns (is_valid, error_message).
        """
        # Check player has armies in hand
        player = await self.session.get(Player, player_id)
        if not player:
            return False, "Jugador no encontrado"

        if player.armies_in_hand < armies:
            return False, f"Solo tienes {player.armies_in_hand} ejércitos disponibles"

        # Check country belongs to player
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.country_id == country_id,
                GameCountry.player_id == player_id
            )
        )
        gc = result.scalar_one_or_none()

        if not gc:
            return False, "Ese territorio no es tuyo"

        if armies < 1:
            return False, "Debes colocar al menos 1 ejército"

        return True, ""

    async def apply_reinforcement(self, room_id: int, player_id: int, country_id: int, armies: int) -> GameCountry:
        """Apply reinforcement to a country."""
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.country_id == country_id,
                GameCountry.player_id == player_id
            )
        )
        gc = result.scalar_one()

        gc.armies += armies

        # Deduct from player's hand
        player = await self.session.get(Player, player_id)
        player.armies_in_hand -= armies

        await self.session.flush()
        return gc

    async def get_placeable_countries(self, room_id: int, player_id: int) -> List[GameCountry]:
        """Get all countries where player can place armies (own countries)."""
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            ).order_by(GameCountry.country_id)
        )
        return result.scalars().all()