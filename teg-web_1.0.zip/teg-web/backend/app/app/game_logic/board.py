"""
TEG Web - Board Manager
Handles country distribution, initial setup, and board queries
"""

import random
from typing import List, Dict, Optional, Set, Tuple
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import (
    Country, Continent, Border, Room, Player, GameCountry, GameCard, Card,
    GamePhaseEnum, PlayerStatusEnum
)
from ..schemas import CountryInfo, ContinentInfo


class BoardManager:
    """Manages board state, country distribution, and territory queries."""

    def __init__(self, session: AsyncSession):
        self.session = session

    # ========================================================================
    # Static Data Loading
    # ========================================================================

    async def get_all_countries(self) -> List[CountryInfo]:
        """Get all countries with their info."""
        result = await self.session.execute(
            select(Country).order_by(Country.id)
        )
        countries = result.scalars().all()

        # Load borders
        borders_result = await self.session.execute(select(Border))
        borders = borders_result.scalars().all()
        border_map: Dict[int, Set[int]] = {}
        for b in borders:
            if b.country_from_id not in border_map:
                border_map[b.country_from_id] = set()
            border_map[b.country_from_id].add(b.country_to_id)
            if b.country_to_id not in border_map:
                border_map[b.country_to_id] = set()
            border_map[b.country_to_id].add(b.country_from_id)

        return [
            CountryInfo(
                id=c.id,
                name=c.name,
                continent_id=c.continent_id,
                continent_name="",  # Will be filled by get_full_board_info
                svg_path=c.svg_path,
                x_coord=c.x_coord,
                y_coord=c.y_coord,
                borders=list(border_map.get(c.id, []))
            )
            for c in countries
        ]

    async def get_all_continents(self) -> List[ContinentInfo]:
        """Get all continents with their info."""
        result = await self.session.execute(select(Continent).order_by(Continent.id))
        continents = result.scalars().all()

        # Get countries per continent
        countries_result = await self.session.execute(select(Country))
        countries = countries_result.scalars().all()
        continent_countries: Dict[int, List[int]] = {}
        for c in countries:
            if c.continent_id not in continent_countries:
                continent_countries[c.continent_id] = []
            continent_countries[c.continent_id].append(c.id)

        return [
            ContinentInfo(
                id=cont.id,
                name=cont.name,
                bonus_armies=cont.bonus_armies,
                color=cont.color,
                countries=continent_countries.get(cont.id, [])
            )
            for cont in continents
        ]

    async def get_full_board_info(self) -> Dict:
        """Get complete board info for client initialization."""
        countries = await self.get_all_countries()
        continents = await self.get_all_continents()

        # Build continent name map
        continent_names = {c.id: c.name for c in continents}

        # Add continent names to countries
        for country in countries:
            country.continent_name = continent_names.get(country.continent_id, "")

        return {
            "countries": [c.model_dump() for c in countries],
            "continents": [c.model_dump() for c in continents],
        }

    # ========================================================================
    # Game Initialization
    # ========================================================================

    async def initialize_game(self, room: Room, players: List[Player]) -> None:
        """
        Initialize a new game:
        1. Distribute countries rotationally
        2. Place initial army (1) on each country
        3. Shuffle and prepare card deck
        4. Assign secret objectives
        """
        # Get all countries
        result = await self.session.execute(select(Country).order_by(Country.id))
        all_countries = result.scalars().all()
        country_ids = [c.id for c in all_countries]

        # Rotational distribution
        random.shuffle(country_ids)
        distributed = self._distribute_countries_rotationally(country_ids, players)

        # Create GameCountry entries
        for player, cids in distributed.items():
            for cid in cids:
                gc = GameCountry(
                    room_id=room.id,
                    country_id=cid,
                    player_id=player.id,
                    armies=1
                )
                self.session.add(gc)

        # Initialize card deck
        await self._initialize_card_deck(room)

        # Assign objectives
        await self._assign_objectives(room, players)

        await self.session.flush()

    def _distribute_countries_rotationally(self, country_ids: List[int], players: List[Player]) -> Dict[Player, List[int]]:
        """Distribute countries rotationally among players."""
        distributed: Dict[Player, List[int]] = {p: [] for p in players}
        player_cycle = players * ((len(country_ids) // len(players)) + 1)

        for i, cid in enumerate(country_ids):
            player = player_cycle[i]
            distributed[player].append(cid)

        return distributed

    async def _initialize_card_deck(self, room: Room) -> None:
        """Create GameCard entries for all cards, shuffled."""
        result = await self.session.execute(select(Card).order_by(Card.id))
        cards = result.scalars().all()

        # Create deck entries (all in_deck=True initially)
        for card in cards:
            gc = GameCard(
                room_id=room.id,
                card_id=card.id,
                player_id=None,
                in_deck=True,
                drawn_at=None
            )
            self.session.add(gc)

    async def _assign_objectives(self, room: Room, players: List[Player]) -> None:
        """Assign secret objectives to each player."""
        if room.game_mode.value != "objetivos":
            return

        result = await self.session.execute(select(Objective).order_by(Objective.id))
        objectives = result.scalars().all()

        # Shuffle and assign one per player
        shuffled = objectives.copy()
        random.shuffle(shuffled)

        for i, player in enumerate(players):
            obj = shuffled[i % len(shuffled)]
            po = PlayerObjective(
                room_id=room.id,
                player_id=player.id,
                objective_id=obj.id,
                completed=False
            )
            self.session.add(po)

    # ========================================================================
    # Game State Queries
    # ========================================================================

    async def get_game_countries(self, room_id: int) -> List[GameCountry]:
        """Get all game countries for a room."""
        result = await self.session.execute(
            select(GameCountry).where(GameCountry.room_id == room_id)
        )
        return result.scalars().all()

    async def get_player_countries(self, room_id: int, player_id: int) -> List[GameCountry]:
        """Get countries owned by a player."""
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            )
        )
        return result.scalars().all()

    async def get_country(self, room_id: int, country_id: int) -> Optional[GameCountry]:
        """Get a specific game country."""
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.country_id == country_id
            )
        )
        return result.scalar_one_or_none()

    async def get_adjacent_countries(self, room_id: int, country_id: int) -> List[GameCountry]:
        """Get adjacent countries with their game state."""
        # Get border country IDs
        result = await self.session.execute(
            select(Border.country_to_id).where(Border.country_from_id == country_id)
        )
        to_ids = set(result.scalars().all())

        result = await self.session.execute(
            select(Border.country_from_id).where(Border.country_to_id == country_id)
        )
        from_ids = set(result.scalars().all())

        adjacent_ids = to_ids | from_ids

        # Get game state for adjacent countries
        result = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.country_id.in_(adjacent_ids)
            )
        )
        return result.scalars().all()

    async def get_enemy_countries_adjacent_to(self, room_id: int, country_id: int, player_id: int) -> List[GameCountry]:
        """Get enemy countries adjacent to a given country."""
        adjacent = await self.get_adjacent_countries(room_id, country_id)
        return [c for c in adjacent if c.player_id is not None and c.player_id != player_id]

    async def get_own_countries_adjacent_to(self, room_id: int, country_id: int, player_id: int) -> List[GameCountry]:
        """Get own countries adjacent to a given country (for fortification)."""
        adjacent = await self.get_adjacent_countries(room_id, country_id)
        return [c for c in adjacent if c.player_id == player_id]

    async def find_path(self, room_id: int, from_country_id: int, to_country_id: int, player_id: int) -> Optional[List[int]]:
        """
        Find a path between two countries through player's territories (BFS).
        Returns list of country IDs including start and end, or None if no path.
        """
        # Get all player's countries
        player_countries = await self.get_player_countries(room_id, player_id)
        player_country_ids = {c.country_id for c in player_countries}

        if from_country_id not in player_country_ids or to_country_id not in player_country_ids:
            return None

        # BFS
        from collections import deque
        queue = deque([(from_country_id, [from_country_id])])
        visited = {from_country_id}

        # Get all borders for the room
        result = await self.session.execute(
            select(Border).where(
                Border.country_from_id.in_(player_country_ids),
                Border.country_to_id.in_(player_country_ids)
            )
        )
        borders = result.scalars().all()

        # Build adjacency map
        adj: Dict[int, Set[int]] = {}
        for b in borders:
            if b.country_from_id not in adj:
                adj[b.country_from_id] = set()
            adj[b.country_from_id].add(b.country_to_id)
            if b.country_to_id not in adj:
                adj[b.country_to_id] = set()
            adj[b.country_to_id].add(b.country_from_id)

        while queue:
            current, path = queue.popleft()
            if current == to_country_id:
                return path

            for neighbor in adj.get(current, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))

        return None

    # ========================================================================
    # Country Operations
    # ========================================================================

    async def add_armies(self, room_id: int, country_id: int, amount: int) -> GameCountry:
        """Add armies to a country."""
        gc = await self.get_country(room_id, country_id)
        if gc:
            gc.armies += amount
            await self.session.flush()
        return gc

    async def remove_armies(self, room_id: int, country_id: int, amount: int) -> GameCountry:
        """Remove armies from a country."""
        gc = await self.get_country(room_id, country_id)
        if gc:
            gc.armies = max(0, gc.armies - amount)
            await self.session.flush()
        return gc

    async def move_armies(self, room_id: int, from_country_id: int, to_country_id: int, amount: int) -> Tuple[GameCountry, GameCountry]:
        """Move armies between two countries."""
        from_gc = await self.get_country(room_id, from_country_id)
        to_gc = await self.get_country(room_id, to_country_id)

        if from_gc and to_gc:
            from_gc.armies = max(0, from_gc.armies - amount)
            to_gc.armies += amount
            await self.session.flush()

        return from_gc, to_gc

    async def conquer_country(self, room_id: int, country_id: int, new_owner_id: int, armies: int) -> GameCountry:
        """Transfer country ownership after conquest."""
        gc = await self.get_country(room_id, country_id)
        if gc:
            gc.player_id = new_owner_id
            gc.armies = armies
            await self.session.flush()
        return gc

    # ========================================================================
    # Player Stats
    # ========================================================================

    async def get_player_stats(self, room_id: int, player_id: int) -> Dict:
        """Get player statistics: countries, armies, continents."""
        countries = await self.get_player_countries(room_id, player_id)

        total_armies = sum(c.armies for c in countries)
        country_count = len(countries)

        # Continent control
        continent_control: Dict[int, int] = {}
        for c in countries:
            # Need to get continent for each country
            country_result = await self.session.execute(
                select(Country.continent_id).where(Country.id == c.country_id)
            )
            cont_id = country_result.scalar_one_or_none()
            if cont_id:
                continent_control[cont_id] = continent_control.get(cont_id, 0) + 1

        # Get continent totals
        continents = await self.get_all_continents()
        continent_totals = {c.id: len(c.countries) for c in continents}

        controlled_continents = [
            cont_id for cont_id, count in continent_control.items()
            if count == continent_totals.get(cont_id, 0)
        ]

        return {
            "countries": country_count,
            "total_armies": total_armies,
            "continents_controlled": controlled_continents,
            "continent_control": continent_control,
        }

    # ========================================================================
    # Setup Phase
    # ========================================================================

    async def can_place_army(self, room_id: int, country_id: int, player_id: int) -> bool:
        """Check if player can place army on country during setup."""
        gc = await self.get_country(room_id, country_id)
        return gc is not None and gc.player_id == player_id