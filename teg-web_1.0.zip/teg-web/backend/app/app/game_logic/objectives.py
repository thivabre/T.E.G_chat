"""
TEG Web - Objective Manager
Handles objective assignment and victory condition checking
"""

import json
import re
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import (
    Room, Player, GameCountry, PlayerObjective, Objective, ObjectiveTypeEnum,
    Country, Continent, PlayerStatusEnum
)


@dataclass
class ObjectiveCheckResult:
    """Result of checking an objective."""
    completed: bool
    progress: str  # Human-readable progress
    details: Dict  # Detailed info for UI


class ObjectiveManager:
    """Manages objectives and victory checking."""

    def __init__(self, session: AsyncSession):
        self.session = session

    # ========================================================================
    # Objective Parsing
    # ========================================================================

    def parse_objective(self, objective: Objective) -> Dict:
        """
        Parse objective description into structured data.
        Returns dict with type, targets, etc.
        """
        desc = objective.description.lower()

        # Base info from DB
        result = {
            "id": objective.id,
            "type": objective.type.value,
            "description": objective.description,
            "target_count": objective.target_count,
            "target_continent_id": objective.target_continent_id,
            "target_player_color": objective.target_player_color,
        }

        # Parse additional info from description
        if objective.type == ObjectiveTypeEnum.occupation:
            # "Ocupar 30 países" or "Ocupar 24 países y 2 continentes"
            countries_match = re.search(r'(\d+)\s*país', desc)
            continents_match = re.search(r'(\d+)\s*continente', desc)

            if countries_match:
                result["target_countries"] = int(countries_match.group(1))
            if continents_match:
                result["target_continents"] = int(continents_match.group(1))

            # Specific continent objectives
            if "norteamérica" in desc or "north america" in desc:
                result["specific_continent"] = "north-america"
            elif "sudamérica" in desc or "south america" in desc:
                result["specific_continent"] = "south-america"
            elif "europa" in desc:
                result["specific_continent"] = "europe"
            elif "áfrica" in desc or "africa" in desc:
                result["specific_continent"] = "africa"
            elif "asia" in desc:
                result["specific_continent"] = "asia"
            elif "oceanía" in desc or "oceania" in desc:
                result["specific_continent"] = "oceania"

        elif objective.type == ObjectiveTypeEnum.destruction:
            # "Destruir al jugador rojo" or "Eliminar al jugador verde"
            color_match = re.search(r'(rojo|azul|verde|amarillo|naranja|morado|púrpura|purple|orange|red|blue|green|yellow)', desc)
            if color_match:
                color_map = {
                    'rojo': 'red', 'red': 'red',
                    'azul': 'blue', 'blue': 'blue',
                    'verde': 'green', 'green': 'green',
                    'amarillo': 'yellow', 'yellow': 'yellow',
                    'naranja': 'orange', 'orange': 'orange',
                    'morado': 'purple', 'púrpura': 'purple', 'purple': 'purple',
                }
                result["target_color"] = color_map.get(color_match.group(1), color_match.group(1))

        return result

    # ========================================================================
    # Victory Checking
    # ========================================================================

    async def check_victory(self, room_id: int, player_id: int) -> Optional[ObjectiveCheckResult]:
        """
        Check if a player has achieved their objective.
        Returns ObjectiveCheckResult if completed, None otherwise.
        """
        # Get player's objective
        result = await self.session.execute(
            select(PlayerObjective).where(
                PlayerObjective.room_id == room_id,
                PlayerObjective.player_id == player_id,
                PlayerObjective.completed == False
            ).options(
                selectinload(PlayerObjective.objective)
            )
        )
        po = result.scalar_one_or_none()

        if not po:
            return None

        objective = po.objective
        parsed = self.parse_objective(objective)

        if objective.type == ObjectiveTypeEnum.occupation:
            return await self._check_occupation_objective(room_id, player_id, parsed, po)
        elif objective.type == ObjectiveTypeEnum.destruction:
            return await self._check_destruction_objective(room_id, player_id, parsed, po)

        return None

    async def _check_occupation_objective(
        self,
        room_id: int,
        player_id: int,
        parsed: Dict,
        po: PlayerObjective
    ) -> Optional[ObjectiveCheckResult]:
        """Check occupation-type objective."""
        # Get player's countries
        countries = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            )
        )
        player_countries = countries.scalars().all()

        country_count = len(player_countries)

        # Count controlled continents
        continent_control = {}
        for gc in player_countries:
            country_result = await self.session.execute(
                select(Country.continent_id).where(Country.id == gc.country_id)
            )
            cont_id = country_result.scalar_one_or_none()
            if cont_id:
                continent_control[cont_id] = continent_control.get(cont_id, 0) + 1

        # Get continent totals
        cont_result = await self.session.execute(select(Continent))
        continents = cont_result.scalars().all()
        continent_totals = {c.id: len(c.countries) for c in continents}  # This won't work directly

        # Better: query country count per continent
        cont_countries = await self.session.execute(
            select(Country.continent_id, func.count(Country.id)).group_by(Country.continent_id)
        )
        continent_totals = {row[0]: row[1] for row in cont_countries.all()}

        controlled_continents = [
            cid for cid, count in continent_control.items()
            if count == continent_totals.get(cid, 0)
        ]
        continent_count = len(controlled_continents)

        # Check conditions
        target_countries = parsed.get("target_countries", 0)
        target_continents = parsed.get("target_continents", 0)
        specific_continent = parsed.get("specific_continent")

        completed = False
        progress_parts = []

        if target_countries > 0:
            completed = completed or (country_count >= target_countries)
            progress_parts.append(f"{country_count}/{target_countries} países")

        if target_continents > 0:
            completed = completed or (continent_count >= target_continents)
            progress_parts.append(f"{continent_count}/{target_continents} continentes")

        if specific_continent:
            # Find continent ID
            cont_result = await self.session.execute(
                select(Continent).where(Continent.name.ilike(f"%{specific_continent}%"))
            )
            spec_cont = cont_result.scalar_one_or_none()
            if spec_cont:
                owns_continent = spec_cont.id in controlled_continents
                completed = completed or owns_continent
                progress_parts.append(f"Continente {spec_cont.name}: {'Sí' if owns_continent else 'No'}")

        if completed:
            po.completed = True
            po.completed_at = func.now()
            await self.session.flush()

            return ObjectiveCheckResult(
                completed=True,
                progress=", ".join(progress_parts),
                details={
                    "country_count": country_count,
                    "continent_count": continent_count,
                    "controlled_continents": controlled_continents,
                }
            )

        return ObjectiveCheckResult(
            completed=False,
            progress=", ".join(progress_parts) if progress_parts else "En progreso",
            details={
                "country_count": country_count,
                "continent_count": continent_count,
                "controlled_continents": controlled_continents,
            }
        )

    async def _check_destruction_objective(
        self,
        room_id: int,
        player_id: int,
        parsed: Dict,
        po: PlayerObjective
    ) -> Optional[ObjectiveCheckResult]:
        """Check destruction-type objective."""
        target_color = parsed.get("target_color")

        if not target_color:
            return ObjectiveCheckResult(
                completed=False,
                progress="Objetivo no válido",
                details={}
            )

        # Find target player
        result = await self.session.execute(
            select(Player).where(
                Player.room_id == room_id,
                Player.color.ilike(f"%{target_color}%"),
                Player.status != PlayerStatusEnum.eliminated
            )
        )
        target_player = result.scalar_one_or_none()

        if not target_player:
            # Target already eliminated = objective complete!
            po.completed = True
            po.completed_at = func.now()
            await self.session.flush()

            return ObjectiveCheckResult(
                completed=True,
                progress=f"Jugador {target_color} eliminado",
                details={"target_color": target_color, "eliminated": True}
            )

        return ObjectiveCheckResult(
            completed=False,
            progress=f"Jugador {target_color} sigue en juego",
            details={"target_color": target_color, "target_player_id": target_player.id}
        )

    async def check_world_conquest_victory(self, room_id: int) -> Optional[Player]:
        """Check for world conquest victory (last player standing)."""
        result = await self.session.execute(
            select(Player).where(
                Player.room_id == room_id,
                Player.status == PlayerStatusEnum.active
            )
        )
        active_players = result.scalars().all()

        if len(active_players) == 1:
            return active_players[0]

        return None

    async def check_all_objectives(self, room_id: int) -> List[ObjectiveCheckResult]:
        """Check all incomplete objectives in a room."""
        result = await self.session.execute(
            select(PlayerObjective).where(
                PlayerObjective.room_id == room_id,
                PlayerObjective.completed == False
            ).options(
                selectinload(PlayerObjective.objective),
                selectinload(PlayerObjective.player)
            )
        )
        objectives = result.scalars().all()

        results = []
        for po in objectives:
            check = await self.check_victory(room_id, po.player_id)
            if check:
                results.append(check)

        return results

    # ========================================================================
    # Objective Progress for UI
    # ========================================================================

    async def get_objective_progress(self, room_id: int, player_id: int) -> Optional[ObjectiveCheckResult]:
        """Get current progress on player's objective (without marking complete)."""
        result = await self.session.execute(
            select(PlayerObjective).where(
                PlayerObjective.room_id == room_id,
                PlayerObjective.player_id == player_id
            ).options(
                selectinload(PlayerObjective.objective)
            )
        )
        po = result.scalar_one_or_none()

        if not po:
            return None

        objective = po.objective
        parsed = self.parse_objective(objective)

        if objective.type == ObjectiveTypeEnum.occupation:
            return await self._get_occupation_progress(room_id, player_id, parsed, po)
        elif objective.type == ObjectiveTypeEnum.destruction:
            return await self._get_destruction_progress(room_id, player_id, parsed, po)

        return None

    async def _get_occupation_progress(
        self,
        room_id: int,
        player_id: int,
        parsed: Dict,
        po: PlayerObjective
    ) -> ObjectiveCheckResult:
        """Get progress for occupation objective."""
        countries = await self.session.execute(
            select(GameCountry).where(
                GameCountry.room_id == room_id,
                GameCountry.player_id == player_id
            )
        )
        player_countries = countries.scalars().all()
        country_count = len(player_countries)

        continent_control = {}
        for gc in player_countries:
            country_result = await self.session.execute(
                select(Country.continent_id).where(Country.id == gc.country_id)
            )
            cont_id = country_result.scalar_one_or_none()
            if cont_id:
                continent_control[cont_id] = continent_control.get(cont_id, 0) + 1

        cont_countries = await self.session.execute(
            select(Country.continent_id, func.count(Country.id)).group_by(Country.continent_id)
        )
        continent_totals = {row[0]: row[1] for row in cont_countries.all()}

        controlled_continents = [
            cid for cid, count in continent_control.items()
            if count == continent_totals.get(cid, 0)
        ]
        continent_count = len(controlled_continents)

        target_countries = parsed.get("target_countries", 0)
        target_continents = parsed.get("target_continents", 0)
        specific_continent = parsed.get("specific_continent")

        progress_parts = []
        if target_countries > 0:
            progress_parts.append(f"{country_count}/{target_countries} países")
        if target_continents > 0:
            progress_parts.append(f"{continent_count}/{target_continents} continentes")
        if specific_continent:
            cont_result = await self.session.execute(
                select(Continent).where(Continent.name.ilike(f"%{specific_continent}%"))
            )
            spec_cont = cont_result.scalar_one_or_none()
            if spec_cont:
                owns = spec_cont.id in controlled_continents
                progress_parts.append(f"{spec_cont.name}: {'✓' if owns else '✗'}")

        return ObjectiveCheckResult(
            completed=po.completed,
            progress=", ".join(progress_parts) if progress_parts else "En progreso",
            details={
                "country_count": country_count,
                "continent_count": continent_count,
                "controlled_continents": controlled_continents,
            }
        )

    async def _get_destruction_progress(
        self,
        room_id: int,
        player_id: int,
        parsed: Dict,
        po: PlayerObjective
    ) -> ObjectiveCheckResult:
        """Get progress for destruction objective."""
        target_color = parsed.get("target_color")

        if not target_color:
            return ObjectiveCheckResult(
                completed=False,
                progress="Objetivo no válido",
                details={}
            )

        result = await self.session.execute(
            select(Player).where(
                Player.room_id == room_id,
                Player.color.ilike(f"%{target_color}%")
            )
        )
        target_player = result.scalar_one_or_none()

        if not target_player:
            return ObjectiveCheckResult(
                completed=True,
                progress=f"Jugador {target_color} eliminado",
                details={"target_color": target_color, "eliminated": True}
            )

        status = "activo" if target_player.status == PlayerStatusEnum.active else "eliminado"
        return ObjectiveCheckResult(
            completed=False,
            progress=f"Jugador {target_color}: {status}",
            details={
                "target_color": target_color,
                "target_player_id": target_player.id,
                "target_status": target_player.status.value,
            }
        )


# Need to import selectinload
from sqlalchemy.orm import selectinload