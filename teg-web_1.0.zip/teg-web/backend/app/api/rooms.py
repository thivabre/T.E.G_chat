"""
TEG Web - Room API Endpoints
REST API for room management
"""

import random
import string
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..database import get_db
from ..models import Room, Player, Spectator, RoomTypeEnum, RoomStatusEnum, GameModeEnum, PlayerStatusEnum
from ..schemas import (
    RoomCreate, RoomJoin, RoomResponse, RoomDetailResponse,
    RoomSummaryResponse, PlayerResponse, SpectatorResponse
)
from ..websocket.manager import manager


router = APIRouter(prefix="/rooms", tags=["rooms"])


def generate_room_code() -> str:
    """Generate a unique 6-character room code."""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))


# ============================================================================
# Room Listing
# ============================================================================

@router.get("/public", response_model=List[RoomSummaryResponse])
async def list_public_rooms(
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db)
):
    """List public rooms waiting for players."""
    result = await db.execute(
        select(Room).where(
            Room.type == RoomTypeEnum.publica,
            Room.status == RoomStatusEnum.waiting
        ).order_by(Room.created_at.desc()).limit(limit).offset(offset)
    )
    rooms = result.scalars().all()

    # Get player counts
    room_summaries = []
    for room in rooms:
        player_count_result = await db.execute(
            select(func.count(Player.id)).where(Player.room_id == room.id)
        )
        player_count = player_count_result.scalar() or 0

        spectator_count_result = await db.execute(
            select(func.count(Spectator.id)).where(Spectator.room_id == room.id)
        )
        spectator_count = spectator_count_result.scalar() or 0

        host_result = await db.execute(
            select(Player.name).where(Player.id == room.host_id)
        )
        host_name = host_result.scalar() or "Desconocido"

        room_summaries.append(RoomSummaryResponse(
            id=room.id,
            code=room.code,
            name=room.name,
            type=room.type,
            status=room.status,
            max_players=room.max_players,
            game_mode=room.game_mode,
            turn_time_limit=room.turn_time_limit,
            player_count=player_count,
            spectator_count=spectator_count,
            host_name=host_name,
            created_at=room.created_at
        ))

    return room_summaries


@router.get("/{room_id}", response_model=RoomDetailResponse)
async def get_room(room_id: int, db: AsyncSession = Depends(get_db)):
    """Get detailed room information."""
    result = await db.execute(
        select(Room).where(Room.id == room_id)
    )
    room = result.scalar_one_or_none()

    if not room:
        raise HTTPException(status_code=404, detail="Partida no encontrada")

    # Get players
    players_result = await db.execute(
        select(Player).where(Player.room_id == room_id).order_by(Player.position)
    )
    players = players_result.scalars().all()

    # Get spectators
    specs_result = await db.execute(
        select(Spectator).where(Spectator.room_id == room_id)
    )
    spectators = specs_result.scalars().all()

    return RoomDetailResponse(
        id=room.id,
        code=room.code,
        name=room.name,
        type=room.type,
        status=room.status,
        max_players=room.max_players,
        game_mode=room.game_mode,
        turn_time_limit=room.turn_time_limit,
        host_id=room.host_id,
        host_name=None,  # Would need join
        current_turn_player_id=room.current_turn_player_id,
        current_phase=room.current_phase,
        turn_number=room.turn_number,
        trade_count=room.trade_count,
        created_at=room.created_at,
        started_at=room.started_at,
        finished_at=room.finished_at,
        players=[PlayerResponse.model_validate(p) for p in players],
        spectators=[SpectatorResponse.model_validate(s) for s in spectators]
    )


# ============================================================================
# Room Creation
# ============================================================================

@router.post("", response_model=RoomResponse, status_code=status.HTTP_201_CREATED)
async def create_room(room_data: RoomCreate, db: AsyncSession = Depends(get_db)):
    """Create a new room."""
    # Generate unique code
    code = generate_room_code()
    while True:
        result = await db.execute(select(Room).where(Room.code == code))
        if not result.scalar_one_or_none():
            break
        code = generate_room_code()

    # Create room
    room = Room(
        code=code,
        name=room_data.name,
        type=room_data.type,
        max_players=room_data.max_players,
        game_mode=room_data.game_mode,
        turn_time_limit=room_data.turn_time_limit,
        status=RoomStatusEnum.waiting,
    )
    db.add(room)
    await db.flush()

    # Create host player
    host = Player(
        room_id=room.id,
        name=room_data.host_name,
        color="#e74c3c",  # Red for host
        position=1,
        status=PlayerStatusEnum.active,
        is_host=True,
        is_ready=True,
    )
    db.add(host)
    await db.flush()

    # Link host to room
    room.host_id = host.id

    await db.commit()
    # Re-fetch with host loaded to avoid lazy loading issues
    result = await db.execute(
        select(Room).options(selectinload(Room.host)).where(Room.id == room.id)
    )
    room = result.scalar_one()

    return RoomResponse.model_validate(room)


# ============================================================================
# Room Joining
# ============================================================================

@router.post("/join-by-code", response_model=RoomResponse)
async def join_room_by_code(join_data: RoomJoin, db: AsyncSession = Depends(get_db)):
    """Join a room using its code."""
    result = await db.execute(
        select(Room).options(selectinload(Room.host)).where(Room.code == join_data.code.upper())
    )
    room = result.scalar_one_or_none()

    if not room:
        raise HTTPException(status_code=404, detail="Código de partida inválido")

    if room.status != RoomStatusEnum.waiting:
        raise HTTPException(status_code=400, detail="La partida ya comenzó")

    # Check if name already taken
    result = await db.execute(
        select(Player).where(
            Player.room_id == room.id,
            Player.name == join_data.player_name
        )
    )
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Ese nombre ya está en uso")

    # Count current players
    result = await db.execute(
        select(func.count(Player.id)).where(Player.room_id == room.id)
    )
    player_count = result.scalar() or 0

    if player_count >= room.max_players:
        raise HTTPException(status_code=400, detail="La partida está completa")

    # Assign color
    colors = ["#e74c3c", "#3498db", "#2ecc71", "#f1c40f", "#e67e22", "#9b59b6"]
    used_colors_result = await db.execute(
        select(Player.color).where(Player.room_id == room.id)
    )
    used_colors = {c for c in used_colors_result.scalars().all()}
    available_colors = [c for c in colors if c not in used_colors]
    color = available_colors[0] if available_colors else "#95a5a6"

    # Assign position
    position = player_count + 1

    # Create player
    player = Player(
        room_id=room.id,
        name=join_data.player_name,
        color=color,
        position=position,
        status=PlayerStatusEnum.active,
        is_host=False,
        is_ready=False,
    )
    db.add(player)
    await db.commit()
    await db.refresh(room)

    # Notify via WebSocket
    await manager.broadcast_to_room(room.id, {
        "event": "room_update",
        "data": {
            "room": RoomResponse.model_validate(room).model_dump(),
            "players": [PlayerResponse.model_validate(p).model_dump() for p in
                       (await db.execute(select(Player).where(Player.room_id == room.id))).scalars().all()],
            "spectators": []
        }
    })

    return RoomResponse.model_validate(room)


@router.post("/{room_id}/join", response_model=RoomResponse)
async def join_room(room_id: int, player_name: str, db: AsyncSession = Depends(get_db)):
    """Join a room by ID (for public rooms)."""
    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()

    if not room:
        raise HTTPException(status_code=404, detail="Partida no encontrada")

    if room.type == RoomTypeEnum.privada:
        raise HTTPException(status_code=403, detail="Partida privada, usa el código")

    return await join_room_by_code(RoomJoin(code=room.code, player_name=player_name), db)


# ============================================================================
# Player Actions
# ============================================================================

@router.post("/{room_id}/ready/{player_id}")
async def set_player_ready(room_id: int, player_id: int, ready: bool, db: AsyncSession = Depends(get_db)):
    """Set player ready status."""
    result = await db.execute(
        select(Player).where(Player.id == player_id, Player.room_id == room_id)
    )
    player = result.scalar_one_or_none()

    if not player:
        raise HTTPException(status_code=404, detail="Jugador no encontrado")

    player.is_ready = ready
    await db.commit()

    # Broadcast update
    await manager.broadcast_to_room(room_id, {
        "event": "room_update",
        "data": {"player_ready": {"player_id": player_id, "ready": ready}}
    })

    return {"success": True, "ready": ready}


@router.delete("/{room_id}/leave/{player_id}")
async def leave_room(room_id: int, player_id: int, db: AsyncSession = Depends(get_db)):
    """Player leaves room."""
    result = await db.execute(
        select(Player).where(Player.id == player_id, Player.room_id == room_id)
    )
    player = result.scalar_one_or_none()

    if not player:
        raise HTTPException(status_code=404, detail="Jugador no encontrado")

    was_host = player.is_host

    # If host leaves, transfer host to next player
    if was_host:
        result = await db.execute(
            select(Player).where(
                Player.room_id == room_id,
                Player.id != player_id,
                Player.status == PlayerStatusEnum.active
            ).order_by(Player.position)
        )
        next_player = result.scalars().first()
        if next_player:
            next_player.is_host = True
            room = await db.get(Room, room_id)
            room.host_id = next_player.id

    await db.delete(player)
    await db.commit()

    # If no players left, delete room
    result = await db.execute(
        select(func.count(Player.id)).where(Player.room_id == room_id)
    )
    if result.scalar() == 0:
        room = await db.get(Room, room_id)
        await db.delete(room)
        await db.commit()
        return {"success": True, "room_deleted": True}

    # Broadcast update
    await manager.broadcast_to_room(room_id, {
        "event": "room_update",
        "data": {"player_left": player_id}
    })

    return {"success": True}


# ============================================================================
# Spectators
# ============================================================================

@router.post("/{room_id}/spectate", response_model=SpectatorResponse)
async def spectate_room(room_id: int, name: str, db: AsyncSession = Depends(get_db)):
    """Join a room as spectator."""
    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()

    if not room:
        raise HTTPException(status_code=404, detail="Partida no encontrada")

    # Check if name already taken by player or spectator
    result = await db.execute(
        select(Player).where(Player.room_id == room_id, Player.name == name)
    )
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Nombre en uso por un jugador")

    result = await db.execute(
        select(Spectator).where(Spectator.room_id == room_id, Spectator.name == name)
    )
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Nombre en uso por un espectador")

    spectator = Spectator(room_id=room_id, name=name)
    db.add(spectator)
    await db.commit()
    await db.refresh(spectator)

    # Notify via WebSocket
    await manager.broadcast_to_room(room_id, {
        "event": "room_update",
        "data": {"spectator_joined": SpectatorResponse.model_validate(spectator).model_dump()}
    })

    return SpectatorResponse.model_validate(spectator)


@router.delete("/{room_id}/spectate/{spectator_id}")
async def leave_spectate(room_id: int, spectator_id: int, db: AsyncSession = Depends(get_db)):
    """Spectator leaves room."""
    result = await db.execute(
        select(Spectator).where(Spectator.id == spectator_id, Spectator.room_id == room_id)
    )
    spectator = result.scalar_one_or_none()

    if not spectator:
        raise HTTPException(status_code=404, detail="Espectador no encontrado")

    spectator.left_at = datetime.utcnow()
    await db.commit()

    # Notify via WebSocket
    await manager.broadcast_to_room(room_id, {
        "event": "room_update",
        "data": {"spectator_left": spectator_id}
    })

    return {"success": True}