"""
TEG Web - API Package
"""

from .rooms import router as rooms_router
from .game import router as game_router
from .chat import router as chat_router

__all__ = [
    "rooms_router",
    "game_router",
    "chat_router",
]