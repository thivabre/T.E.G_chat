"""
TEG Web - Chat API Endpoints
REST API for chat history and messages
"""

from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..database import get_db
from ..models import Room, Player, ChatMessage, ChatTypeEnum
from ..schemas import ChatMessageResponse


router = APIRouter(prefix="/chat", tags=["chat"])


@router.get("/{room_id}/messages", response_model=List[ChatMessageResponse])
async def get_chat_history(
    room_id: int,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    before: Optional[datetime] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """Get chat history for a room."""
    # Verify room exists
    room = await db.get(Room, room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Partida no encontrada")

    query = select(ChatMessage).where(ChatMessage.room_id == room_id)

    if before:
        query = query.where(ChatMessage.sent_at < before)

    query = query.order_by(ChatMessage.sent_at.desc()).limit(limit).offset(offset)

    result = await db.execute(query)
    messages = result.scalars().all()

    # Enrich with sender/recipient info
    message_ids = [m.id for m in messages]
    sender_ids = set(m.sender_id for m in messages)
    recipient_ids = set(m.recipient_id for m in messages if m.recipient_id)
    all_user_ids = sender_ids | recipient_ids

    players_info = {}
    if all_user_ids:
        result = await db.execute(select(Player).where(Player.id.in_(all_user_ids)))
        for p in result.scalars().all():
            players_info[p.id] = p

    response = []
    for msg in reversed(messages):  # Reverse to chronological order
        sender = players_info.get(msg.sender_id)
        recipient = players_info.get(msg.recipient_id) if msg.recipient_id else None

        response.append(ChatMessageResponse(
            id=msg.id,
            room_id=msg.room_id,
            sender_id=msg.sender_id,
            sender_name=sender.name if sender else "Desconocido",
            sender_color=sender.color if sender else "#95a5a6",
            recipient_id=msg.recipient_id,
            type=msg.type,
            message=msg.message,
            sent_at=msg.sent_at
        ))

    return response


@router.get("/{room_id}/unread-count")
async def get_unread_count(
    room_id: int,
    player_id: int,
    since: datetime,
    db: AsyncSession = Depends(get_db)
):
    """Get count of unread messages since a timestamp."""
    room = await db.get(Room, room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Partida no encontrada")

    # Count general messages + private messages to/from player
    result = await db.execute(
        select(func.count(ChatMessage.id)).where(
            ChatMessage.room_id == room_id,
            ChatMessage.sent_at > since,
            (ChatMessage.type == ChatTypeEnum.general) |
            (ChatMessage.recipient_id == player_id) |
            (ChatMessage.sender_id == player_id)
        )
    )
    count = result.scalar() or 0

    return {"unread_count": count}


@router.get("/{room_id}/private/{player_id}/{other_player_id}")
async def get_private_chat(
    room_id: int,
    player_id: int,
    other_player_id: int,
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db)
):
    """Get private chat history between two players."""
    room = await db.get(Room, room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Partida no encontrada")

    result = await db.execute(
        select(ChatMessage).where(
            ChatMessage.room_id == room_id,
            ChatMessage.type == ChatTypeEnum.private,
            ((ChatMessage.sender_id == player_id) & (ChatMessage.recipient_id == other_player_id)) |
            ((ChatMessage.sender_id == other_player_id) & (ChatMessage.recipient_id == player_id))
        ).order_by(ChatMessage.sent_at.desc()).limit(limit)
    )
    messages = result.scalars().all()

    # Get player info
    players_result = await db.execute(
        select(Player).where(Player.id.in_([player_id, other_player_id]))
    )
    players_info = {p.id: p for p in players_result.scalars().all()}

    response = []
    for msg in reversed(messages):
        sender = players_info.get(msg.sender_id)
        recipient = players_info.get(msg.recipient_id) if msg.recipient_id else None

        response.append(ChatMessageResponse(
            id=msg.id,
            room_id=msg.room_id,
            sender_id=msg.sender_id,
            sender_name=sender.name if sender else "Desconocido",
            sender_color=sender.color if sender else "#95a5a6",
            recipient_id=msg.recipient_id,
            type=msg.type,
            message=msg.message,
            sent_at=msg.sent_at
        ))

    return {"messages": response, "other_player": players_info.get(other_player_id)}