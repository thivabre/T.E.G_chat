"""
TEG Web - Game API Endpoints
REST API for game actions (supplements WebSocket)
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..database import get_db
from ..models import Room, Player, GameCountry, GameCard, GamePhaseEnum, RoomStatusEnum, PlayerStatusEnum
from ..schemas import (
    GameStateResponse, PlayerGameState, GameCountryResponse,
    ReinforceRequest, AttackRequest, FortifyRequest, TradeCardsRequest,
    CombatResult, TradeCardsResponse, CardResponse
)
from ..game_logic import BoardManager, CombatManager, CardManager, TurnManager, ReinforcementManager, ObjectiveManager


router = APIRouter(prefix="/game", tags=["game"])


# ============================================================================
# Game State
# ============================================================================

@router.get("/{room_id}/state", response_model=GameStateResponse)
async def get_game_state(room_id: int, db: AsyncSession = Depends(get_db)):
    """Get current game state."""
    result = await db.execute(select(Room).where(Room.id == room_id))
    room = result.scalar_one_or_none()

    if not room:
        raise HTTPException(status_code=404, detail="Partida no encontrada")

    if room.status != RoomStatusEnum.in_progress:
        raise HTTPException(status_code=400, detail="La partida no está en curso")

    # Build game state (similar to WebSocket handler)
    board_manager = BoardManager(db)
    card_manager = CardManager(db)
    objective_manager = ObjectiveManager(db)
    turn_manager = TurnManager(db)
    reinforcement_manager = ReinforcementManager(db)

    # Get players
    players_result = await db.execute(
        select(Player).where(Player.room_id == room_id).order_by(Player.position)
    )
    players = players_result.scalars().all()

    # Get countries
    countries_result = await db.execute(
        select(GameCountry).where(GameCountry.room_id == room_id)
    )
    countries = countries_result.scalars().all()

    # Build player states
    player_states = []
    for p in players:
        p_countries = [c for c in countries if c.player_id == p.id]
        p_cards = await card_manager.get_player_cards(room_id, p.id)
        p_obj = await objective_manager.get_objective_progress(room_id, p.id)

        player_states.append(PlayerGameState(
            id=p.id,
            name=p.name,
            color=p.color,
            position=p.position,
            status=p.status,
            armies_in_hand=p.armies_in_hand,
            countries_count=len(p_countries),
            total_armies=sum(c.armies for c in p_countries),
            cards_count=len(p_cards),
            cards=[await card_manager.get_card_display_info(c) for c in p_cards],
            objective=p_obj,
            is_host=p.is_host,
            is_current_turn=p.id == room.current_turn_player_id
        ))

    # Build country states
    country_states = []
    for gc in countries:
        # Get country info
        from ..models import Country
        country_result = await db.execute(select(Country).where(Country.id == gc.country_id))
        country = country_result.scalar_one()

        country_states.append(GameCountryResponse(
            id=gc.id,
            room_id=gc.room_id,
            country_id=gc.country_id,
            country_name=country.name,
            continent_name="",  # Would need join
            player_id=gc.player_id,
            player_name="",  # Would need join
            player_color="",  # Would need join
            armies=gc.armies
        ))

    # Get timer
    timer = await turn_manager.get_turn_timer(room_id)
    timer_expires = timer.expires_at if timer else None

    return GameStateResponse(
        room=room,
        current_phase=room.current_phase,
        current_turn_player_id=room.current_turn_player_id,
        players=player_states,
        countries=country_states,
        turn_number=room.turn_number,
        trade_count=room.trade_count,
        timer_expires_at=timer_expires,
        can_trade_cards=False,
        must_trade_cards=False
    )


@router.get("/{room_id}/board")
async def get_board_info(room_id: int, db: AsyncSession = Depends(get_db)):
    """Get static board info (countries, continents, borders)."""
    board_manager = BoardManager(db)
    return await board_manager.get_full_board_info()


@router.get("/{room_id}/countries", response_model=List[GameCountryResponse])
async def get_game_countries(room_id: int, db: AsyncSession = Depends(get_db)):
    """Get all game countries with current state."""
    result = await db.execute(
        select(GameCountry).where(GameCountry.room_id == room_id)
    )
    countries = result.scalars().all()

    # Enrich with country info
    from ..models import Country
    country_ids = [c.country_id for c in countries]
    countries_info = {}
    if country_ids:
        result = await db.execute(select(Country).where(Country.id.in_(country_ids)))
        for c in result.scalars().all():
            countries_info[c.id] = c

    # Get player info
    player_ids = set(c.player_id for c in countries if c.player_id)
    players_info = {}
    if player_ids:
        result = await db.execute(select(Player).where(Player.id.in_(player_ids)))
        for p in result.scalars().all():
            players_info[p.id] = p

    response = []
    for gc in countries:
        country = countries_info.get(gc.country_id)
        player = players_info.get(gc.player_id) if gc.player_id else None

        response.append(GameCountryResponse(
            id=gc.id,
            room_id=gc.room_id,
            country_id=gc.country_id,
            country_name=country.name if country else "",
            continent_name="",
            player_id=gc.player_id,
            player_name=player.name if player else "",
            player_color=player.color if player else "",
            armies=gc.armies
        ))

    return response


@router.get("/{room_id}/players", response_model=List[PlayerGameState])
async def get_players(room_id: int, db: AsyncSession = Depends(get_db)):
    """Get all players with game state."""
    result = await db.execute(
        select(Player).where(Player.room_id == room_id).order_by(Player.position)
    )
    players = result.scalars().all()

    board_manager = BoardManager(db)
    card_manager = CardManager(db)
    objective_manager = ObjectiveManager(db)

    player_states = []
    for p in players:
        countries = await board_manager.get_player_countries(room_id, p.id)
        p_cards = await card_manager.get_player_cards(room_id, p.id)
        p_obj = await objective_manager.get_objective_progress(room_id, p.id)

        player_states.append(PlayerGameState(
            id=p.id,
            name=p.name,
            color=p.color,
            position=p.position,
            status=p.status,
            armies_in_hand=p.armies_in_hand,
            countries_count=len(countries),
            total_armies=sum(c.armies for c in countries),
            cards_count=len(p_cards),
            cards=[await card_manager.get_card_display_info(c) for c in p_cards],
            objective=p_obj,
            is_host=p.is_host,
            is_current_turn=False  # Would need room
        ))

    return player_states


# ============================================================================
# Card Endpoints
# ============================================================================

@router.get("/{room_id}/cards/{player_id}", response_model=List[CardResponse])
async def get_player_cards(room_id: int, player_id: int, db: AsyncSession = Depends(get_db)):
    """Get player's cards."""
    card_manager = CardManager(db)
    cards = await card_manager.get_player_cards(room_id, player_id)

    result = []
    for gc in cards:
        info = await card_manager.get_card_display_info(gc)
        result.append(CardResponse(
            id=gc.card_id,
            country_id=info["country_name"],  # This is wrong, but for display
            country_name=info["country_name"],
            type=info["type"]
        ))

    return result


@router.post("/{room_id}/trade", response_model=TradeCardsResponse)
async def trade_cards(room_id: int, trade: TradeCardsRequest, player_id: int, db: AsyncSession = Depends(get_db)):
    """Trade in cards for armies."""
    card_manager = CardManager(db)
    success, msg, armies, returned = await card_manager.trade_cards(room_id, player_id, trade.card_ids)

    if not success:
        raise HTTPException(status_code=400, detail=msg)

    # Get room to update trade count
    room = await db.get(Room, room_id)
    player = await db.get(Player, player_id)
    player.armies_in_hand += armies

    await db.commit()

    return TradeCardsResponse(
        success=True,
        armies_received=armies,
        new_trade_count=room.trade_count,
        cards_returned=[]
    )


@router.get("/{room_id}/valid-trades/{player_id}")
async def get_valid_trades(room_id: int, player_id: int, db: AsyncSession = Depends(get_db)):
    """Get valid card trade combinations for a player."""
    card_manager = CardManager(db)
    combos = await card_manager.get_valid_trade_combinations(room_id, player_id)
    return {"valid_combinations": combos}


# ============================================================================
# Combat Preview (for UI)
# ============================================================================

@router.post("/{room_id}/combat-preview", response_model=dict)
async def combat_preview(room_id: int, attack: AttackRequest, db: AsyncSession = Depends(get_db)):
    """Get combat probability preview."""
    board_manager = BoardManager(db)
    combat_manager = CombatManager()

    from_country = await board_manager.get_country(room_id, attack.from_country_id)
    to_country = await board_manager.get_country(room_id, attack.to_country_id)

    if not from_country or not to_country:
        raise HTTPException(status_code=404, detail="Territorio no encontrado")

    preview = combat_manager.get_combat_preview(
        from_country.armies,
        to_country.armies,
        attack.attacker_dice
    )

    return preview


# ============================================================================
# Valid Actions
# ============================================================================

@router.get("/{room_id}/valid-targets/{country_id}/{player_id}")
async def get_valid_targets(room_id: int, country_id: int, player_id: int, action: str, db: AsyncSession = Depends(get_db)):
    """Get valid target countries for attack/fortify."""
    board_manager = BoardManager(db)

    if action == "attack":
        targets = await board_manager.get_enemy_countries_adjacent_to(room_id, country_id, player_id)
    elif action == "fortify":
        targets = await board_manager.get_own_countries_adjacent_to(room_id, country_id, player_id)
    else:
        raise HTTPException(status_code=400, detail="Acción inválida")

    return {
        "targets": [
            {
                "country_id": t.country_id,
                "armies": t.armies,
                "player_id": t.player_id,
            }
            for t in targets
        ]
    }


@router.get("/{room_id}/fortify-path/{from_id}/{to_id}/{player_id}")
async def check_fortify_path(room_id: int, from_id: int, to_id: int, player_id: int, db: AsyncSession = Depends(get_db)):
    """Check if a fortification path exists."""
    board_manager = BoardManager(db)
    path = await board_manager.find_path(room_id, from_id, to_id, player_id)

    return {
        "valid": path is not None,
        "path": path
    }