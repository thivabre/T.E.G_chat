"""
TEG Web - Main FastAPI Application
Entry point with lifespan, CORS, static files, and WebSocket endpoint
"""

import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from .config import settings
from .database import init_db, close_db, get_db
from .api import rooms_router, game_router, chat_router
from .websocket.manager import manager, Connection
from .websocket.handlers import WebSocketHandler
from .websocket.events import deserialize_client_event, ClientEventType


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    # Startup
    await init_db()
    print("Database initialized")

    yield

    # Shutdown
    await close_db()
    print("Database connections closed")


# Create FastAPI app
app = FastAPI(
    title="TEG Web",
    description="Digital version of the classic TEG board game",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs" if settings.DEBUG else None,
    redoc_url="/api/redoc" if settings.DEBUG else None,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers
app.include_router(rooms_router, prefix="/api")
app.include_router(game_router, prefix="/api")
app.include_router(chat_router, prefix="/api")

# Static files (frontend)
frontend_dir = os.path.join(os.path.dirname(__file__), "..", "..", "frontend")
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

    @app.get("/", response_class=HTMLResponse)
    async def serve_lobby():
        """Serve lobby page."""
        index_path = os.path.join(frontend_dir, "index.html")
        if os.path.exists(index_path):
            return FileResponse(index_path)
        return HTMLResponse("<h1>TEG Web - Frontend not built</h1>")

    @app.get("/game.html", response_class=HTMLResponse)
    async def serve_game():
        """Serve game page."""
        game_path = os.path.join(frontend_dir, "game.html")
        if os.path.exists(game_path):
            return FileResponse(game_path)
        return HTMLResponse("<h1>TEG Web - Game page not found</h1>")


# ============================================================================
# WebSocket Endpoint
# ============================================================================

@app.websocket("/ws/{room_id}")
async def websocket_endpoint(
    websocket: WebSocket,
    room_id: int,
    name: str = None,
    spectate: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """
    WebSocket endpoint for real-time game communication.
    Connect as player (by name) or spectator (by name with spectate=true).
    The name is used to find or create the player/spectator in the room.
    """
    print(f"DEBUG WS HANDLER CALLED: room={room_id} name={name}", flush=True)
    # Verify room exists
    from .models import Room
    room = await db.get(Room, room_id)
    if not room:
        await websocket.close(code=4004, reason="Room not found")
        return

    connection: Connection = None

    try:
        print(f"DEBUG WS: Starting handshake for room={room_id} name={name}")
        if name:
            # Connect as player by name
            from .models import Player, RoomTypeEnum
            # Check if player already exists in this room
            result = await db.execute(
                select(Player).where(Player.room_id == room_id, Player.name == name)
            )
            player = result.scalar_one_or_none()

            if player:
                # Player already exists, connect as player
                connection = await manager.connect_player(websocket, room_id, player.id)
            else:
                # Create new player - find next available ID and assign color
                # Count existing players to determine new ID
                result = await db.execute(
                    select(func.count(Player.id)).where(Player.room_id == room_id)
                )
                player_count = result.scalar_one()
                new_player_id = player_count + 1

                # Assign a color based on number of players
                from .models import PlayerStatusEnum
                color_map = {
                    1: "#FF5733", 2: "#33C1FF", 3: "#FFBD33",
                    4: "#7D33FF", 5: "#33FF57", 6: "#FF33A8"
                }
                color = color_map.get(min(new_player_id, 6), "#FFFFFF")

                player = Player(
                    id=new_player_id,
                    room_id=room_id,
                    name=name,
                    color=color,
                    status=PlayerStatusEnum.active,
                    is_host=(player_count == 0),
                    armies_in_hand=0
                )
                db.add(player)
                await db.commit()
                await db.refresh(player)

                connection = await manager.connect_player(websocket, room_id, player.id)
        elif spectate:
            # Connect as spectator by name
            from .models import Spectator
            # Check if spectator already exists in this room
            result = await db.execute(
                select(Spectator).where(Spectator.room_id == room_id, Spectator.name == name)
            )
            spectator = result.scalar_one_or_none()

            if spectator:
                # Spectator already exists
                connection = await manager.connect_spectator(websocket, room_id, spectator.id)
            else:
                # Create new spectator
                result = await db.execute(
                    select(func.count(Spectator.id)).where(Spectator.room_id == room_id)
                )
                spectator_count = result.scalar_one()
                new_spectator_id = spectator_count + 1

                spectator = Spectator(
                    id=new_spectator_id,
                    room_id=room_id,
                    name=name,
                )
                db.add(spectator)
                await db.commit()
                await db.refresh(spectator)

                connection = await manager.connect_spectator(websocket, room_id, spectator.id)
        else:
            await websocket.close(code=4000, reason="Must provide name or spectate")
            return

        # Create handler
        handler = WebSocketHandler(db)

        # Send initial state
        await handler._send_state_to_connection(connection, room)

        # Main message loop
        while True:
            try:
                data = await websocket.receive_text()
                print(f"DEBUG WS RECEIVED: {data[:200]}", flush=True)
                event = deserialize_client_event(data)
                print(f"DEBUG WS EVENT: {event.event}", flush=True)
                await handler.handle_event(connection, event)
            except WebSocketDisconnect:
                break
            except Exception as e:
                print(f"WebSocket error: {e}")
                await manager.send_error(connection, str(e), "WS_ERROR")

    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"WebSocket connection error: {e}")
    finally:
        if connection:
            manager.disconnect(connection)


# ============================================================================
# Health Check
# ============================================================================

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "TEG Web",
        "version": "1.0.0"
    }


# ============================================================================
# Run with uvicorn
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
    )