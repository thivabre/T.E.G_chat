"""
TEG Web - WebSocket Event Handlers
Handles all client -> server WebSocket events
"""

import json
import os
from typing import Optional, Dict, Any, List
from datetime import datetime
from fastapi import WebSocket
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..models import (
    Room, Player, Spectator, GameCountry, GameCard, PlayerObjective,
    GamePhaseEnum, PlayerStatusEnum, RoomStatusEnum, ChatTypeEnum, TurnTimer
)
from ..schemas import GameStateResponse, PlayerGameState, GameCountryResponse
from ..game_logic import (
    BoardManager, CombatManager, CardManager, ObjectiveManager,
    TurnManager, ReinforcementManager
)
from .manager import manager, Connection
from .events import (
    ClientEventType, ServerEventType, ClientEvent,
    JoinRoomPayload, LeaveRoomPayload, StartGamePayload,
    PlaceArmiesPayload, ReinforcePayload, AttackPayload,
    FortifyPayload, TradeCardsPayload, EndTurnPayload,
    SendChatPayload, RequestStatePayload, SpectatePayload, PingPayload
)

# Load map SVG at module level for performance
_MAP_SVG_CACHE = None

def _get_map_svg() -> str:
    """Load and cache the map SVG."""
    global _MAP_SVG_CACHE
    if _MAP_SVG_CACHE is not None:
        return _MAP_SVG_CACHE

    # Try multiple paths for the map file
    possible_paths = [
        os.path.join(os.path.dirname(__file__), "..", "..", "..", "frontend", "assets", "map", "teg-map.svg"),
        os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "assets", "map", "teg-map.svg"),
        "/app/frontend/assets/map/teg-map.svg",
    ]

    for path in possible_paths:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                _MAP_SVG_CACHE = f.read()
            return _MAP_SVG_CACHE

    # Return a fallback empty SVG if not found
    _MAP_SVG_CACHE = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 700"><text x="600" y="350" text-anchor="middle">Map not found</text></svg>'
    return _MAP_SVG_CACHE


class WebSocketHandler:
    """Handles WebSocket events for the game."""

    def __init__(self, session: AsyncSession):
        self.session = session
        self.board_manager = BoardManager(session)
        self.combat_manager = CombatManager()
        self.card_manager = CardManager(session)
        self.objective_manager = ObjectiveManager(session)
        self.turn_manager = TurnManager(session)
        self.reinforcement_manager = ReinforcementManager(session)

    # ========================================================================
    # Main Event Dispatcher
    # ========================================================================

    async def handle_event(
        self,
        connection: Connection,
        event: ClientEvent
    ) -> None:
        """Dispatch event to appropriate handler."""
        handlers = {
            ClientEventType.JOIN_ROOM: self.handle_join_room,
            ClientEventType.LEAVE_ROOM: self.handle_leave_room,
            ClientEventType.START_GAME: self.handle_start_game,
            ClientEventType.PLACE_ARMIES: self.handle_place_armies,
            ClientEventType.REINFORCE: self.handle_reinforce,
            ClientEventType.ATTACK: self.handle_attack,
            ClientEventType.FORTIFY: self.handle_fortify,
            ClientEventType.TRADE_CARDS: self.handle_trade_cards,
            ClientEventType.END_TURN: self.handle_end_turn,
            ClientEventType.SEND_CHAT: self.handle_send_chat,
            ClientEventType.REQUEST_STATE: self.handle_request_state,
            ClientEventType.SPECTATE: self.handle_spectate,
            ClientEventType.PING: self.handle_ping,
        }

        handler = handlers.get(event.event)
        if handler:
            try:
                await handler(connection, event.data, event.request_id)
            except Exception as e:
                await manager.send_error(connection, str(e), "HANDLER_ERROR", event.event.value)
        else:
            await manager.send_error(connection, f"Unknown event: {event.event}", "UNKNOWN_EVENT", event.event.value)

    # ========================================================================
    # Helper Methods
    # ========================================================================

    async def _get_room(self, room_id: int) -> Optional[Room]:
        """Get room with relationships loaded."""
        result = await self.session.execute(
            select(Room).where(Room.id == room_id)
        )
        return result.scalar_one_or_none()

    async def _get_player(self, room_id: int, player_id: int) -> Optional[Player]:
        """Get player in room."""
        result = await self.session.execute(
            select(Player).where(
                Player.room_id == room_id,
                Player.id == player_id
            )
        )
        return result.scalar_one_or_none()

    async def _verify_player_turn(self, room: Room, player_id: int) -> bool:
        """Verify it's the player's turn."""
        return room.current_turn_player_id == player_id

    async def _build_game_state(self, room: Room) -> Dict:
        """Build complete game state for sync."""
        # Get players
        result = await self.session.execute(
            select(Player).where(Player.room_id == room.id).order_by(Player.position)
        )
        players = result.scalars().all()

        # Get countries
        result = await self.session.execute(
            select(GameCountry).where(GameCountry.room_id == room.id)
        )
        countries = result.scalars().all()

        # Build player game states
        player_states = []
        for p in players:
            p_countries = [c for c in countries if c.player_id == p.id]
            p_cards = await self.card_manager.get_player_cards(room.id, p.id)
            p_obj = await self.objective_manager.get_objective_progress(room.id, p.id)

            player_states.append(PlayerGameState(
                id=p.id,
                name=p.name,
                color=p.color,
                position=p.position,
                status=p.status,
                armies_in_hand=p.armies_in_hand,
                countries_count=len(p_countries),
                total_armies=sum(c.armies for c in p_countries),
                cards_count=len(p_cards),
                cards=[await self.card_manager.get_card_display_info(c) for c in p_cards],
                objective=p_obj,
                is_host=p.is_host,
                is_current_turn=p.id == room.current_turn_player_id
            ))

        # Build country states
        country_states = []
        for gc in countries:
            country_states.append(GameCountryResponse(
                id=gc.id,
                room_id=gc.room_id,
                country_id=gc.country_id,
                country_name="",  # Would need join
                continent_name="",
                player_id=gc.player_id,
                player_name="",
                player_color="",
                armies=gc.armies
            ))

        # Get timer
        timer = await self.turn_manager.get_turn_timer(room.id)
        timer_expires = timer.expires_at if timer else None

        return {
            "room": {
                "id": room.id,
                "code": room.code,
                "name": room.name,
                "type": room.type.value,
                "status": room.status.value,
                "max_players": room.max_players,
                "game_mode": room.game_mode.value,
                "turn_time_limit": room.turn_time_limit,
                "host_id": room.host_id,
                "host_name": "",  # Would need join
                "current_turn_player_id": room.current_turn_player_id,
                "current_phase": room.current_phase.value,
                "turn_number": room.turn_number,
                "trade_count": room.trade_count,
                "created_at": room.created_at,
                "started_at": room.started_at,
                "finished_at": room.finished_at,
            },
            "current_phase": room.current_phase.value,
            "current_turn_player_id": room.current_turn_player_id,
            "players": [ps.model_dump() for ps in player_states],
            "countries": [cs.model_dump() for cs in country_states],
            "continents": [],  # TODO: populate from board manager
            "borders": [],  # TODO: populate from board manager
            "map_svg": _get_map_svg(),
            "turn_number": room.turn_number,
            "trade_count": room.trade_count,
            "timer_expires_at": timer_expires,
            "can_trade_cards": False,  # Would check
            "must_trade_cards": False,  # Would check
        }

    async def _send_state_to_connection(self, connection: Connection, room: Room) -> None:
        """Send current game state to a connection."""
        try:
            from ..models import Player
            result = await self.session.execute(
                select(Player).where(Player.room_id == room.id).order_by(Player.position)
            )
            players = result.scalars().all()

            event = ServerEvent(
                event=ServerEventType.STATE_UPDATE,
                data={
                    "room": {
                        "id": room.id,
                        "code": room.code,
                        "name": room.name,
                        "status": room.status.value if hasattr(room.status, 'value') else str(room.status),
                        "current_phase": room.current_phase.value if hasattr(room.current_phase, 'value') else str(room.current_phase),
                    },
                    "players": [
                        {
                            "id": p.id,
                            "name": p.name,
                            "color": p.color,
                            "position": p.position,
                            "is_host": p.is_host,
                        }
                        for p in players
                    ],
                    "countries": [],
                }
            )
            await manager.send_to_connection(connection, event)
        except Exception as e:
            print(f"ERROR _send_state_to_connection: {e}", flush=True)
            # Send minimal state
            try:
                event = ServerEvent(
                    event=ServerEventType.STATE_UPDATE,
                    data={"room": {"id": room.id, "code": room.code, "name": room.name}, "players": [], "countries": []}
                )
                await manager.send_to_connection(connection, event)
            except Exception as e2:
                print(f"ERROR sending minimal state: {e2}", flush=True)

    # ========================================================================
    # Event Handlers
    # ========================================================================

    async def handle_join_room(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle player joining a room."""
        payload = JoinRoomPayload(**data)
        room = await self._get_room(payload.room_id)

        if not room:
            await manager.send_error(connection, "Partida no encontrada", "ROOM_NOT_FOUND")
            return

        if payload.as_spectator:
            # Handle as spectator (would need spectator creation)
            await manager.send_error(connection, "Use spectate event for spectators", "USE_SPECTATE")
            return

        # Find or create player
        # For simplicity, assume player already exists in room
        # In reality, player joins via REST API first, then connects via WS
        player = await self._get_player(payload.room_id, connection.player_id)

        if not player:
            await manager.send_error(connection, "No eres parte de esta partida", "NOT_IN_ROOM")
            return

        # Send current room state
        await self._send_state_to_connection(connection, room)

        # Notify others
        await self._broadcast_room_update(room)

    async def handle_leave_room(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle player leaving room."""
        payload = LeaveRoomPayload(**data)
        # Just disconnect - manager handles cleanup
        manager.disconnect(connection)

    async def handle_start_game(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle game start (host only)."""
        payload = StartGamePayload(**data)
        room = await self._get_room(payload.room_id)

        if not room:
            await manager.send_error(connection, "Partida no encontrada", "ROOM_NOT_FOUND")
            return

        # Verify host
        player = await self._get_player(payload.room_id, connection.player_id)
        if not player or not player.is_host:
            await manager.send_error(connection, "Solo el host puede iniciar la partida", "NOT_HOST")
            return

        if room.status != RoomStatusEnum.waiting:
            await manager.send_error(connection, "La partida ya comenzó", "ALREADY_STARTED")
            return

        # Check minimum players
        result = await self.session.execute(
            select(func.count(Player.id)).where(
                Player.room_id == room.id,
                Player.status == PlayerStatusEnum.active
            )
        )
        player_count = result.scalar() or 0

        if player_count < 2:
            await manager.send_error(connection, "Se necesitan al menos 2 jugadores", "NOT_ENOUGH_PLAYERS")
            return

        # Initialize game
        players_result = await self.session.execute(
            select(Player).where(
                Player.room_id == room.id,
                Player.status == PlayerStatusEnum.active
            ).order_by(Player.position)
        )
        players = players_result.scalars().all()

        await self.board_manager.initialize_game(room, players)

        # Start game
        first_player, initial_armies = await self.turn_manager.start_game(room)

        await self.session.commit()

        # Send game started to all
        game_state = await self._build_game_state(room)
        await manager.send_game_started(room.id, game_state)

    async def handle_place_armies(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle placing initial army during setup phase."""
        payload = PlaceArmiesPayload(**data)
        room = await self._get_room(payload.room_id)

        if not room or room.current_phase != GamePhaseEnum.setup:
            await manager.send_error(connection, "No es la fase de preparación", "WRONG_PHASE")
            return

        player = await self._get_player(payload.room_id, connection.player_id)
        if not player or not await self._verify_player_turn(room, player.id):
            await manager.send_error(connection, "No es tu turno", "NOT_YOUR_TURN")
            return

        # Verify country belongs to player
        can_place = await self.board_manager.can_place_army(payload.room_id, payload.country_id, player.id)
        if not can_place:
            await manager.send_error(connection, "No puedes colocar ahí", "INVALID_PLACEMENT")
            return

        # Place army (already has 1, this adds 1 more during setup)
        await self.board_manager.add_armies(payload.room_id, payload.country_id, 1)
        player.armies_in_hand -= 1

        await self.session.commit()

        # Check if setup complete
        if await self.turn_manager.is_setup_complete(room):
            next_player, armies = await self.turn_manager.complete_setup(room)
            await self.session.commit()

            # Notify turn change
            await manager.send_turn_change(
                room.id,
                next_player.id,
                next_player.name,
                next_player.color,
                GamePhaseEnum.reinforcement.value,
                None,  # timer
                room.turn_number,
                armies
            )
        else:
            # Next player in setup (rotational)
            # For simplicity, just update state
            pass

        # Send state update
        await self._broadcast_state_update(room)

    async def handle_reinforce(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle reinforcement phase."""
        payload = ReinforcePayload(**data)
        room = await self._get_room(payload.room_id)

        if not room or room.current_phase != GamePhaseEnum.reinforcement:
            await manager.send_error(connection, "No es la fase de refuerzo", "WRONG_PHASE")
            return

        player = await self._get_player(payload.room_id, connection.player_id)
        if not player or not await self._verify_player_turn(room, player.id):
            await manager.send_error(connection, "No es tu turno", "NOT_YOUR_TURN")
            return

        # Validate
        valid, msg = await self.reinforcement_manager.validate_reinforcement(
            payload.room_id, player.id, payload.country_id, payload.armies
        )
        if not valid:
            await manager.send_error(connection, msg, "INVALID_REINFORCEMENT")
            return

        # Apply
        await self.reinforcement_manager.apply_reinforcement(
            payload.room_id, player.id, payload.country_id, payload.armies
        )

        await self.session.commit()
        await self._broadcast_state_update(room)

    async def handle_attack(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle attack action."""
        payload = AttackPayload(**data)
        room = await self._get_room(payload.room_id)

        if not room or room.current_phase != GamePhaseEnum.attack:
            await manager.send_error(connection, "No es la fase de ataque", "WRONG_PHASE")
            return

        player = await self._get_player(payload.room_id, connection.player_id)
        if not player or not await self._verify_player_turn(room, player.id):
            await manager.send_error(connection, "No es tu turno", "NOT_YOUR_TURN")
            return

        # Get countries
        from_country = await self.board_manager.get_country(payload.room_id, payload.from_country_id)
        to_country = await self.board_manager.get_country(payload.room_id, payload.to_country_id)

        if not from_country or from_country.player_id != player.id:
            await manager.send_error(connection, "Territorio de origen inválido", "INVALID_FROM")
            return

        if not to_country or to_country.player_id == player.id:
            await manager.send_error(connection, "Territorio de destino inválido", "INVALID_TO")
            return

        if to_country.player_id is None:
            await manager.send_error(connection, "No puedes atacar territorio neutral", "NEUTRAL_TARGET")
            return

        # Check adjacency
        adjacent = await self.board_manager.get_enemy_countries_adjacent_to(
            payload.room_id, payload.from_country_id, player.id
        )
        if not any(c.country_id == payload.to_country_id for c in adjacent):
            await manager.send_error(connection, "Territorios no son adyacentes", "NOT_ADJACENT")
            return

        # Validate dice
        valid, msg = self.combat_manager.validate_attack(
            from_country.armies,
            to_country.armies,
            payload.attacker_dice
        )
        if not valid:
            await manager.send_error(connection, msg, "INVALID_DICE")
            return

        # Resolve combat
        defender_dice = self.combat_manager.calculate_max_defender_dice(to_country.armies)
        result = self.combat_manager.simulate_combat(
            from_country.armies,
            to_country.armies,
            max_attacker_dice=payload.attacker_dice,
            max_defender_dice=defender_dice
        )

        # Apply losses
        await self.board_manager.remove_armies(payload.room_id, payload.from_country_id, result.total_attacker_losses)
        await self.board_manager.remove_armies(payload.room_id, payload.to_country_id, result.total_defender_losses)

        conquered = False
        conquered_countries = []

        if result.conquered:
            # Attacker must move at least attacker_dice armies, up to from_country.armies - 1
            move_armies = min(payload.attacker_dice, from_country.armies - result.total_attacker_losses - 1)
            move_armies = max(payload.attacker_dice, move_armies)  # At least dice count

            await self.board_manager.conquer_country(
                payload.room_id,
                payload.to_country_id,
                player.id,
                move_armies
            )

            # Remove from attacker
            await self.board_manager.remove_armies(payload.room_id, payload.from_country_id, move_armies)

            conquered = True
            conquered_countries.append(payload.to_country_id)

            # Draw card
            drawn_card = await self.card_manager.draw_card(payload.room_id, player.id)
            if drawn_card:
                card_info = await self.card_manager.get_card_display_info(drawn_card)
                await manager.send_card_drawn(payload.room_id, card_info, player.id)

            # Check objectives
            obj_result = await self.objective_manager.check_victory(payload.room_id, player.id)
            if obj_result and obj_result.completed:
                await manager.send_objective_complete(
                    payload.room_id,
                    player.id,
                    player.name,
                    obj_result.details,
                    obj_result.completed_at
                )

                # Game over - objective completed
                room.status = RoomStatusEnum.finished
                room.winner_id = player.id
                room.finished_at = func.now()
                await self.session.commit()

                await manager.send_game_over(
                    payload.room_id,
                    player.id,
                    player.name,
                    player.color,
                    room.game_mode.value
                )
                return

            # Check world conquest
            if room.game_mode.value == "conquista":
                winner = await self.objective_manager.check_world_conquest_victory(payload.room_id)
                if winner:
                    room.status = RoomStatusEnum.finished
                    room.winner_id = winner.id
                    room.finished_at = func.now()
                    await self.session.commit()

                    await manager.send_game_over(
                        payload.room_id,
                        winner.id,
                        winner.name,
                        winner.color,
                        room.game_mode.value
                    )
                    return

            # Check if defender eliminated
            defender = await self._get_player(payload.room_id, to_country.player_id)
            if defender:
                defender_countries = await self.board_manager.get_player_countries(payload.room_id, defender.id)
                if not defender_countries:
                    defender.status = PlayerStatusEnum.eliminated
                    defender.eliminated_at = func.now()
                    defender.eliminated_by = player.id

                    # Transfer cards to attacker
                    defender_cards = await self.card_manager.get_player_cards(payload.room_id, defender.id)
                    for gc in defender_cards:
                        gc.player_id = player.id
                        await self.session.flush()

                    if len(defender_cards) >= 5:
                        # Must trade immediately
                        pass

                    await manager.send_player_eliminated(
                        payload.room_id,
                        defender.id,
                        defender.name,
                        player.id,
                        player.name,
                        conquered_countries
                    )

        await self.session.commit()

        # Send combat result
        await manager.send_combat_result(
            payload.room_id,
            result.rolls[-1].attacker_rolls if result.rolls else [],
            result.rolls[-1].defender_rolls if result.rolls else [],
            result.total_attacker_losses,
            result.total_defender_losses,
            conquered,
            from_country.armies - result.total_attacker_losses - (move_armies if conquered else 0),
            max(0, to_country.armies - result.total_defender_losses),
            payload.from_country_id,
            payload.to_country_id
        )

        await self._broadcast_state_update(room)

    async def handle_fortify(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle fortification action."""
        payload = FortifyPayload(**data)
        room = await self._get_room(payload.room_id)

        if not room or room.current_phase != GamePhaseEnum.fortify:
            await manager.send_error(connection, "No es la fase de fortificación", "WRONG_PHASE")
            return

        player = await self._get_player(payload.room_id, connection.player_id)
        if not player or not await self._verify_player_turn(room, player.id):
            await manager.send_error(connection, "No es tu turno", "NOT_YOUR_TURN")
            return

        # Check both countries belong to player
        from_country = await self.board_manager.get_country(payload.room_id, payload.from_country_id)
        to_country = await self.board_manager.get_country(payload.room_id, payload.to_country_id)

        if not from_country or from_country.player_id != player.id:
            await manager.send_error(connection, "Territorio de origen no es tuyo", "INVALID_FROM")
            return

        if not to_country or to_country.player_id != player.id:
            await manager.send_error(connection, "Territorio de destino no es tuyo", "INVALID_TO")
            return

        if from_country.armies <= payload.armies:
            await manager.send_error(connection, "Debes dejar al menos 1 ejército", "NOT_ENOUGH_ARMIES")
            return

        # Check path exists through owned territories
        path = await self.board_manager.find_path(
            payload.room_id,
            payload.from_country_id,
            payload.to_country_id,
            player.id
        )
        if not path:
            await manager.send_error(connection, "No hay ruta conectada entre los territorios", "NO_PATH")
            return

        # Move armies
        await self.board_manager.move_armies(
            payload.room_id,
            payload.from_country_id,
            payload.to_country_id,
            payload.armies
        )

        await self.session.commit()
        await self._broadcast_state_update(room)

    async def handle_trade_cards(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle card trading."""
        payload = TradeCardsPayload(**data)
        room = await self._get_room(payload.room_id)

        if not room:
            await manager.send_error(connection, "Partida no encontrada", "ROOM_NOT_FOUND")
            return

        player = await self._get_player(payload.room_id, connection.player_id)
        if not player:
            await manager.send_error(connection, "Jugador no encontrado", "PLAYER_NOT_FOUND")
            return

        # Can trade during reinforcement phase or if forced
        if room.current_phase != GamePhaseEnum.reinforcement and room.current_phase != GamePhaseEnum.trade_cards:
            await manager.send_error(connection, "Solo puedes canjear en fase de refuerzo", "WRONG_PHASE")
            return

        success, msg, armies, returned = await self.card_manager.trade_cards(
            payload.room_id, player.id, payload.card_ids
        )

        if not success:
            await manager.send_error(connection, msg, "TRADE_FAILED")
            return

        player.armies_in_hand += armies

        await self.session.commit()

        await manager.send_cards_traded(
            payload.room_id,
            True,
            armies,
            room.trade_count,
            [await self.card_manager.get_card_display_info(c) for c in returned]
        )

        await self._broadcast_state_update(room)

    async def handle_end_turn(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle end of turn."""
        payload = EndTurnPayload(**data)
        room = await self._get_room(payload.room_id)

        if not room:
            await manager.send_error(connection, "Partida no encontrada", "ROOM_NOT_FOUND")
            return

        player = await self._get_player(payload.room_id, connection.player_id)
        if not player or not await self._verify_player_turn(room, player.id):
            await manager.send_error(connection, "No es tu turno", "NOT_YOUR_TURN")
            return

        # Can only end turn in fortify phase (or attack if skipping)
        if room.current_phase not in (GamePhaseEnum.attack, GamePhaseEnum.fortify):
            await manager.send_error(connection, "No puedes terminar turno en esta fase", "WRONG_PHASE")
            return

        # If in attack phase, skip to fortify
        if room.current_phase == GamePhaseEnum.attack:
            await self.turn_manager.skip_to_fortify(room, player)
            await self.session.commit()
            await self._broadcast_state_update(room)
            return

        # End turn - move to next player
        next_player, next_phase, armies = await self.turn_manager.end_turn(room)
        await self.session.commit()

        # Check for card draw at end of turn if conquered
        # (handled in attack)

        # Notify turn change
        await manager.send_turn_change(
            room.id,
            next_player.id,
            next_player.name,
            next_player.color,
            next_phase.value,
            None,  # timer
            room.turn_number,
            armies
        )

        await self._broadcast_state_update(room)

    async def handle_send_chat(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle chat message."""
        payload = SendChatPayload(**data)
        room = await self._get_room(payload.room_id)

        if not room:
            await manager.send_error(connection, "Partida no encontrada", "ROOM_NOT_FOUND")
            return

        player = await self._get_player(payload.room_id, connection.player_id)
        if not player:
            await manager.send_error(connection, "Jugador no encontrado", "PLAYER_NOT_FOUND")
            return

        # Create chat message
        from ..models import ChatMessage
        chat_msg = ChatMessage(
            room_id=payload.room_id,
            sender_id=player.id,
            recipient_id=payload.recipient_id,
            type=ChatTypeEnum(payload.type),
            message=payload.message
        )
        self.session.add(chat_msg)
        await self.session.flush()

        # Send to appropriate recipients
        message_data = {
            "id": chat_msg.id,
            "room_id": chat_msg.room_id,
            "sender_id": chat_msg.sender_id,
            "sender_name": player.name,
            "sender_color": player.color,
            "recipient_id": chat_msg.recipient_id,
            "type": chat_msg.type.value,
            "message": chat_msg.message,
            "sent_at": chat_msg.sent_at,
        }

        await manager.send_chat_message(
            payload.room_id,
            message_data,
            sender_player_id=player.id
        )

    async def handle_request_state(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle state sync request."""
        payload = RequestStatePayload(**data)
        room = await self._get_room(payload.room_id)

        if not room:
            await manager.send_error(connection, "Partida no encontrada", "ROOM_NOT_FOUND")
            return

        await self._send_state_to_connection(connection, room)

    async def handle_spectate(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle spectator joining."""
        payload = SpectatePayload(**data)
        room = await self._get_room(payload.room_id)

        if not room:
            await manager.send_error(connection, "Partida no encontrada", "ROOM_NOT_FOUND")
            return

        # Create spectator
        spectator = Spectator(
            room_id=payload.room_id,
            name=payload.spectator_name
        )
        self.session.add(spectator)
        await self.session.flush()

        # Update connection
        connection.is_spectator = True
        connection.spectator_id = spectator.id
        connection.player_id = None

        # Send state
        await self._send_state_to_connection(connection, room)

        # Notify room
        await self._broadcast_room_update(room)

    async def handle_ping(
        self,
        connection: Connection,
        data: Dict[str, Any],
        request_id: Optional[str]
    ) -> None:
        """Handle ping."""
        payload = PingPayload(**data)
        await manager.handle_ping(connection, payload.timestamp)

    # ========================================================================
    # Broadcast Helpers
    # ========================================================================

    async def _broadcast_state_update(self, room: Room) -> None:
        """Broadcast state update to all in room."""
        state = await self._build_game_state(room)
        await manager.send_state_update(room.id, state)

    async def _broadcast_room_update(self, room: Room) -> None:
        """Broadcast room update to all in room."""
        # Get players
        result = await self.session.execute(
            select(Player).where(Player.room_id == room.id).order_by(Player.position)
        )
        players = result.scalars().all()

        # Get spectators
        result = await self.session.execute(
            select(Spectator).where(Spectator.room_id == room.id)
        )
        spectators = result.scalars().all()

        room_data = {
            "id": room.id,
            "code": room.code,
            "name": room.name,
            "type": room.type.value,
            "status": room.status.value,
            "max_players": room.max_players,
            "game_mode": room.game_mode.value,
            "turn_time_limit": room.turn_time_limit,
            "host_id": room.host_id,
            "current_turn_player_id": room.current_turn_player_id,
            "current_phase": room.current_phase.value,
            "turn_number": room.turn_number,
            "trade_count": room.trade_count,
            "created_at": room.created_at,
            "started_at": room.started_at,
            "finished_at": room.finished_at,
        }

        players_data = [
            {
                "id": p.id,
                "name": p.name,
                "color": p.color,
                "position": p.position,
                "status": p.status.value,
                "armies_in_hand": p.armies_in_hand,
                "is_host": p.is_host,
                "is_ready": p.is_ready,
                "joined_at": p.joined_at,
                "eliminated_at": p.eliminated_at,
                "eliminated_by": p.eliminated_by,
            }
            for p in players
        ]

        spectators_data = [
            {
                "id": s.id,
                "name": s.name,
                "joined_at": s.joined_at,
                "left_at": s.left_at,
            }
            for s in spectators
        ]

        await manager.send_room_update(room.id, room_data, players_data, spectators_data)