import asyncio
import sys
sys.path.insert(0, r'C:\Users\Thiago\teg-web\backend')

import httpx

async def test():
    async with httpx.AsyncClient() as client:
        # Test health
        r = await client.get("http://localhost:8000/health")
        print(f"Health: {r.status_code} - {r.json()}")

        # Test create room
        r = await client.post("http://localhost:8000/api/rooms", json={
            "name": "Test Room",
            "host_name": "Player1",
            "type": "publica",
            "max_players": 4,
            "game_mode": "objetivos"
        })
        print(f"Create Room: {r.status_code} - {r.text}")

        if r.status_code == 201:
            room = r.json()
            print(f"Room created: {room}")

            # Test join room
            r = await client.post("http://localhost:8000/api/rooms/join-by-code", json={
                "code": room["code"],
                "player_name": "Player2"
            })
            print(f"Join Room: {r.status_code} - {r.text}")

            # Test list public rooms
            r = await client.get("http://localhost:8000/api/rooms/public")
            print(f"List Rooms: {r.status_code} - {r.json()}")

asyncio.run(test())