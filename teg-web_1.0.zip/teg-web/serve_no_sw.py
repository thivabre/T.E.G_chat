"""Serve frontend without service worker, no cache, no nginx.

NOTA: este server es solo para previsualizar los archivos estáticos del
frontend de forma aislada (sin backend). Las llamadas a /api y al
WebSocket /ws NO van a funcionar acá — para jugar de verdad hay que
correr unified_server.py, que sirve frontend + backend juntos.
"""
import http.server
import socketserver
import os
import sys
from pathlib import Path

PORT = int(os.environ.get("TEG_FRONTEND_PORT", "8080"))
FRONTEND_DIR = str(Path(__file__).resolve().parent / "frontend")

class NoCacheHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Service-Worker-Allowed', '/')
        super().end_headers()

    def do_GET(self):
        # Unregister any service worker
        if self.path == '/sw.js':
            self.send_response(200)
            self.send_header('Content-Type', 'application/javascript')
            self.end_headers()
            self.wfile.write(b'self.addEventListener("install", e => self.skipWaiting()); self.addEventListener("activate", e => self.clients.claim());')
            return
        super().do_GET()

if __name__ == '__main__':
    os.chdir(FRONTEND_DIR)
    handler = NoCacheHandler
    with socketserver.TCPServer(("", PORT), handler) as httpd:
        print(f"Serving {FRONTEND_DIR} at http://localhost:{PORT}/")
        httpd.serve_forever()
