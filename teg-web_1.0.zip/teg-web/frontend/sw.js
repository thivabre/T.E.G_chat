console.log("SW disabled - no caching"); self.addEventListener("install", () => self.skipWaiting());
