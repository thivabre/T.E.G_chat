#!/usr/bin/env python3
"""
TEG - Servidor Unificado (reescrito desde cero)
Sirve frontend estatico + API REST + WebSocket en un solo proceso.
Sin Docker, sin nginx. Solo Python.
"""
import os
import sys
import json
import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any

# Setup path y env ANTES de importar nada
SCRIPT_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = SCRIPT_DIR / "frontend"
os.environ.setdefault("DATABASE_URL", "mysql+aiomysql://teg_user:teg_password@127.0.0.1:3307/teg_web")
# teg_data.py vive al lado de este archivo — asegurar que se pueda importar
# sin importar desde qué directorio se invoque este script.
sys.path.insert(0, str(SCRIPT_DIR))

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import aiomysql
import random

from teg_data import (
    ALL_COUNTRY_IDS, COUNTRY_NAME, COUNTRY_CONTINENT,
    ADJACENCY, borders_as_pairs, continents_payload,
    calculate_reinforcements, fully_owned_continents,
)

# Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger("teg")

# =============================================================================
# DB
# =============================================================================
DB_CONFIG = {
    "host": os.environ.get("TEG_DB_HOST", "127.0.0.1"),
    "port": int(os.environ.get("TEG_DB_PORT", "3307")),
    "user": os.environ.get("TEG_DB_USER", "teg_user"),
    "password": os.environ.get("TEG_DB_PASSWORD", "teg_password"),
    "db": os.environ.get("TEG_DB_NAME", "teg_web"),
    "autocommit": True,
    "charset": "utf8mb4",
}

def jsonify_dt(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)

def row_to_dict(row: dict) -> dict:
    return {k: jsonify_dt(v) for k, v in row.items()}

async def query(sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
    conn = await aiomysql.connect(**DB_CONFIG)
    try:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute(sql, params)
            rows = await cur.fetchall()
        return rows
    finally:
        conn.close()

async def execute(sql: str, params: tuple = ()) -> int:
    conn = await aiomysql.connect(**DB_CONFIG)
    try:
        async with conn.cursor() as cur:
            await cur.execute(sql, params)
            return cur.lastrowid
    finally:
        conn.close()

async def call_proc(proc_name: str, params: tuple = ()) -> List[Dict[str, Any]]:
    """CALL sp_x(p1, p2, ...) y devuelve el/los result set(s) que produzca
    (p.ej. el SELECT LAST_INSERT_ID() final de sp_crear_partida)."""
    conn = await aiomysql.connect(**DB_CONFIG)
    try:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            placeholders = ", ".join(["%s"] * len(params))
            await cur.execute(f"CALL {proc_name}({placeholders})", params)
            rows = await cur.fetchall()
        await conn.commit()
        return rows
    finally:
        conn.close()

async def call_proc_out(proc_name: str, in_params: tuple, num_out: int) -> dict:
    """CALL sp_x(p1, p2, ..., @out0, @out1, ...) y después SELECT @out0, ...
    en la MISMA conexión (las variables de sesión @out no sobreviven entre
    conexiones distintas, por eso este helper no reutiliza query()/execute()).
    Devuelve un dict {"out0": valor, "out1": valor, ...}."""
    conn = await aiomysql.connect(**DB_CONFIG)
    try:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            in_placeholders = ", ".join(["%s"] * len(in_params))
            out_vars = ", ".join(f"@out{i}" for i in range(num_out))
            all_placeholders = ", ".join(p for p in [in_placeholders, out_vars] if p)
            await cur.execute(f"CALL {proc_name}({all_placeholders})", in_params)
            # drenar cualquier result set intermedio que el proc haya producido
            try:
                more = True
                while more:
                    await cur.fetchall()
                    more = await cur.nextset()
            except Exception:
                pass
            select_outs = ", ".join(f"@out{i} AS out{i}" for i in range(num_out))
            await cur.execute(f"SELECT {select_outs}")
            row = await cur.fetchone()
        await conn.commit()
        return row or {}
    finally:
        conn.close()

# =============================================================================
# FastAPI App
# =============================================================================
app = FastAPI(title="TEG Server")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Mount frontend
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

# =============================================================================
# Models (Pydantic)
# =============================================================================
class RoomCreate(BaseModel):
    name: str
    type: str = "publica"
    max_players: int = 6
    host_name: Optional[str] = None
    game_mode: Optional[str] = None
    turn_time_limit: Optional[int] = None

class JoinByCode(BaseModel):
    code: str
    player_name: str

class ChatMessage(BaseModel):
    sender: str
    message: str

# =============================================================================
# Traducción de estados: la DB usa los ENUM en español del schema académico
# (Partida.estado: esperando/en_curso/finalizada, Usuarios.estado:
# activo/eliminado/desconectado). El frontend ya espera los valores en
# inglés (waiting/in_progress/finished) de una iteración anterior de este
# proyecto — se traduce acá en vez de tocar 1300 líneas de JS.
# =============================================================================
ESTADO_PARTIDA_TO_STATUS = {"esperando": "waiting", "en_curso": "in_progress", "finalizada": "finished"}
FASE_TO_PHASE = {"refuerzo": "reinforce", "ataque": "attack", "fortificacion": "fortify"}
PHASE_TO_FASE = {v: k for k, v in FASE_TO_PHASE.items()}
PLAYER_COLORS = ["#FF5733", "#33C1FF", "#FFBD33", "#7D33FF", "#33FF57", "#FF33A8"]
TIPO_FIGURA_TO_CARD_TYPE = {"soldado": "infantry", "caballo": "cavalry", "canon": "artillery", "comodin": "wild"}


def generate_code(length: int = 6) -> str:
    import random as _r, string as _s
    return "".join(_r.choices(_s.ascii_uppercase + _s.digits, k=length))


async def get_host_id(id_partida: int) -> Optional[int]:
    """No hay columna host_id/is_host en este schema — el host es
    simplemente el jugador activo con menor orden_turno (el primero que
    entró). Si el host se va, el siguiente por orden_turno pasa a serlo
    automáticamente, sin necesidad de reasignar nada a mano."""
    rows = await query(
        "SELECT id_usuario FROM Usuarios WHERE id_partida=%s AND estado='activo' ORDER BY orden_turno LIMIT 1",
        (id_partida,)
    )
    return rows[0]["id_usuario"] if rows else None


async def get_room_dict(id_partida: int) -> Optional[dict]:
    rows = await query("SELECT * FROM Partida WHERE id_partida=%s", (id_partida,))
    if not rows:
        return None
    p = rows[0]
    users = await query(
        "SELECT id_usuario, nombre, color, orden_turno, estado FROM Usuarios WHERE id_partida=%s ORDER BY orden_turno",
        (id_partida,)
    )
    host_id = await get_host_id(id_partida)
    active_users = [u for u in users if u["estado"] == "activo"]
    host_row = next((u for u in active_users if u["id_usuario"] == host_id), None)
    return {
        "id": p["id_partida"],
        "code": p["codigo_acceso"],
        "name": p["nombre_partida"],
        "type": p["tipo"],
        "status": ESTADO_PARTIDA_TO_STATUS.get(p["estado"], p["estado"]),
        "max_players": p["max_jugadores"],
        "host_id": host_id,
        "host_name": host_row["nombre"] if host_row else None,
        "players": [
            {
                "id": u["id_usuario"], "name": u["nombre"], "color": u["color"] or "#FFFFFF",
                "position": u["orden_turno"], "is_host": u["id_usuario"] == host_id,
                "is_ready": True, "armies_in_hand": 0,
            }
            for u in active_users
        ],
    }


# =============================================================================
# API Routes
# =============================================================================
@app.get("/api/rooms/public")
async def list_public_rooms():
    rows = await query("""
        SELECT p.id_partida, p.nombre_partida, p.max_jugadores,
               COUNT(u.id_usuario) AS jugadores_actuales
        FROM Partida p
        LEFT JOIN Usuarios u ON u.id_partida = p.id_partida AND u.estado = 'activo'
        WHERE p.tipo = 'publica' AND p.estado = 'esperando'
        GROUP BY p.id_partida
        ORDER BY p.fecha_creacion DESC
        LIMIT 50
    """)
    out = []
    for r in rows:
        out.append({
            "id": r["id_partida"],
            "name": r["nombre_partida"],
            "max_players": r["max_jugadores"],
            "player_count": r["jugadores_actuales"],
            "type": "publica",
        })
    return out


@app.get("/api/rooms/{room_id}")
async def get_room(room_id: int):
    room = await get_room_dict(room_id)
    if not room:
        raise HTTPException(404, "Room not found")
    room["spectators"] = []
    return room


@app.post("/api/rooms")
async def create_room(data: RoomCreate):
    tipo = data.type if data.type in ("publica", "privada") else "publica"
    if not data.name or not data.name.strip():
        raise HTTPException(400, "El nombre de la partida es requerido")
    code = generate_code()
    rows = await call_proc("sp_crear_partida", (data.name.strip(), tipo, code, data.max_players or 6))
    if not rows:
        raise HTTPException(500, "No se pudo crear la partida")
    id_partida = rows[0]["id_partida"]
    return {"id": id_partida, "code": code, "name": data.name.strip(), "type": tipo}


@app.post("/api/rooms/join-by-code")
async def join_room_by_code(data: JoinByCode):
    code = (data.code or "").strip().upper()
    if not code:
        raise HTTPException(400, "code es requerido")
    rows = await query("SELECT id_partida FROM Partida WHERE codigo_acceso = %s", (code,))
    if not rows:
        raise HTTPException(404, "Código no encontrado")
    room = await get_room_dict(rows[0]["id_partida"])
    return room


@app.delete("/api/rooms/{room_id}")
async def delete_room(room_id: int):
    # Los DELETE en cascada de FKs (Territorios_Partida, Cartas_Partida, etc)
    # no están definidos con ON DELETE CASCADE en el schema, así que hay que
    # borrar manualmente en el orden correcto (hijos antes que padres).
    for table, col in [
        ("Chat", "id_partida"), ("Intercambios", "id_partida"),
        ("Objetivos_Partida", "id_partida"), ("Estadisticas", "id_partida"),
        ("Turnos", "id_partida"), ("Cartas_Partida", "id_partida"),
        ("Territorios_Partida", "id_partida"), ("Usuarios", "id_partida"),
    ]:
        await execute(f"DELETE FROM {table} WHERE {col} = %s", (room_id,))
    await execute("DELETE FROM Partida WHERE id_partida = %s", (room_id,))
    return {"ok": True}


# =============================================================================
# WebSocket Connection Manager (per-room broadcast)
# =============================================================================
class ConnectionManager:
    def __init__(self):
        self.rooms: Dict[int, List[Dict[str, Any]]] = {}

    def add(self, room_id: int, websocket: WebSocket, player_id: int, name: str):
        self.rooms.setdefault(room_id, []).append(
            {"ws": websocket, "player_id": player_id, "name": name}
        )

    def remove(self, room_id: int, websocket: WebSocket):
        conns = self.rooms.get(room_id, [])
        self.rooms[room_id] = [c for c in conns if c["ws"] is not websocket]
        if not self.rooms[room_id]:
            del self.rooms[room_id]

    async def broadcast(self, room_id: int, message: dict):
        conns = self.rooms.get(room_id, [])
        dead = []
        for c in conns:
            try:
                await c["ws"].send_text(json.dumps(message, default=str))
            except Exception:
                dead.append(c["ws"])
        for ws in dead:
            self.remove(room_id, ws)

manager = ConnectionManager()

# Estado transitorio que NO vive en la DB: cuántos ejércitos le quedan por
# colocar a cada jugador en su fase de refuerzo actual. El schema dado no
# tiene una columna para esto (sp_calcular_refuerzos coloca todo junto en
# un solo país); acá el jugador elige país por país, así que hace falta
# un contador de vida corta (se resetea cada vez que arranca su refuerzo).
PENDING_REINFORCEMENTS: Dict[int, Dict[int, int]] = {}  # room_id -> {id_usuario: cantidad}


async def broadcast_room_waiting_state(room_id: int):
    """Sala de espera (antes de iniciar): un state_update por cliente
    conectado, con code/name/status/players — sin datos de partida."""
    room = await get_room_dict(room_id)
    if not room:
        return
    for c in list(manager.rooms.get(room_id, [])):
        payload = {
            "event": "state_update",
            "data": {
                "id": room["id"], "code": room["code"], "name": room["name"],
                "status": room["status"], "host_id": room["host_id"],
                "max_players": room["max_players"], "players": room["players"],
                "countries": [], "continents": [], "map_svg": None, "spectators": [],
                "my_state": {
                    "player_id": c["player_id"], "player_name": c["name"],
                    "is_host": c["player_id"] == room["host_id"],
                },
            }
        }
        try:
            await c["ws"].send_text(json.dumps(payload, default=str))
        except Exception:
            log.exception(f"Failed sending waiting state to player {c['player_id']} in room {room_id}")


async def get_current_turn(id_partida: int) -> Optional[dict]:
    rows = await query(
        "SELECT * FROM Turnos WHERE id_partida=%s AND fecha_fin IS NULL ORDER BY id_turno DESC LIMIT 1",
        (id_partida,)
    )
    return rows[0] if rows else None


async def get_countries_payload(id_partida: int) -> List[dict]:
    rows = await query("""
        SELECT pa.id_pais, pa.nombre, c.nombre AS continente,
               tp.id_usuario, tp.cantidad_ejercitos
        FROM Paises pa
        JOIN Continentes c ON c.id_continente = pa.id_continente
        LEFT JOIN Territorios_Partida tp ON tp.id_pais = pa.id_pais AND tp.id_partida = %s
        ORDER BY pa.id_pais
    """, (id_partida,))
    return [
        {
            "id": r["id_pais"], "name": r["nombre"], "continent": r["continente"],
            "owner_id": r["id_usuario"], "armies": r["cantidad_ejercitos"] or 0,
        }
        for r in rows
    ]


async def get_players_ingame_payload(id_partida: int) -> List[dict]:
    rows = await query("""
        SELECT u.id_usuario, u.nombre, u.color, u.orden_turno, u.estado,
               COUNT(tp.id_territorio) AS paises,
               COALESCE(SUM(tp.cantidad_ejercitos), 0) AS ejercitos,
               (SELECT COUNT(*) FROM Cartas_Partida cp WHERE cp.id_partida=u.id_partida
                    AND cp.id_usuario=u.id_usuario AND cp.estado='mano') AS cartas
        FROM Usuarios u
        LEFT JOIN Territorios_Partida tp ON tp.id_usuario=u.id_usuario AND tp.id_partida=u.id_partida
        WHERE u.id_partida=%s
        GROUP BY u.id_usuario
        ORDER BY u.orden_turno
    """, (id_partida,))
    host_id = await get_host_id(id_partida)
    return [
        {
            "id": r["id_usuario"], "name": r["nombre"], "color": r["color"] or "#FFFFFF",
            "is_host": r["id_usuario"] == host_id,
            "eliminated": r["estado"] != "activo",
            "countries_count": r["paises"], "total_armies": int(r["ejercitos"]),
            "cards_count": r["cartas"],
        }
        for r in rows
    ]


async def get_my_state(id_partida: int, id_usuario: int) -> dict:
    countries = await query(
        "SELECT id_pais FROM Territorios_Partida WHERE id_partida=%s AND id_usuario=%s",
        (id_partida, id_usuario)
    )
    armies_row = await query(
        "SELECT COALESCE(SUM(cantidad_ejercitos),0) AS total FROM Territorios_Partida WHERE id_partida=%s AND id_usuario=%s",
        (id_partida, id_usuario)
    )
    cards = await query("""
        SELECT cp.id_carta_partida, ca.tipo_figura
        FROM Cartas_Partida cp JOIN Cartas ca ON ca.id_carta = cp.id_carta
        WHERE cp.id_partida=%s AND cp.id_usuario=%s AND cp.estado='mano'
    """, (id_partida, id_usuario))
    obj_rows = await query("""
        SELECT o.descripcion, o.tipo, op.cumplido
        FROM Objetivos_Partida op JOIN Objetivos o ON o.id_objetivo = op.id_objetivo
        WHERE op.id_partida=%s AND op.id_usuario=%s
    """, (id_partida, id_usuario))
    trade_rows = await query("SELECT COUNT(*) AS c FROM Intercambios WHERE id_partida=%s", (id_partida,))
    next_trade_value = 5 + (trade_rows[0]["c"] * 2) if trade_rows else 5
    host_id = await get_host_id(id_partida)

    return {
        "player_id": id_usuario,
        "countries": [c["id_pais"] for c in countries],
        "total_armies": int(armies_row[0]["total"]) if armies_row else 0,
        "pending_reinforcements": PENDING_REINFORCEMENTS.get(id_partida, {}).get(id_usuario, 0),
        "cards": [
            {"id": c["id_carta_partida"], "type": TIPO_FIGURA_TO_CARD_TYPE.get(c["tipo_figura"], c["tipo_figura"])}
            for c in cards
        ],
        "objective": ({"description": obj_rows[0]["descripcion"]} if obj_rows and not obj_rows[0]["cumplido"] else None),
        "is_host": id_usuario == host_id,
        "next_trade_value": next_trade_value,
    }


async def send_game_state(room_id: int, event: str = "state_update", extra: dict = None):
    """Manda a cada cliente conectado su propio snapshot de la partida en
    curso (my_state difiere por jugador). Además dispara turn_change si
    cambió la fase o el jugador de turno."""
    room = await get_room_dict(room_id)
    if not room:
        return

    turno = await get_current_turn(room_id)
    phase = FASE_TO_PHASE.get(turno["fase"], "reinforce") if turno else "reinforce"
    current_player_id = turno["id_usuario"] if turno else None

    countries = await get_countries_payload(room_id)
    players_payload = await get_players_ingame_payload(room_id)

    for c in list(manager.rooms.get(room_id, [])):
        my_state = await get_my_state(room_id, c["player_id"])
        payload = {
            "event": event,
            "data": {
                "id": room["id"], "code": room["code"], "name": room["name"],
                "status": room["status"],
                "game_id": room["id"],
                "phase": phase,
                "turn_number": turno["numero_turno"] if turno else 0,
                "current_player_id": current_player_id,
                "countries": countries,
                "continents": continents_payload(),
                "borders": borders_as_pairs(),
                "players": players_payload,
                "spectators": [],
                "my_state": my_state,
            },
        }
        if extra:
            payload["data"].update(extra)
        try:
            await c["ws"].send_text(json.dumps(payload, default=str))
        except Exception:
            log.exception(f"Failed sending game state to player {c['player_id']} in room {room_id}")

    marker = (phase, current_player_id)
    if _last_turn_marker.get(room_id) != marker:
        _last_turn_marker[room_id] = marker
        await manager.broadcast(room_id, {
            "event": "turn_change",
            "data": {"current_player_id": current_player_id, "phase": phase, "time_remaining": 0},
        })

_last_turn_marker: Dict[int, tuple] = {}


async def start_reinforce_phase(id_partida: int, id_usuario: int):
    """Calcula (en Python, con teg_data para el bonus real de continentes
    consistente con el mapa/adyacencias) cuántos ejércitos le tocan al
    jugador y los deja pendientes de colocar. No usamos
    sp_calcular_refuerzos directamente porque ese procedure coloca todo
    de una en el primer país en vez de dejar elegir — acá se necesita que
    el jugador elija dónde colocarlos, país por país."""
    rows = await query(
        "SELECT id_pais, id_usuario FROM Territorios_Partida WHERE id_partida=%s",
        (id_partida,)
    )
    owner_by_country = {r["id_pais"]: r["id_usuario"] for r in rows}
    cantidad = calculate_reinforcements(owner_by_country, id_usuario)
    PENDING_REINFORCEMENTS.setdefault(id_partida, {})[id_usuario] = cantidad


async def eliminate_and_maybe_finish(room_id: int, id_usuario: int, display_name: str):
    """El trigger trg_territorios_partida_after_update ya marca 'eliminado'
    automáticamente cuando un jugador se queda sin territorios (se dispara
    solo con el UPDATE de Territorios_Partida). Acá solo nos encargamos de:
    avisar por chat/evento, y si queda 1 solo jugador activo, cerrar la
    partida con sp_finalizar_partida."""
    await manager.broadcast(room_id, {
        "event": "player_eliminated",
        "data": {"player_id": id_usuario, "player_name": display_name},
    })
    activos = await query(
        "SELECT id_usuario, nombre FROM Usuarios WHERE id_partida=%s AND estado='activo'",
        (room_id,)
    )
    if len(activos) <= 1:
        winner = activos[0] if activos else None
        if winner:
            await call_proc("sp_finalizar_partida", (room_id, winner["id_usuario"]))
        else:
            await execute("UPDATE Partida SET estado='finalizada' WHERE id_partida=%s", (room_id,))
        players_payload = await get_players_ingame_payload(room_id)
        await manager.broadcast(room_id, {
            "event": "game_over",
            "data": {
                "winner_id": winner["id_usuario"] if winner else None,
                "winner_name": winner["nombre"] if winner else None,
                "players": players_payload,
            }
        })
        PENDING_REINFORCEMENTS.pop(room_id, None)
        _last_turn_marker.pop(room_id, None)
        return True
    return False


# =============================================================================
# WebSocket
# =============================================================================
@app.websocket("/ws/{room_id}")
async def ws_endpoint(websocket: WebSocket, room_id: int, name: str = "player", spectate: bool = False):
    log.info(f"WS connect: room={room_id} name={name}")
    await websocket.accept()

    player_id_for_conn = None
    try:
        rooms = await query("SELECT * FROM Partida WHERE id_partida=%s", (room_id,))
        if not rooms:
            await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Room not found"}}))
            await websocket.close()
            return
        partida = rooms[0]

        # Buscar o crear el Usuario. Si ya existe (misma sala + mismo
        # nombre) y sigue activo, lo reutilizamos (soporta refrescar la
        # página en la sala de espera, o reconectar antes de que el
        # cleanup de desconexión lo haya marcado eliminado).
        existing = await query(
            "SELECT * FROM Usuarios WHERE id_partida=%s AND nombre=%s AND estado='activo'",
            (room_id, name)
        )
        if existing:
            usuario = existing[0]
        else:
            try:
                rows = await call_proc("sp_unirse_partida", (room_id, name, partida["codigo_acceso"]))
            except Exception as e:
                msg = str(e)
                # Los triggers/procedures usan SIGNAL SQLSTATE '45000' con un
                # MESSAGE_TEXT legible — se lo pasamos tal cual al cliente.
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": msg}}))
                await websocket.close()
                return
            if not rows:
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": "No se pudo unir a la partida"}}))
                await websocket.close()
                return
            id_usuario = rows[0]["id_usuario"]
            orden_rows = await query("SELECT orden_turno FROM Usuarios WHERE id_usuario=%s", (id_usuario,))
            orden = orden_rows[0]["orden_turno"] if orden_rows else 1
            color = PLAYER_COLORS[(orden - 1) % len(PLAYER_COLORS)]
            await execute("UPDATE Usuarios SET color=%s WHERE id_usuario=%s", (color, id_usuario))
            urows = await query("SELECT * FROM Usuarios WHERE id_usuario=%s", (id_usuario,))
            usuario = urows[0]

        player_id_for_conn = usuario["id_usuario"]
        manager.add(room_id, websocket, player_id_for_conn, name)

        if partida["estado"] == "en_curso":
            map_svg = ""
            try:
                map_path = FRONTEND_DIR / "assets" / "map" / "teg-map.svg"
                if map_path.exists():
                    map_svg = map_path.read_text(encoding="utf-8")
            except Exception as e:
                log.warning(f"Could not load map SVG: {e}")
            await send_game_state(room_id, event="game_started", extra={"map_svg": map_svg})
        else:
            await broadcast_room_waiting_state(room_id)

        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Invalid JSON"}}))
                continue
            if not isinstance(msg, dict):
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Expected a JSON object"}}))
                continue

            evt = msg.get("event") or msg.get("type") or ""
            data = msg.get("data") or msg.get("payload") or {}

            if evt == "ping":
                await websocket.send_text(json.dumps({"event": "pong", "data": {}}))

            elif evt == "join_room":
                rooms_now = await query("SELECT estado FROM Partida WHERE id_partida=%s", (room_id,))
                if rooms_now and rooms_now[0]["estado"] == "en_curso":
                    await send_game_state(room_id)
                else:
                    await broadcast_room_waiting_state(room_id)

            elif evt == "start_game":
                rows_now = await query("SELECT estado FROM Partida WHERE id_partida=%s", (room_id,))
                if not rows_now or rows_now[0]["estado"] != "esperando":
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "La partida ya empezó"}}))
                    continue
                activos = await query(
                    "SELECT id_usuario, orden_turno FROM Usuarios WHERE id_partida=%s AND estado='activo' ORDER BY orden_turno",
                    (room_id,)
                )
                if len(activos) < 2:
                    await websocket.send_text(json.dumps({
                        "event": "error", "data": {"message": "Se necesitan al menos 2 jugadores para iniciar"}
                    }))
                    continue

                await call_proc("sp_iniciar_partida", (room_id,))
                await start_reinforce_phase(room_id, activos[0]["id_usuario"])

                map_svg = ""
                try:
                    map_path = FRONTEND_DIR / "assets" / "map" / "teg-map.svg"
                    if map_path.exists():
                        map_svg = map_path.read_text(encoding="utf-8")
                except Exception as e:
                    log.warning(f"Could not load map SVG: {e}")
                await send_game_state(room_id, event="game_started", extra={"map_svg": map_svg})
                await call_proc("sp_enviar_mensaje", (room_id, "general", activos[0]["id_usuario"], None, "¡La partida ha comenzado!"))
                await manager.broadcast(room_id, {
                    "event": "chat_message",
                    "data": {
                        "channel": "general", "sender_id": None, "sender_name": "Sistema",
                        "message": "¡La partida ha comenzado!", "timestamp": datetime.now().isoformat(),
                    }
                })

            elif evt == "place_armies":
                turno = await get_current_turn(room_id)
                if not turno or turno["fase"] != "refuerzo" or turno["id_usuario"] != player_id_for_conn:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "No es tu turno de refuerzo"}}))
                    continue
                try:
                    country_id = int(data.get("country_id"))
                    amount = int(data.get("amount", 1))
                except (TypeError, ValueError):
                    continue
                owner_rows = await query(
                    "SELECT id_usuario FROM Territorios_Partida WHERE id_partida=%s AND id_pais=%s",
                    (room_id, country_id)
                )
                if not owner_rows or owner_rows[0]["id_usuario"] != player_id_for_conn:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Ese país no es tuyo"}}))
                    continue
                available = PENDING_REINFORCEMENTS.get(room_id, {}).get(player_id_for_conn, 0)
                if amount < 1 or amount > available:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Cantidad de ejércitos inválida"}}))
                    continue
                await execute(
                    "UPDATE Territorios_Partida SET cantidad_ejercitos = cantidad_ejercitos + %s WHERE id_partida=%s AND id_pais=%s",
                    (amount, room_id, country_id)
                )
                PENDING_REINFORCEMENTS[room_id][player_id_for_conn] -= amount
                await send_game_state(room_id)

            elif evt == "end_reinforce":
                turno = await get_current_turn(room_id)
                if not turno or turno["fase"] != "refuerzo" or turno["id_usuario"] != player_id_for_conn:
                    continue
                if PENDING_REINFORCEMENTS.get(room_id, {}).get(player_id_for_conn, 0) > 0:
                    await websocket.send_text(json.dumps({
                        "event": "error", "data": {"message": "Todavía tenés ejércitos por colocar"}
                    }))
                    continue
                await execute(
                    "UPDATE Turnos SET fase='ataque' WHERE id_turno=%s",
                    (turno["id_turno"],)
                )
                await send_game_state(room_id)

            elif evt == "attack":
                turno = await get_current_turn(room_id)
                if not turno or turno["fase"] != "ataque" or turno["id_usuario"] != player_id_for_conn:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "No podés atacar ahora"}}))
                    continue
                try:
                    from_id = int(data.get("from_country_id"))
                    to_id = int(data.get("to_country_id"))
                except (TypeError, ValueError):
                    continue

                origen_rows = await query(
                    "SELECT id_usuario, cantidad_ejercitos FROM Territorios_Partida WHERE id_partida=%s AND id_pais=%s",
                    (room_id, from_id)
                )
                destino_rows = await query(
                    "SELECT id_usuario, cantidad_ejercitos FROM Territorios_Partida WHERE id_partida=%s AND id_pais=%s",
                    (room_id, to_id)
                )
                if not origen_rows or origen_rows[0]["id_usuario"] != player_id_for_conn:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "País de origen inválido"}}))
                    continue
                if not destino_rows or destino_rows[0]["id_usuario"] == player_id_for_conn:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "País de destino inválido"}}))
                    continue
                if to_id not in ADJACENCY.get(from_id, []):
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Los países no son limítrofes"}}))
                    continue

                ejercitos_origen = origen_rows[0]["cantidad_ejercitos"]
                ejercitos_destino = destino_rows[0]["cantidad_ejercitos"]
                defender_id = destino_rows[0]["id_usuario"]
                if ejercitos_origen < 2:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Necesitás al menos 2 ejércitos para atacar"}}))
                    continue

                # El combate se resuelve acá en Python (dado a dado, regla
                # real de TEG/Risk) en vez de con sp_realizar_ataque: ese
                # procedure tiene una comparación simplificada que el propio
                # comentario del enunciado dice que hay que reemplazar "en
                # la capa de aplicación". Las UPDATE que siguen son las
                # mismas que haría el procedure, así que el trigger
                # trg_territorios_partida_after_update (elim./objetivo) se
                # sigue disparando igual.
                attacker_dice_n = max(1, min(int(data.get("attacker_dice", 1)), 3, ejercitos_origen - 1))
                defender_dice_n = max(1, min(int(data.get("defender_dice", 1)), 2, ejercitos_destino))
                a_rolls = sorted((random.randint(1, 6) for _ in range(attacker_dice_n)), reverse=True)
                d_rolls = sorted((random.randint(1, 6) for _ in range(defender_dice_n)), reverse=True)

                attacker_losses = 0
                defender_losses = 0
                for a, d in zip(a_rolls, d_rolls):
                    if a > d:
                        defender_losses += 1
                    else:
                        attacker_losses += 1

                nuevo_origen = ejercitos_origen - attacker_losses
                nuevo_destino = max(ejercitos_destino - defender_losses, 0)
                await execute(
                    "UPDATE Territorios_Partida SET cantidad_ejercitos=%s WHERE id_partida=%s AND id_pais=%s",
                    (nuevo_origen, room_id, from_id)
                )

                conquered = False
                if nuevo_destino == 0:
                    conquered = True
                    move_in = min(attacker_dice_n, nuevo_origen - 1) if nuevo_origen > 1 else 0
                    move_in = max(move_in, 1) if nuevo_origen > 1 else 0
                    await execute(
                        "UPDATE Territorios_Partida SET id_usuario=%s, cantidad_ejercitos=%s WHERE id_partida=%s AND id_pais=%s",
                        (player_id_for_conn, move_in, room_id, to_id)
                    )
                    if move_in > 0:
                        await execute(
                            "UPDATE Territorios_Partida SET cantidad_ejercitos = cantidad_ejercitos - %s WHERE id_partida=%s AND id_pais=%s",
                            (move_in, room_id, from_id)
                        )
                    await execute(
                        "UPDATE Estadisticas SET paises_conquistados = paises_conquistados + 1 WHERE id_partida=%s AND id_usuario=%s",
                        (room_id, player_id_for_conn)
                    )
                    # Robo de carta: una por turno con al menos una conquista
                    turno_key = (room_id, player_id_for_conn, turno["id_turno"])
                    if not _conquered_this_turn.get(turno_key):
                        _conquered_this_turn[turno_key] = True
                        carta_rows = await query(
                            "SELECT id_carta_partida FROM Cartas_Partida WHERE id_partida=%s AND estado='mazo' ORDER BY RAND() LIMIT 1",
                            (room_id,)
                        )
                        if carta_rows:
                            id_carta_partida = carta_rows[0]["id_carta_partida"]
                            await execute(
                                "UPDATE Cartas_Partida SET estado='mano', id_usuario=%s WHERE id_carta_partida=%s",
                                (player_id_for_conn, id_carta_partida)
                            )
                            tipo_rows = await query(
                                "SELECT ca.tipo_figura FROM Cartas_Partida cp JOIN Cartas ca ON ca.id_carta=cp.id_carta WHERE cp.id_carta_partida=%s",
                                (id_carta_partida,)
                            )
                            tipo_figura = tipo_rows[0]["tipo_figura"] if tipo_rows else "soldado"
                            card_conn = next((c for c in manager.rooms.get(room_id, []) if c["player_id"] == player_id_for_conn), None)
                            if card_conn:
                                try:
                                    await card_conn["ws"].send_text(json.dumps({
                                        "event": "card_drawn",
                                        "data": {"card": {"id": id_carta_partida, "type": TIPO_FIGURA_TO_CARD_TYPE.get(tipo_figura, tipo_figura)}}
                                    }, default=str))
                                except Exception:
                                    pass

                attacker_name_rows = await query("SELECT nombre FROM Usuarios WHERE id_usuario=%s", (player_id_for_conn,))
                defender_name_rows = await query("SELECT nombre FROM Usuarios WHERE id_usuario=%s", (defender_id,)) if defender_id else []
                pais_origen_rows = await query("SELECT nombre FROM Paises WHERE id_pais=%s", (from_id,))
                pais_destino_rows = await query("SELECT nombre FROM Paises WHERE id_pais=%s", (to_id,))

                final_origen = await query("SELECT cantidad_ejercitos FROM Territorios_Partida WHERE id_partida=%s AND id_pais=%s", (room_id, from_id))
                final_destino = await query("SELECT id_usuario, cantidad_ejercitos FROM Territorios_Partida WHERE id_partida=%s AND id_pais=%s", (room_id, to_id))

                await manager.broadcast(room_id, {
                    "event": "combat_result",
                    "data": {
                        "from_country_id": from_id, "to_country_id": to_id,
                        "attacker_id": player_id_for_conn, "defender_id": defender_id,
                        "attacker_name": attacker_name_rows[0]["nombre"] if attacker_name_rows else name,
                        "defender_name": defender_name_rows[0]["nombre"] if defender_name_rows else "Neutral",
                        "attacker_dice": a_rolls, "defender_dice": d_rolls,
                        "attacker_losses": attacker_losses, "defender_losses": defender_losses,
                        "conquered": conquered,
                        "attacker_country": {"id": from_id, "name": pais_origen_rows[0]["nombre"], "armies": final_origen[0]["cantidad_ejercitos"]},
                        "defender_country": {"id": to_id, "name": pais_destino_rows[0]["nombre"], "armies": final_destino[0]["cantidad_ejercitos"]},
                        "countries": [
                            {"id": from_id, "name": pais_origen_rows[0]["nombre"], "owner_id": player_id_for_conn, "armies": final_origen[0]["cantidad_ejercitos"]},
                            {"id": to_id, "name": pais_destino_rows[0]["nombre"], "owner_id": final_destino[0]["id_usuario"], "armies": final_destino[0]["cantidad_ejercitos"]},
                        ],
                    }
                })

                if defender_id:
                    check_rows = await query("SELECT estado FROM Usuarios WHERE id_usuario=%s", (defender_id,))
                    if check_rows and check_rows[0]["estado"] != "activo":
                        finished = await eliminate_and_maybe_finish(room_id, defender_id, defender_name_rows[0]["nombre"] if defender_name_rows else "?")
                        if finished:
                            continue

                await send_game_state(room_id)

            elif evt == "end_attack":
                turno = await get_current_turn(room_id)
                if not turno or turno["fase"] != "ataque" or turno["id_usuario"] != player_id_for_conn:
                    continue
                await execute("UPDATE Turnos SET fase='fortificacion' WHERE id_turno=%s", (turno["id_turno"],))
                await send_game_state(room_id)

            elif evt == "fortify":
                turno = await get_current_turn(room_id)
                if not turno or turno["fase"] != "fortificacion" or turno["id_usuario"] != player_id_for_conn:
                    continue
                try:
                    from_id = int(data.get("from_country_id"))
                    to_id = int(data.get("to_country_id"))
                    amount = int(data.get("amount", 0))
                except (TypeError, ValueError):
                    continue

                # sp_fortificar no valida adyacencia ni que el destino sea
                # del mismo jugador (podría "perder" ejércitos si el
                # destino es de otro dueño) — se valida acá antes de tocar
                # las tablas, en vez de llamar al procedure tal cual.
                origen_rows = await query(
                    "SELECT id_usuario, cantidad_ejercitos FROM Territorios_Partida WHERE id_partida=%s AND id_pais=%s",
                    (room_id, from_id)
                )
                destino_rows = await query(
                    "SELECT id_usuario FROM Territorios_Partida WHERE id_partida=%s AND id_pais=%s",
                    (room_id, to_id)
                )
                if (not origen_rows or origen_rows[0]["id_usuario"] != player_id_for_conn or
                        not destino_rows or destino_rows[0]["id_usuario"] != player_id_for_conn):
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Ambos países deben ser tuyos"}}))
                    continue
                if to_id not in ADJACENCY.get(from_id, []):
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Los países no son limítrofes"}}))
                    continue
                if amount < 1 or amount > origen_rows[0]["cantidad_ejercitos"] - 1:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Cantidad de ejércitos inválida"}}))
                    continue

                await execute(
                    "UPDATE Territorios_Partida SET cantidad_ejercitos = cantidad_ejercitos - %s WHERE id_partida=%s AND id_pais=%s",
                    (amount, room_id, from_id)
                )
                await execute(
                    "UPDATE Territorios_Partida SET cantidad_ejercitos = cantidad_ejercitos + %s WHERE id_partida=%s AND id_pais=%s",
                    (amount, room_id, to_id)
                )
                await call_proc("sp_finalizar_turno", (room_id,))
                nuevo_turno = await get_current_turn(room_id)
                if nuevo_turno:
                    await start_reinforce_phase(room_id, nuevo_turno["id_usuario"])
                await send_game_state(room_id)

            elif evt == "end_fortify":
                turno = await get_current_turn(room_id)
                if not turno or turno["fase"] != "fortificacion" or turno["id_usuario"] != player_id_for_conn:
                    continue
                await call_proc("sp_finalizar_turno", (room_id,))
                nuevo_turno = await get_current_turn(room_id)
                if nuevo_turno:
                    await start_reinforce_phase(room_id, nuevo_turno["id_usuario"])
                await send_game_state(room_id)

            elif evt == "trade_cards":
                try:
                    card_ids = [int(i) for i in data.get("card_ids", [])]
                except (TypeError, ValueError):
                    continue
                if len(card_ids) != 3:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Necesitás elegir 3 cartas"}}))
                    continue
                mias_rows = await query("""
                    SELECT cp.id_carta_partida, ca.tipo_figura
                    FROM Cartas_Partida cp JOIN Cartas ca ON ca.id_carta=cp.id_carta
                    WHERE cp.id_carta_partida IN (%s,%s,%s) AND cp.id_partida=%s AND cp.id_usuario=%s AND cp.estado='mano'
                """, (*card_ids, room_id, player_id_for_conn))
                if len(mias_rows) != 3:
                    await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Esas cartas no son tuyas o ya no están en tu mano"}}))
                    continue
                tipos = [r["tipo_figura"] for r in mias_rows]
                tiene_comodin = "comodin" in tipos
                if not tiene_comodin and len(set(tipos)) not in (1, 3):
                    await websocket.send_text(json.dumps({
                        "event": "error", "data": {"message": "Las 3 cartas deben ser del mismo tipo, todas distintas, o incluir un comodín"}
                    }))
                    continue

                try:
                    out = await call_proc_out(
                        "sp_intercambiar_cartas",
                        (room_id, player_id_for_conn, card_ids[0], card_ids[1], card_ids[2]),
                        0,
                    )
                except Exception:
                    pass
                # sp_intercambiar_cartas no tiene OUT param — el valor
                # calculado se puede leer del último registro insertado.
                bonus_rows = await query(
                    "SELECT ejercitos_obtenidos FROM Intercambios WHERE id_partida=%s AND id_usuario=%s ORDER BY id_intercambio DESC LIMIT 1",
                    (room_id, player_id_for_conn)
                )
                bonus = bonus_rows[0]["ejercitos_obtenidos"] if bonus_rows else 5
                PENDING_REINFORCEMENTS.setdefault(room_id, {})[player_id_for_conn] = \
                    PENDING_REINFORCEMENTS.get(room_id, {}).get(player_id_for_conn, 0) + bonus

                conn = next((c for c in manager.rooms.get(room_id, []) if c["player_id"] == player_id_for_conn), None)
                if conn:
                    try:
                        await conn["ws"].send_text(json.dumps({
                            "event": "cards_traded",
                            "data": {"traded_card_ids": card_ids, "armies_received": bonus}
                        }, default=str))
                    except Exception:
                        pass
                await send_game_state(room_id)

            elif evt == "surrender" or evt == "leave_game":
                if player_id_for_conn is not None:
                    await execute("UPDATE Territorios_Partida SET id_usuario=NULL WHERE id_partida=%s AND id_usuario=%s", (room_id, player_id_for_conn))
                    await call_proc("sp_eliminar_jugador", (room_id, player_id_for_conn))
                    finished = await eliminate_and_maybe_finish(room_id, player_id_for_conn, name)
                    if not finished:
                        turno = await get_current_turn(room_id)
                        if turno and turno["id_usuario"] == player_id_for_conn:
                            await call_proc("sp_finalizar_turno", (room_id,))
                            nuevo_turno = await get_current_turn(room_id)
                            if nuevo_turno:
                                await start_reinforce_phase(room_id, nuevo_turno["id_usuario"])
                        await send_game_state(room_id)

            elif evt == "send_chat":
                channel = data.get("channel", "general")
                message_text = (data.get("message") or "").strip()[:500]
                if not message_text:
                    continue
                timestamp = datetime.now().isoformat()

                if channel == "private":
                    recipient_id = data.get("recipient_id")
                    if recipient_id is None:
                        await websocket.send_text(json.dumps({"event": "error", "data": {"message": "recipient_id required"}}))
                        continue
                    recipient_id = int(recipient_id)
                    recipient_conn = next((c for c in manager.rooms.get(room_id, []) if c["player_id"] == recipient_id), None)
                    try:
                        await call_proc("sp_enviar_mensaje", (room_id, "privado", player_id_for_conn, recipient_id, message_text))
                    except Exception as e:
                        await websocket.send_text(json.dumps({"event": "error", "data": {"message": str(e)}}))
                        continue
                    payload = {
                        "event": "chat_message",
                        "data": {
                            "channel": "private", "sender_id": player_id_for_conn, "sender_name": name,
                            "recipient_id": recipient_id,
                            "recipient_name": recipient_conn["name"] if recipient_conn else None,
                            "message": message_text, "timestamp": timestamp,
                        }
                    }
                    if recipient_conn:
                        try:
                            await recipient_conn["ws"].send_text(json.dumps(payload, default=str))
                        except Exception:
                            pass
                    if recipient_id != player_id_for_conn:
                        await websocket.send_text(json.dumps(payload, default=str))
                else:
                    await call_proc("sp_enviar_mensaje", (room_id, "general", player_id_for_conn, None, message_text))
                    await manager.broadcast(room_id, {
                        "event": "chat_message",
                        "data": {
                            "channel": "general", "sender_id": player_id_for_conn, "sender_name": name,
                            "message": message_text, "timestamp": timestamp,
                        }
                    })

            else:
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": f"Unknown event: {evt}"}}))

    except WebSocketDisconnect:
        log.info(f"WS disconnect: room={room_id}")
    except Exception as e:
        log.exception(f"WS error: {e}")
    finally:
        manager.remove(room_id, websocket)
        if player_id_for_conn is not None:
            try:
                rows_now = await query("SELECT estado FROM Partida WHERE id_partida=%s", (room_id,))
                en_curso = rows_now and rows_now[0]["estado"] == "en_curso"
                estado_rows = await query("SELECT estado FROM Usuarios WHERE id_usuario=%s", (player_id_for_conn,))
                ya_eliminado = estado_rows and estado_rows[0]["estado"] != "activo"

                if en_curso and not ya_eliminado:
                    # Partida en curso: tratamos la desconexión igual que un
                    # abandono, para que el juego nunca quede trabado
                    # esperando el turno de alguien que ya no está.
                    await execute("UPDATE Territorios_Partida SET id_usuario=NULL WHERE id_partida=%s AND id_usuario=%s", (room_id, player_id_for_conn))
                    await call_proc("sp_eliminar_jugador", (room_id, player_id_for_conn))
                    finished = await eliminate_and_maybe_finish(room_id, player_id_for_conn, name)
                    if not finished:
                        turno = await get_current_turn(room_id)
                        if turno and turno["id_usuario"] == player_id_for_conn:
                            await call_proc("sp_finalizar_turno", (room_id,))
                            nuevo_turno = await get_current_turn(room_id)
                            if nuevo_turno:
                                await start_reinforce_phase(room_id, nuevo_turno["id_usuario"])
                        await send_game_state(room_id)
                elif not en_curso:
                    # Sala de espera: se borra directamente (no hay nada que
                    # "abandonar" todavía). El host se recalcula solo (ver
                    # get_host_id) apenas este Usuario deja de estar activo.
                    await execute("DELETE FROM Usuarios WHERE id_usuario=%s", (player_id_for_conn,))
                    await broadcast_room_waiting_state(room_id)
            except Exception:
                log.exception(f"Failed cleaning up player {player_id_for_conn} in room {room_id}")


_conquered_this_turn: Dict[tuple, bool] = {}

# =============================================================================
# Frontend catch-all
# =============================================================================
@app.get("/")
async def root():
    return FileResponse(str(FRONTEND_DIR / "index.html"))

from fastapi.responses import FileResponse

@app.get("/{path:path}")
async def serve_frontend(path: str):
    full = FRONTEND_DIR / path
    if full.exists() and full.is_file():
        return FileResponse(str(full))
    return FileResponse(str(FRONTEND_DIR / "index.html"))


# =============================================================================
# Main
# =============================================================================
if __name__ == "__main__":
    import uvicorn
    log.info("=" * 60)
    log.info("TEG UNIFIED SERVER (sin docker, sin nginx)")
    log.info(f"Frontend: {FRONTEND_DIR}")
    log.info(f"DB: {DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['db']}")
    log.info(f"URL: http://localhost:8765")
    log.info("=" * 60)
    uvicorn.run(app, host="0.0.0.0", port=8765, reload=False, log_level="info")
