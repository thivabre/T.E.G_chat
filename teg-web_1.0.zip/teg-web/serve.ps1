$port = 8080
$frontendDir = Join-Path $PSScriptRoot "frontend"
$backendUrl = "http://localhost:8765"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()

Write-Host "Proxy running at http://localhost:$port/"
Write-Host "  - Static files from $frontendDir"
Write-Host "  - /api/* proxied to $backendUrl"

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response
    
    $path = $request.Url.AbsolutePath
    
    if ($path -match "^/api/") {
        # Proxy to backend
        $backendTarget = "$backendUrl$path"
        try {
            $backendRequest = [System.Net.HttpWebRequest]::Create($backendTarget)
            $backendRequest.Method = $request.HttpMethod
            $backendRequest.ContentType = $request.ContentType
            $backendRequest.Headers.Add("Origin", "http://localhost:$port")
            
            if ($request.ContentLength64 -gt 0) {
                $body = New-Object byte[] $request.ContentLength64
                $request.InputStream.Read($body, 0, $request.ContentLength64)
                $backendRequest.GetRequestStream().Write($body, 0, $body.Length)
            }
            
            $backendResponse = $backendRequest.GetResponse()
            $response.StatusCode = $backendResponse.StatusCode
            $response.ContentType = $backendResponse.ContentType
            $response.Headers.Add("Access-Control-Allow-Origin", "*")
            
            $respBytes = [System.IO.Stream]::CopyTo($backendResponse.GetResponseStream(), $response.OutputStream)
        } catch {
            $response.StatusCode = 502
            $body = [System.Text.Encoding]::UTF8.GetBytes("Proxy error: $($_.Exception.Message)")
            $response.OutputStream.Write($body, 0, $body.Length)
        }
    } elseif ($path -eq "/sw.js") {
        # Disabled SW
        $response.StatusCode = 200
        $response.ContentType = "application/javascript"
        $body = [System.Text.Encoding]::UTF8.GetBytes('console.log("SW disabled");')
        $response.OutputStream.Write($body, 0, $body.Length)
    } else {
        # Serve static file
        $filePath = Join-Path $frontendDir $path.TrimStart("/")
        if (Test-Path $filePath) {
            $mimeTypes = @{
                ".html" = "text/html"
                ".js" = "application/javascript"
                ".css" = "text/css"
                ".svg" = "image/svg+xml"
                ".png" = "image/png"
                ".ico" = "image/x-icon"
            }
            $ext = [System.IO.Path]::GetExtension($filePath)
            $response.ContentType = $mimeTypes[$ext]
            $response.StatusCode = 200
            $body = [System.IO.File]::ReadAllBytes($filePath)
            $response.OutputStream.Write($body, 0, $body.Length)
        } else {
            $response.StatusCode = 404
        }
    }
    
    $response.Close()
}
