"""Serve frontend on 8080, proxy /api and /ws to backend 8000.

ADVERTENCIA: este proxy usa http.server (síncrono) y urllib — puede
reenviar pedidos REST /api normales, pero NO puede hacer proxy de un
WebSocket real (/ws), porque eso requiere upgrade de conexión y un
socket persistente en ambas puntas, algo que este modelo síncrono no
soporta. Si lo usás, el chat/las partidas en vivo NO van a andar.
Se deja en el repo tal cual estaba, arreglado solo en las rutas
hardcodeadas, para no prometer algo que no funciona. Para jugar de
verdad, corré unified_server.py (frontend + backend + WS en un solo
proceso, un solo puerto) — es el flujo soportado y recomendado.
"""
import http.server, socketserver, urllib.request, urllib.error, os, json
from pathlib import Path

PORT = int(os.environ.get("TEG_FRONTEND_PORT", "8080"))
FRONTEND_DIR = str(Path(__file__).resolve().parent / "frontend")
BACKEND_PROXY = os.environ.get("TEG_BACKEND_PROXY", "http://localhost:8765")

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=FRONTEND_DIR, **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        super().end_headers()

    def proxy_request(self, path):
        """Proxy a request to the backend."""
        url = BACKEND_PROXY + path
        headers = {}
        for k, v in self.headers.items():
            if k.lower() not in ('host', 'connection', 'accept-encoding'):
                headers[k] = v

        body = None
        if self.command in ('POST', 'PUT', 'PATCH'):
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                body = self.rfile.read(content_length)

        try:
            req = urllib.request.Request(url, data=body, headers=headers, method=self.command)
            with urllib.request.urlopen(req, timeout=10) as resp:
                self.send_response(resp.status)
                for k, v in resp.headers.items():
                    if k.lower() not in ('transfer-encoding', 'connection', 'keep-alive', 'content-length', 'access-control-allow-origin'):
                        self.send_header(k, v)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(resp.read())
        except urllib.error.HTTPError as e:
            self.send_response(e.code)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(e.read() or b'')
        except Exception as e:
            self.send_response(502)
            self.end_headers()
            self.wfile.write(f'Proxy error: {e}'.encode())

    def do_GET(self):
        if self.path.startswith('/api/') or self.path.startswith('/ws/'):
            self.proxy_request(self.path)
            return
        if self.path == '/sw.js':
            self.send_response(200)
            self.send_header('Content-Type', 'application/javascript')
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(b'console.log("SW disabled");')
            return
        super().do_GET()

    def do_POST(self):
        if self.path.startswith('/api/') or self.path.startswith('/ws/'):
            self.proxy_request(self.path)
            return
        self.send_error(404)

    def do_PUT(self):
        if self.path.startswith('/api/'):
            self.proxy_request(self.path)
            return
        self.send_error(404)

    def do_DELETE(self):
        if self.path.startswith('/api/'):
            self.proxy_request(self.path)
            return
        self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

if __name__ == '__main__':
    os.chdir(FRONTEND_DIR)
    with socketserver.TCPServer(("", PORT), Handler) as s:
        print(f"Frontend + Proxy running at http://localhost:{PORT}/")
        print(f"  - Static files from {FRONTEND_DIR}/")
        print(f"  - /api/* and /ws/* proxied to {BACKEND_PROXY}")
        s.serve_forever()
