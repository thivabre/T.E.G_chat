# TEG Web

Implementación web del TEG (parecido a Risk) con multijugador en tiempo real
vía WebSocket: reparto de países, fases de refuerzo/ataque/fortificación,
combate con dados, cartas y canje, objetivos, chat público y privado.

> **Nota sobre el repo**: existe una carpeta `backend/` con una app FastAPI
> más "completa" (SQLAlchemy, Alembic, Docker) que **no se usa** — quedó
> abandonada en algún momento del desarrollo. Lo que realmente corre es
> **`unified_server.py`**, en la raíz del proyecto: un solo proceso que
> sirve el frontend, la API REST y el WebSocket, todo en el puerto **8765**,
> hablando SQL crudo (con stored procedures) contra MySQL/MariaDB. Todo lo
> que sigue en este README es sobre `unified_server.py`.

## Arquitectura en una línea

```
Navegador  <-->  unified_server.py (FastAPI, puerto 8765)  <-->  MySQL/MariaDB
                  sirve frontend/ + REST /api + WS /ws
```

Como todo corre en **un solo proceso Python**, en la práctica **te alcanza
con un solo entorno virtual**. Más abajo, en la sección "¿Y el venv del
frontend?", explico por qué y qué hacer si igual querés separarlo en dos
procesos.

## 1. Base de datos

El schema real vive en `database/` (fue provisto como entregable académico:
tablas en español, triggers, y stored procedures). `database/init.sql` es
el script consolidado — crea la base `teg_web`, las 14 tablas, carga el
mapa (41 países / 6 continentes / fronteras reales del TEG clásico / 41
cartas / objetivo), los 8 triggers y los 12 stored procedures.

```bash
# Con MySQL o MariaDB corriendo:
mysql -u root -p < database/init.sql

# Crear el usuario de la app (o usá root directo si preferís, ajustando
# las variables de entorno más abajo):
mysql -u root -p -e "
  CREATE USER IF NOT EXISTS teg_user@'%' IDENTIFIED BY 'teg_password';
  GRANT ALL PRIVILEGES ON teg_web.* TO teg_user@'%';
  FLUSH PRIVILEGES;
"
```

**Importante — acentos/ñ**: `init.sql` ya incluye `SET NAMES utf8mb4;` al
principio, así que se puede correr tal cual con `mysql -u root -p < ...`
sin banderas extra y los nombres de países (África, Japón, Ucrania, etc.)
van a quedar bien guardados. Si en algún momento cargás algo a mano con el
cliente `mysql` y ves los acentos corrompidos (`Ã¡` en vez de `á`), el
cliente negoció `latin1` — corré `mysql --default-character-set=utf8mb4 ...`
o poné `SET NAMES utf8mb4;` primero en esa sesión.

Los scripts individuales (`01_schema.sql`, `02_seed.sql`, `03_triggers.sql`,
`04_procedures.sql`) están por separado en `database/` por si preferís
correrlos uno por uno o revisar cada parte; `init.sql` es la concatenación
de los cuatro con el `CREATE DATABASE`/`SET NAMES` al principio.
`database/consultas_referencia.sql` es el archivo original que subiste con
las consultas parametrizadas de referencia (no se ejecuta, es documentación).

### Bugs que se corrigieron en el SQL provisto

Al probar todo esto contra un MariaDB real encontré y arreglé:

- **`sp_iniciar_partida`** usaba `LIMIT 1 OFFSET (subconsulta dinámica)`
  para repartir países — eso no es válido en MySQL/MariaDB (el `OFFSET`
  tiene que ser una constante). Se reescribió con `ROW_NUMBER() OVER()`,
  mismo resultado (reparto rotativo), sintaxis válida. Probado con 2 y 3
  jugadores, reparte bien (14/14/13 con 3 jugadores y 41 países).
- **`sp_intercambiar_cartas`** calculaba `v_tipos` (cantidad de tipos
  distintos entre las 3 cartas) pero nunca lo validaba — cualquier trío se
  podía canjear. Se agregó el chequeo real (3 iguales, 3 distintas, o con
  comodín).
- El seed de `Paises_Limitrofes` inserta **ambas direcciones** de cada
  frontera explícitamente, en vez de confiar en el trigger
  `trg_limitrofes_simetria` — ese trigger solo dispara en inserts
  *posteriores* al `init.sql` (llega después en el archivo), así que para
  el seed inicial no alcanzaba.

### Decisiones de diseño sobre el SQL provisto (no son bugs, son elecciones)

- **`sp_realizar_ataque`** no se usa desde Python: su comparación de dados
  es una simplificación (el propio comentario del enunciado dice que hay
  que reemplazarla "en la capa de aplicación"). El combate real (tirar los
  dados, comparar de a pares, restar ejércitos, conquistar) se resuelve en
  Python dentro de `unified_server.py`, y después se hacen los mismos
  `UPDATE Territorios_Partida` que haría el procedure — así el trigger
  `trg_territorios_partida_after_update` (elimina jugadores sin
  territorio, chequea objetivo de ocupación) se sigue disparando igual.
- **`sp_fortificar`** tampoco se llama directo: no valida que los dos
  países sean adyacentes ni que el país destino sea del mismo jugador
  (podría "perder" ejércitos si el destino es de otro dueño). Python valida
  ambas cosas antes de tocar las tablas.
- El schema no tiene columna para "ejércitos pendientes de colocar este
  turno" (`sp_calcular_refuerzos` original coloca todo junto en un solo
  país en vez de dejar elegir). Como el frontend deja click-to-place país
  por país, ese contador vive en memoria del proceso Python
  (`PENDING_REINFORCEMENTS`), no en la base — se recalcula al arrancar
  cada fase de refuerzo con la misma fórmula (país/3, mínimo 3, + bonus de
  continente si lo controlás completo).
- No hay columna `host_id`/`is_host`: el host de la sala es, en cada
  momento, el jugador activo con menor `orden_turno` — se recalcula solo
  (si el host se va, el siguiente pasa a serlo automáticamente).
- Reconexión durante una partida en curso **no está soportada**: si alguien
  se desconecta a mitad de partida, se lo trata como si hubiese abandonado
  (para que el juego no quede trabado esperando su turno para siempre).
  Antes de empezar sí se puede recargar la página sin problema.

## 2. Backend (Python)

```bash
cd teg-web
python3 -m venv venv-backend
source venv-backend/bin/activate      # Windows: venv-backend\Scripts\activate
pip install -r requirements.txt

# Si tu MySQL no es root/teg_user en 127.0.0.1:3307, configurá esto (o
# copiá .env.example a .env y exportalo con tu shell/herramienta preferida):
export TEG_DB_HOST=127.0.0.1
export TEG_DB_PORT=3307
export TEG_DB_USER=teg_user
export TEG_DB_PASSWORD=teg_password
export TEG_DB_NAME=teg_web

python3 unified_server.py
```

Con eso ya tenés todo (frontend incluido) en **http://localhost:8765**.

## 3. ¿Y el venv del frontend?

El frontend es HTML/CSS/JS puro (módulos ES6, sin build step, sin
`package.json`) y **ya lo sirve `unified_server.py`** desde el mismo
proceso/puerto. No necesita su propio entorno Python para nada — de hecho
no necesita Python para nada en general.

Si igual querés separarlo en dos procesos (por ejemplo para iterar el CSS
sin reiniciar el backend), el repo trae `serve_no_sw.py` (estático puro,
sin caché) y `serve_proxy.py` (estático + intenta hacer proxy de `/api` y
`/ws` hacia el backend). Ninguno necesita ninguna dependencia externa
(son stdlib puro), así que ese "segundo venv" literalmente no necesita
`pip install` nada:

```bash
cd teg-web
python3 -m venv venv-frontend
source venv-frontend/bin/activate
python3 serve_no_sw.py     # sirve solo estáticos en :8080, sin api/ws
# o
python3 serve_proxy.py     # intenta proxear /api y /ws hacia :8765
```

**Advertencia importante sobre `serve_proxy.py`**: usa `http.server`
(síncrono) para el proxy, que puede reenviar pedidos REST normales pero
**no puede** hacer proxy de un WebSocket real — eso requiere upgrade de
conexión y un socket persistente en ambas puntas, algo que ese modelo
síncrono no soporta. Si lo usás, el chat y las partidas en vivo **no van a
funcionar**. Quedó arreglado solo en las rutas hardcodeadas que traía
(apuntaban a `C:\Users\Thiago\...` y al puerto 8000), no se reescribió el
proxy en sí — para jugar de verdad, corré `unified_server.py` y entrá
directo a `http://localhost:8765`.

## 4. Jugar

1. Abrí `http://localhost:8765` en una pestaña — te va a pedir un nombre
   (se guarda en `sessionStorage`, así que cada pestaña nueva pide uno
   distinto, útil para probar con "varios jugadores" desde el mismo
   navegador).
2. Creá una sala o unite con un código.
3. Con 2+ jugadores en la sala, el host ve el botón "Iniciar Partida".
4. Fases por turno: **Refuerzo** (click en tus países para sumar
   ejércitos, según cuántos te den) → **Ataque** (click en tu país de
   origen, después en un país enemigo limítrofe) → **Fortificación**
   (mover ejércitos entre dos países tuyos limítrofes, una vez por turno)
   → pasa al siguiente jugador.
5. Cartas: se gana una carta por turno con al menos una conquista. Se
   canjean de a 3 (mismas o todas distintas, o con comodín) por ejércitos
   extra para el próximo refuerzo.
6. Objetivo: cada jugador tiene un objetivo de ocupación (conquistar 30
   países) asignado al azar; también gana si sos el último jugador con
   territorio.

## 5. Qué NO está implementado (para ser honesto)

- Objetivos de tipo `destruccion` (requieren asignar un rival objetivo a
  cada jugador) — el seed solo carga un objetivo de `ocupacion`.
- Timer de turno visible en el frontend pero no aplicado por el backend
  (nadie te apura, podés tomarte el tiempo que quieras en cada fase).
- Espectadores (el modelo de datos y parte del frontend lo contemplan,
  pero no hay flujo real para unirse como espectador).
- Reconexión a mitad de partida (ver arriba).

## Estructura relevante

```
teg-web/
├── unified_server.py       # el server real: REST + WS + lógica del juego
├── teg_data.py              # mapa (países/continentes/adyacencias) en Python
├── requirements.txt         # deps de unified_server.py
├── .env.example              # variables que unified_server.py realmente lee
├── database/
│   ├── init.sql              # schema + seed + triggers + procedures, todo junto
│   ├── 01_schema.sql          # (provisto) tablas
│   ├── 02_seed.sql            # (generado) países/continentes/fronteras/cartas
│   ├── 03_triggers.sql        # (provisto) triggers
│   ├── 04_procedures.sql      # (provisto, con 2 fixes) stored procedures
│   └── consultas_referencia.sql  # (provisto) consultas de referencia, no se ejecuta
├── frontend/                # HTML/CSS/JS estático, sin build step
├── serve_no_sw.py / serve_proxy.py / serve.ps1   # alternativas de solo-frontend (ver sección 3)
└── backend/, alembic/, docker-compose*.yml, nginx*.conf, README_backend_completo_sin_usar.md
    # la app SQLAlchemy/Docker abandonada — no se usa, se deja como referencia
```
