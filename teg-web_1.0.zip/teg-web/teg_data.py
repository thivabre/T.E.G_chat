"""
Datos estáticos del mapa de TEG.

El SVG (frontend/assets/map/teg-map.svg) define 41 países con
data-country-id y data-continent, pero el grupo <g id="borders"> está
vacío (es un placeholder) — no trae adyacencias. Este módulo define
esa información para poder correr la lógica del juego (ataques,
fortificación, cálculo de refuerzos por continente).
"""

CONTINENTS = {
    "north-america": {"name": "Norteamérica", "bonus": 5},
    "south-america": {"name": "Sudamérica", "bonus": 2},
    "europe": {"name": "Europa", "bonus": 5},
    "africa": {"name": "África", "bonus": 3},
    "asia": {"name": "Asia", "bonus": 7},
    "oceania": {"name": "Oceanía", "bonus": 2},
}

# country_id -> continent_id (extraído directamente del SVG)
COUNTRY_CONTINENT = {
    1: "north-america", 2: "north-america", 3: "north-america", 4: "north-america",
    5: "north-america", 6: "north-america", 7: "north-america",
    8: "south-america", 9: "south-america", 10: "south-america", 11: "south-america",
    12: "south-america",
    13: "europe", 14: "europe", 15: "europe", 16: "europe", 17: "europe",
    18: "europe", 19: "europe",
    20: "africa", 21: "africa", 22: "africa", 23: "africa", 24: "africa", 25: "africa",
    26: "asia", 27: "asia", 28: "asia", 29: "asia", 30: "asia", 31: "asia",
    32: "asia", 33: "asia", 34: "asia", 35: "asia", 36: "asia", 37: "asia",
    38: "oceania", 39: "oceania", 40: "oceania", 41: "oceania",
}

_CONTINENT_PREFIX = {
    "north-america": "Norteamérica",
    "south-america": "Sudamérica",
    "europe": "Europa",
    "africa": "África",
    "asia": "Asia",
    "oceania": "Oceanía",
}

# Nombres reales del TEG clásico (tomados de backend/seed_data.py), mapeados
# en orden a los 41 países que efectivamente tiene el SVG. El SVG tiene una
# forma por país pero es un mapa placeholder (polígonos genéricos, no
# geografía real) con 41 formas repartidas 7/5/7/6/12/4 por continente,
# mientras que el TEG real tiene 42 (9/4/7/6/12/4) — Europa/África/Asia/
# Oceanía calzan exacto; Norteamérica y Sudamérica se ajustaron para sumar
# 41 en vez de 42 (se dropean 2 nombres de Norteamérica y se suma
# "América Central" a Sudamérica en vez de dejarlo en Norteamérica).
_REAL_NAMES = {
    "north-america": ["Alaska", "Noroeste", "Groenlandia", "Alberta", "Ontario", "Quebec", "Estados Unidos del Oeste"],
    "south-america": ["Venezuela", "Perú", "Brasil", "Argentina", "América Central"],
    "europe": ["Islandia", "Gran Bretaña", "Escandinavia", "Europa del Norte", "Europa del Sur", "Europa del Este", "Ucrania"],
    "africa": ["África del Norte", "Egipto", "África Oriental", "Congo", "África del Sur", "Madagascar"],
    "asia": ["Urales", "Siberia", "Yakutsk", "Kamchatka", "Irkutsk", "Mongolia", "Japón", "China", "Medio Oriente", "India", "Sudeste Asiático", "Afganistán"],
    "oceania": ["Indonesia", "Nueva Guinea", "Australia Occidental", "Australia Oriental"],
}

# Nombre legible por país, tomado de _REAL_NAMES en orden dentro de cada
# continente (con fallback genérico "<Continente> <n>" por si algún
# continente tuviera más países que nombres definidos).
_counters = {}
COUNTRY_NAME = {}
for _cid in sorted(COUNTRY_CONTINENT.keys()):
    _cont = COUNTRY_CONTINENT[_cid]
    _counters[_cont] = _counters.get(_cont, 0) + 1
    _idx = _counters[_cont] - 1
    _names = _REAL_NAMES.get(_cont, [])
    COUNTRY_NAME[_cid] = _names[_idx] if _idx < len(_names) else f"{_CONTINENT_PREFIX[_cont]} {_counters[_cont]}"

ALL_COUNTRY_IDS = sorted(COUNTRY_CONTINENT.keys())

# Anillo de adyacencia dentro de cada continente + puentes entre
# continentes (análogos a los pasos clásicos del TEG: Groenlandia-
# Islandia, Alaska-Kamchatka, Gibraltar, Egipto-Oriente Medio, etc).
_RING_GROUPS = {
    "north-america": [1, 2, 3, 4, 5, 6, 7],
    "south-america": [8, 9, 10, 11, 12],
    "europe": [13, 14, 15, 16, 17, 18, 19],
    "africa": [20, 21, 22, 23, 24, 25],
    "asia": [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37],
    "oceania": [38, 39, 40, 41],
}

_BRIDGES = [
    (7, 8),    # Norteamérica - Sudamérica
    (1, 13),   # Norteamérica - Europa
    (4, 26),   # Norteamérica - Asia
    (19, 20),  # Europa - África
    (17, 30),  # Europa - Asia
    (25, 26),  # África - Asia
    (37, 38),  # Asia - Oceanía
]


# Fronteras reales del TEG clásico (por nombre), extraídas de
# backend/seed_data.py. Se filtran a los nombres que efectivamente están
# en COUNTRY_NAME (el TEG real tiene 42 países, este mapa placeholder
# tiene 41 formas, así que "Estados Unidos del Este" no tiene slot acá
# y sus fronteras se ignoran automáticamente al construir el grafo).
_REAL_BORDERS_BY_NAME = [
    ('Alaska', 'Noroeste'),
    ('Alaska', 'Alberta'),
    ('Alaska', 'Kamchatka'),
    ('Noroeste', 'Alaska'),
    ('Noroeste', 'Alberta'),
    ('Noroeste', 'Ontario'),
    ('Noroeste', 'Groenlandia'),
    ('Groenlandia', 'Noroeste'),
    ('Groenlandia', 'Ontario'),
    ('Groenlandia', 'Quebec'),
    ('Groenlandia', 'Islandia'),
    ('Alberta', 'Alaska'),
    ('Alberta', 'Noroeste'),
    ('Alberta', 'Ontario'),
    ('Alberta', 'Estados Unidos del Oeste'),
    ('Ontario', 'Noroeste'),
    ('Ontario', 'Groenlandia'),
    ('Ontario', 'Alberta'),
    ('Ontario', 'Estados Unidos del Oeste'),
    ('Ontario', 'Estados Unidos del Este'),
    ('Ontario', 'Quebec'),
    ('Quebec', 'Groenlandia'),
    ('Quebec', 'Ontario'),
    ('Quebec', 'Estados Unidos del Este'),
    ('Estados Unidos del Oeste', 'Alberta'),
    ('Estados Unidos del Oeste', 'Ontario'),
    ('Estados Unidos del Oeste', 'Estados Unidos del Este'),
    ('Estados Unidos del Oeste', 'América Central'),
    ('Estados Unidos del Este', 'Ontario'),
    ('Estados Unidos del Este', 'Quebec'),
    ('Estados Unidos del Este', 'Estados Unidos del Oeste'),
    ('Estados Unidos del Este', 'América Central'),
    ('América Central', 'Estados Unidos del Oeste'),
    ('América Central', 'Estados Unidos del Este'),
    ('América Central', 'Venezuela'),
    ('Venezuela', 'América Central'),
    ('Venezuela', 'Perú'),
    ('Venezuela', 'Brasil'),
    ('Perú', 'Venezuela'),
    ('Perú', 'Brasil'),
    ('Perú', 'Argentina'),
    ('Brasil', 'Venezuela'),
    ('Brasil', 'Perú'),
    ('Brasil', 'Argentina'),
    ('Brasil', 'África del Norte'),
    ('Argentina', 'Perú'),
    ('Argentina', 'Brasil'),
    ('Islandia', 'Groenlandia'),
    ('Islandia', 'Gran Bretaña'),
    ('Islandia', 'Escandinavia'),
    ('Gran Bretaña', 'Islandia'),
    ('Gran Bretaña', 'Escandinavia'),
    ('Gran Bretaña', 'Europa del Norte'),
    ('Gran Bretaña', 'Europa del Sur'),
    ('Escandinavia', 'Islandia'),
    ('Escandinavia', 'Gran Bretaña'),
    ('Escandinavia', 'Europa del Norte'),
    ('Escandinavia', 'Urales'),
    ('Escandinavia', 'Ucrania'),
    ('Europa del Norte', 'Gran Bretaña'),
    ('Europa del Norte', 'Escandinavia'),
    ('Europa del Norte', 'Europa del Sur'),
    ('Europa del Norte', 'Europa del Este'),
    ('Europa del Sur', 'Gran Bretaña'),
    ('Europa del Sur', 'Europa del Norte'),
    ('Europa del Sur', 'Europa del Este'),
    ('Europa del Sur', 'Medio Oriente'),
    ('Europa del Sur', 'Egipto'),
    ('Europa del Sur', 'África del Norte'),
    ('Europa del Este', 'Escandinavia'),
    ('Europa del Este', 'Europa del Norte'),
    ('Europa del Este', 'Europa del Sur'),
    ('Europa del Este', 'Urales'),
    ('Europa del Este', 'Ucrania'),
    ('Europa del Este', 'Medio Oriente'),
    ('Ucrania', 'Escandinavia'),
    ('Ucrania', 'Europa del Este'),
    ('Ucrania', 'Urales'),
    ('Ucrania', 'Afganistán'),
    ('Ucrania', 'Medio Oriente'),
    ('África del Norte', 'Europa del Sur'),
    ('África del Norte', 'Egipto'),
    ('África del Norte', 'Congo'),
    ('África del Norte', 'África Oriental'),
    ('África del Norte', 'Brasil'),
    ('Egipto', 'Europa del Sur'),
    ('Egipto', 'África del Norte'),
    ('Egipto', 'África Oriental'),
    ('Egipto', 'Medio Oriente'),
    ('África Oriental', 'Egipto'),
    ('África Oriental', 'África del Norte'),
    ('África Oriental', 'Congo'),
    ('África Oriental', 'Madagascar'),
    ('África Oriental', 'Medio Oriente'),
    ('África Oriental', 'India'),
    ('Congo', 'África del Norte'),
    ('Congo', 'África Oriental'),
    ('Congo', 'África del Sur'),
    ('África del Sur', 'Congo'),
    ('África del Sur', 'Madagascar'),
    ('Madagascar', 'África Oriental'),
    ('Madagascar', 'África del Sur'),
    ('Urales', 'Escandinavia'),
    ('Urales', 'Europa del Este'),
    ('Urales', 'Ucrania'),
    ('Urales', 'Siberia'),
    ('Urales', 'Afganistán'),
    ('Urales', 'China'),
    ('Siberia', 'Urales'),
    ('Siberia', 'Yakutsk'),
    ('Siberia', 'Irkutsk'),
    ('Siberia', 'Mongolia'),
    ('Siberia', 'China'),
    ('Yakutsk', 'Siberia'),
    ('Yakutsk', 'Irkutsk'),
    ('Yakutsk', 'Kamchatka'),
    ('Kamchatka', 'Yakutsk'),
    ('Kamchatka', 'Irkutsk'),
    ('Kamchatka', 'Mongolia'),
    ('Kamchatka', 'Japón'),
    ('Kamchatka', 'Alaska'),
    ('Irkutsk', 'Siberia'),
    ('Irkutsk', 'Yakutsk'),
    ('Irkutsk', 'Kamchatka'),
    ('Irkutsk', 'Mongolia'),
    ('Irkutsk', 'China'),
    ('Mongolia', 'Siberia'),
    ('Mongolia', 'Irkutsk'),
    ('Mongolia', 'Kamchatka'),
    ('Mongolia', 'Japón'),
    ('Mongolia', 'China'),
    ('Japón', 'Kamchatka'),
    ('Japón', 'Mongolia'),
    ('China', 'Urales'),
    ('China', 'Siberia'),
    ('China', 'Irkutsk'),
    ('China', 'Mongolia'),
    ('China', 'Afganistán'),
    ('China', 'India'),
    ('China', 'Sudeste Asiático'),
    ('Medio Oriente', 'Europa del Sur'),
    ('Medio Oriente', 'Europa del Este'),
    ('Medio Oriente', 'Ucrania'),
    ('Medio Oriente', 'Afganistán'),
    ('Medio Oriente', 'India'),
    ('Medio Oriente', 'Egipto'),
    ('Medio Oriente', 'África Oriental'),
    ('India', 'Medio Oriente'),
    ('India', 'China'),
    ('India', 'Sudeste Asiático'),
    ('India', 'Afganistán'),
    ('Sudeste Asiático', 'China'),
    ('Sudeste Asiático', 'India'),
    ('Sudeste Asiático', 'Indonesia'),
    ('Afganistán', 'Urales'),
    ('Afganistán', 'Ucrania'),
    ('Afganistán', 'China'),
    ('Afganistán', 'Medio Oriente'),
    ('Afganistán', 'India'),
    ('Indonesia', 'Sudeste Asiático'),
    ('Indonesia', 'Nueva Guinea'),
    ('Indonesia', 'Australia Occidental'),
    ('Nueva Guinea', 'Indonesia'),
    ('Nueva Guinea', 'Australia Occidental'),
    ('Nueva Guinea', 'Australia Oriental'),
    ('Australia Occidental', 'Indonesia'),
    ('Australia Occidental', 'Nueva Guinea'),
    ('Australia Occidental', 'Australia Oriental'),
    ('Australia Oriental', 'Nueva Guinea'),
    ('Australia Oriental', 'Australia Occidental'),
]


def _build_adjacency():
    name_to_id = {name: cid for cid, name in COUNTRY_NAME.items()}
    adj = {cid: set() for cid in ALL_COUNTRY_IDS}

    def link(a, b):
        adj[a].add(b)
        adj[b].add(a)

    linked_any = False
    for name_a, name_b in _REAL_BORDERS_BY_NAME:
        id_a = name_to_id.get(name_a)
        id_b = name_to_id.get(name_b)
        if id_a is not None and id_b is not None:
            link(id_a, id_b)
            linked_any = True

    # Puentes entre continentes que el mapa real de 42 países ya cubre por
    # nombre (América Central-Venezuela, Groenlandia-Islandia, Alaska-
    # Kamchatka, Europa del Sur-África del Norte/Egipto, Ucrania-Afganistán,
    # etc.) — no hace falta agregar nada extra si linked_any es True.
    # Fallback defensivo: si por algún motivo no se pudo enlazar nada
    # (p.ej. los nombres no calzan), usar el anillo sintético por
    # continente + puentes para que el juego siga siendo jugable.
    if not linked_any:
        for group in _RING_GROUPS.values():
            n = len(group)
            for i in range(n):
                link(group[i], group[(i + 1) % n])
        for a, b in _BRIDGES:
            link(a, b)

    # Asegurar que ningún país quede sin ninguna conexión (aislado): si
    # alguno quedó sin vecinos por el filtrado de nombres, lo conectamos
    # al menos con el siguiente país de su propio continente.
    for cid in ALL_COUNTRY_IDS:
        if not adj[cid]:
            cont = COUNTRY_CONTINENT[cid]
            group = _RING_GROUPS.get(cont, [])
            others = [c for c in group if c != cid]
            if others:
                link(cid, others[0])

    return {cid: sorted(neighbors) for cid, neighbors in adj.items()}

ADJACENCY = _build_adjacency()


def borders_as_pairs():
    """Lista plana de pares {from, to} (una entrada por cada dirección),
    tal como la espera el frontend en payload.borders."""
    pairs = []
    for cid, neighbors in ADJACENCY.items():
        for nid in neighbors:
            pairs.append({"from": cid, "to": nid})
    return pairs


def continents_payload():
    return [
        {"id": cont_id, "name": info["name"], "bonus": info["bonus"]}
        for cont_id, info in CONTINENTS.items()
    ]


def fully_owned_continents(owner_by_country: dict, player_id) -> list:
    """Continentes donde TODOS los países pertenecen a player_id."""
    owned = []
    for cont_id in CONTINENTS:
        country_ids = [cid for cid, c in COUNTRY_CONTINENT.items() if c == cont_id]
        if all(owner_by_country.get(cid) == player_id for cid in country_ids):
            owned.append(cont_id)
    return owned


def calculate_reinforcements(owner_by_country: dict, player_id) -> int:
    country_count = sum(1 for owner in owner_by_country.values() if owner == player_id)
    base = max(3, country_count // 3)
    bonus = sum(CONTINENTS[c]["bonus"] for c in fully_owned_continents(owner_by_country, player_id))
    return base + bonus
