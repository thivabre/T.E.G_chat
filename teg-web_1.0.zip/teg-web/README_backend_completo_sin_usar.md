# TEG Web - Digital TEG Board Game

A complete web implementation of the classic TEG board game (similar to Risk) with real-time multiplayer support.

## Features

- **Real-time multiplayer** via WebSockets
- **Two game modes**: Objectives (secret missions) and World Conquest
- **2-6 players** per game + unlimited spectators
- **Public/Private rooms** with 6-character codes
- **Configurable turn timer** (60-300 seconds)
- **Chat system**: General chat + private whispers between players
- **Classic TEG map** with 42 countries and 6 continents as interactive SVG
- **3D perspective table background** with CSS transforms
- **Docker deployment** ready for Oracle OCI Free Tier

## Tech Stack

### Backend
- **FastAPI** - Modern async Python web framework
- **SQLAlchemy 2.0** - Async ORM with asyncmy (MySQL driver)
- **WebSockets** - Native FastAPI WebSocket support
- **Pydantic** - Data validation and serialization
- **Alembic** - Database migrations

### Frontend
- **Vanilla JavaScript (ES6 Modules)** - No build step required
- **HTML5 + CSS3** - Modern standards
- **Interactive SVG** - Scalable vector map
- **CSS 3D Transforms** - Perspective table effect

### Infrastructure
- **Docker Compose** - Multi-container orchestration
- **Nginx** - Reverse proxy with WebSocket support
- **MySQL 8.0** - Database

## Project Structure

```
teg-web/
├── backend/
│   ├── app/
│   │   ├── api/           # REST API endpoints
│   │   │   ├── rooms.py   # Room management
│   │   │   ├── game.py    # Game actions
│   │   │   └── chat.py    # Chat history
│   │   ├── game_logic/    # Core game mechanics
│   │   │   ├── board.py   # Board setup, countries
│   │   │   ├── cards.py   # Card deck, trading
│   │   │   ├── combat.py  # Dice combat resolution
│   │   │   ├── objectives.py # Victory conditions
│   │   │   ├── turns.py   # Turn/phase management
│   │   │   └── reinforcement.py # Army calculation
│   │   ├── websocket/     # Real-time communication
│   │   │   ├── manager.py # Connection management
│   │   │   ├── handlers.py # Event handlers
│   │   │   └── events.py  # Event definitions
│   │   ├── models.py      # SQLAlchemy ORM models
│   │   ├── schemas.py     # Pydantic schemas
│   │   ├── database.py    # DB connection
│   │   ├── config.py      # Settings
│   │   └── main.py        # FastAPI app entry
│   ├── requirements.txt
│   ├── Dockerfile
│   └── alembic/           # Migrations
├── frontend/
│   ├── index.html         # Lobby page
│   ├── game.html          # Game board page
│   ├── css/               # Stylesheets
│   ├── js/                # JavaScript modules
│   └── assets/            # SVG map, images
├── database/
│   └── init.sql           # Initial schema + data
├── docker-compose.yml     # Development
├── docker-compose.prod.yml # Production
├── nginx.dev.conf         # Dev nginx config
├── nginx.prod.conf        # Prod nginx config
└── .env.example           # Environment template
```

## Quick Start (Development)

### Prerequisites
- Docker & Docker Compose
- Git

### Run with Docker Compose

```bash
# Clone and navigate
git clone <repo>
cd teg-web

# Start development stack
docker-compose up -d

# Access:
# Frontend: http://localhost:3000
# Backend API: http://localhost:8000
# API Docs: http://localhost:8000/api/docs
```

### Manual Development Setup

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Set environment variables
cp ../.env.example .env
# Edit .env with your settings

# Run migrations
alembic upgrade head

# Start server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Frontend (in another terminal)
cd frontend
# Serve with any static server, e.g.:
npx serve .
# or
python -m http.server 3000
```

## Production Deployment (Oracle OCI Free Tier)

### 1. Prepare Server

```bash
# On Oracle OCI instance (Ubuntu 22.04)
sudo apt update && sudo apt install -y docker.io docker-compose git
sudo usermod -aG docker $USER
# Log out and back in
```

### 2. Deploy

```bash
# Clone repository
git clone <repo>
cd teg-web

# Configure environment
cp .env.example .env
# Edit .env with secure passwords and your domain

# SSL Certificates (Let's Encrypt)
sudo apt install -y certbot
sudo certbot certonly --standalone -d your-domain.com
# Copy certs to ./ssl/

# Start production stack
docker-compose -f docker-compose.prod.yml up -d
```

### 3. Nginx SSL Configuration

Place your SSL certificates in `./ssl/`:
- `fullchain.pem` - Certificate chain
- `privkey.pem` - Private key

The nginx config expects these at `/etc/nginx/ssl/` inside the container.

## Game Rules Summary

### Setup Phase
1. Countries distributed rotationally among players
2. Each country starts with 1 army
3. Players take turns placing 1 additional army per turn

### Turn Phases
1. **Reinforcement**: Receive armies (countries/3 + continent bonuses)
   - Minimum 3 armies
   - Trade cards for extra armies (escalating: 5, 7, 9, 11, 13, 15...)
2. **Attack**: Attack adjacent enemy countries
   - Max 3 attacker dice vs 2 defender dice
   - Highest dice win (defender wins ties)
   - Conquered country: move at least attacker_dice armies
   - Draw 1 card per turn if conquered at least 1 country
3. **Fortify**: Move armies between connected own countries
   - One fortification per turn
   - Must leave at least 1 army

### Victory Conditions
- **Objectives Mode**: Complete secret mission (occupy territories, control continents, or eliminate player)
- **World Conquest**: Eliminate all other players

### Card Trading
- 3 cards of same type (Infantry/Cavalry/Artillery)
- 3 cards of different types (one of each)
- Any 2 cards + 1 Joker
- Escalating values: 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, then +5 each

## API Endpoints

### Rooms
- `GET /api/rooms/public` - List public rooms
- `POST /api/rooms` - Create room
- `POST /api/rooms/join-by-code` - Join by code
- `GET /api/rooms/{room_id}` - Room details
- `POST /api/rooms/{room_id}/ready/{player_id}` - Set ready
- `DELETE /api/rooms/{room_id}/leave/{player_id}` - Leave room

### Game
- `GET /api/game/{room_id}/state` - Full game state
- `GET /api/game/{room_id}/board` - Static board info
- `GET /api/game/{room_id}/countries` - Game countries
- `GET /api/game/{room_id}/players` - Player states
- `POST /api/game/{room_id}/trade` - Trade cards
- `GET /api/game/{room_id}/valid-trades/{player_id}` - Valid combos
- `POST /api/game/{room_id}/combat-preview` - Combat probabilities

### Chat
- `GET /api/chat/{room_id}/messages` - Chat history
- `GET /api/chat/{room_id}/unread-count` - Unread count
- `GET /api/chat/{room_id}/private/{player_id}/{other_id}` - Private chat

### WebSocket
- `WS /ws/{room_id}?player_id=X` - Player connection
- `WS /ws/{room_id}?spectator_id=X` - Spectator connection

## WebSocket Events

### Client → Server
| Event | Data | Description |
|-------|------|-------------|
| `join_room` | `{room_id, player_name}` | Join as player |
| `leave_room` | `{room_id}` | Leave room |
| `start_game` | `{room_id}` | Host starts game |
| `place_armies` | `{room_id, country_id}` | Setup: place army |
| `reinforce` | `{room_id, country_id, armies}` | Place reinforcement |
| `attack` | `{room_id, from, to, dice}` | Attack country |
| `fortify` | `{room_id, from, to, armies}` | Move armies |
| `trade_cards` | `{room_id, card_ids[3]}` | Trade cards |
| `end_turn` | `{room_id}` | End turn |
| `send_chat` | `{room_id, type, message, recipient?}` | Send message |
| `request_state` | `{room_id}` | Sync state |
| `spectate` | `{room_id, spectator_name}` | Join as spectator |

### Server → Client
| Event | Description |
|-------|-------------|
| `room_update` | Room/player/spectator changes |
| `game_started` | Initial game state |
| `state_update` | Full state sync |
| `turn_change` | New player's turn |
| `phase_change` | Phase transition |
| `combat_result` | Dice rolls, losses, conquest |
| `card_drawn` | Card drawn after conquest |
| `cards_traded` | Trade result |
| `objective_complete` | Objective achieved |
| `game_over` | Winner declared |
| `chat_message` | New chat message |
| `player_eliminated` | Player eliminated |
| `error` | Error response |
| `timer_update` | Turn timer countdown |

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | MySQL connection string | `mysql+asyncmy://teg_user:teg_password@localhost:3306/teg_web` |
| `SECRET_KEY` | Session/token secret | Required in production |
| `DEBUG` | Debug mode | `false` |
| `CORS_ORIGINS` | Allowed origins | `["*"]` |
| `MYSQL_ROOT_PASSWORD` | MySQL root password | Required |
| `MYSQL_USER` | Database user | `teg_user` |
| `MYSQL_PASSWORD` | Database password | Required |
| `DOMAIN` | Production domain | Required for SSL |

## Database Schema

The database includes 14 tables:
- `continents` (6) - Continent definitions with bonuses
- `countries` (42) - Countries with SVG paths
- `borders` - Adjacency relationships
- `cards` (44) - Territory cards with types
- `objectives` (8) - Secret mission cards
- `rooms` - Game rooms
- `players` - Players in rooms
- `spectators` - Spectators
- `game_countries` - Country ownership per game
- `game_cards` - Card ownership per game
- `player_objectives` - Secret objectives per player
- `chat_messages` - Chat history
- `turn_timers` - Active turn timers
- Views for lobby and game state

## Contributing

1. Fork the repository
2. Create feature branch
3. Make changes
4. Test with `docker-compose up`
5. Submit PR

## License

MIT License - Feel free to use for personal or commercial projects.

## Acknowledgments

- Based on the classic TEG board game
- Inspired by Risk game mechanics
- Map design adapted for web SVG rendering