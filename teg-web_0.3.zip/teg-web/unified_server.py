#!/usr/bin/env python3
"""
TEG - Servidor Unificado (reescrito desde cero)
Sirve frontend estatico + API REST + WebSocket en un solo proceso.
Sin Docker, sin nginx. Solo Python.
"""
import os
import sys
import json
import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any

# Setup path y env ANTES de importar nada
BACKEND_DIR = Path(r"C:\Users\Thiago\teg-web\backend")
FRONTEND_DIR = Path(r"C:\Users\Thiago\teg-web\frontend")
os.environ["DATABASE_URL"] = "mysql+aiomysql://teg_user:teg_password@127.0.0.1:3307/teg_web"
os.chdir(str(BACKEND_DIR))
sys.path.insert(0, str(BACKEND_DIR))

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import select, text
import aiomysql

# Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger("teg")

# =============================================================================
# DB
# =============================================================================
DB_CONFIG = {
    "host": "127.0.0.1",
    "port": 3307,
    "user": "teg_user",
    "password": "teg_password",
    "db": "teg_web",
    "autocommit": True,
    "charset": "utf8mb4",
}

def jsonify_dt(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)

def row_to_dict(row: dict) -> dict:
    return {k: jsonify_dt(v) for k, v in row.items()}

async def query(sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
    conn = await aiomysql.connect(**DB_CONFIG)
    try:
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute(sql, params)
            rows = await cur.fetchall()
        return rows
    finally:
        conn.close()

async def execute(sql: str, params: tuple = ()) -> int:
    conn = await aiomysql.connect(**DB_CONFIG)
    try:
        async with conn.cursor() as cur:
            await cur.execute(sql, params)
            return cur.lastrowid
    finally:
        conn.close()

# =============================================================================
# FastAPI App
# =============================================================================
app = FastAPI(title="TEG Server")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Mount frontend
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

# =============================================================================
# Models (Pydantic)
# =============================================================================
class RoomCreate(BaseModel):
    name: str
    max_players: int = 6
    game_mode: str = "objetivos"
    turn_time_limit: int = 60
    is_public: bool = True

class JoinRoom(BaseModel):
    name: str

class ChatMessage(BaseModel):
    sender: str
    message: str

# =============================================================================
# API Routes
# =============================================================================
@app.get("/api/rooms/public")
async def list_public_rooms():
    rows = await query("""
        SELECT r.*, COUNT(p.id) as player_count
        FROM rooms r
        LEFT JOIN players p ON p.room_id = r.id
        WHERE r.type = 'publica' AND r.status IN ('waiting', 'in_progress')
        GROUP BY r.id
        ORDER BY r.created_at DESC
        LIMIT 50
    """)
    return [row_to_dict(r) for r in rows]

@app.get("/api/rooms/{room_id}")
async def get_room(room_id: int):
    rows = await query("SELECT * FROM rooms WHERE id = %s", (room_id,))
    if not rows:
        raise HTTPException(404, "Room not found")
    room = row_to_dict(rows[0])

    players_rows = await query("SELECT * FROM players WHERE room_id = %s ORDER BY position", (room_id,))
    room["players"] = [row_to_dict(p) for p in players_rows]

    spec_rows = await query("SELECT * FROM spectators WHERE room_id = %s", (room_id,))
    room["spectators"] = [row_to_dict(s) for s in spec_rows]

    return room

@app.post("/api/rooms")
async def create_room(data: RoomCreate):
    import random, string
    code = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    type_ = "publica" if data.is_public else "privada"

    room_id = await execute("""
        INSERT INTO rooms (code, name, type, status, max_players, game_mode, turn_time_limit, current_phase, turn_number, trade_count, created_at)
        VALUES (%s, %s, %s, 'waiting', %s, %s, %s, 'setup', 0, 0, NOW())
    """, (code, data.name, type_, data.max_players, data.game_mode, data.turn_time_limit))

    return await get_room(room_id)

@app.delete("/api/rooms/{room_id}")
async def delete_room(room_id: int):
    await execute("DELETE FROM players WHERE room_id = %s", (room_id,))
    await execute("DELETE FROM spectators WHERE room_id = %s", (room_id,))
    await execute("DELETE FROM rooms WHERE id = %s", (room_id,))
    return {"ok": True}

@app.post("/api/rooms/{room_id}/join")
async def join_room(room_id: int, data: JoinRoom):
    rows = await query("SELECT * FROM rooms WHERE id = %s", (room_id,))
    if not rows:
        raise HTTPException(404, "Room not found")

    # Check if player already exists
    existing = await query("SELECT * FROM players WHERE room_id = %s AND name = %s", (room_id, data.name))
    if existing:
        return row_to_dict(existing[0])

    # Count existing players
    count_rows = await query("SELECT COUNT(*) as c FROM players WHERE room_id = %s", (room_id,))
    count = count_rows[0]["c"]
    if count >= 6:
        raise HTTPException(400, "Room is full")

    color_map = {1: "#FF5733", 2: "#33C1FF", 3: "#FFBD33", 4: "#7D33FF", 5: "#33FF57", 6: "#FF33A8"}
    color = color_map.get(count + 1, "#FFFFFF")
    is_host = (count == 0)

    player_id = await execute("""
        INSERT INTO players (room_id, name, color, position, status, armies_in_hand, is_host, is_ready, joined_at)
        VALUES (%s, %s, %s, %s, 'active', 0, %s, 0, NOW())
    """, (room_id, data.name, color, count + 1, 1 if is_host else 0))

    if is_host:
        await execute("UPDATE rooms SET host_id = %s WHERE id = %s", (player_id, room_id))

    rows = await query("SELECT * FROM players WHERE id = %s", (player_id,))
    return row_to_dict(rows[0])

@app.post("/api/rooms/{room_id}/start")
async def start_game(room_id: int):
    await execute("UPDATE rooms SET status = 'in_progress', started_at = NOW() WHERE id = %s", (room_id,))
    return {"ok": True}

@app.post("/api/rooms/{room_id}/leave/{player_id}")
async def leave_room(room_id: int, player_id: int):
    await execute("DELETE FROM players WHERE id = %s AND room_id = %s", (player_id, room_id))
    return {"ok": True}

# =============================================================================
# WebSocket Connection Manager (per-room broadcast)
# =============================================================================
class ConnectionManager:
    def __init__(self):
        # room_id -> list of {"ws": WebSocket, "player_id": int, "name": str}
        self.rooms: Dict[int, List[Dict[str, Any]]] = {}

    def add(self, room_id: int, websocket: WebSocket, player_id: int, name: str):
        self.rooms.setdefault(room_id, []).append(
            {"ws": websocket, "player_id": player_id, "name": name}
        )

    def remove(self, room_id: int, websocket: WebSocket):
        conns = self.rooms.get(room_id, [])
        self.rooms[room_id] = [c for c in conns if c["ws"] is not websocket]
        if not self.rooms[room_id]:
            del self.rooms[room_id]

    async def broadcast(self, room_id: int, message: dict):
        conns = self.rooms.get(room_id, [])
        dead = []
        for c in conns:
            try:
                await c["ws"].send_text(json.dumps(message, default=str))
            except Exception:
                dead.append(c["ws"])
        for ws in dead:
            self.remove(room_id, ws)

manager = ConnectionManager()

async def build_state_payload(room_id: int, name: str, player: dict) -> dict:
    """Build the flat state_update payload the frontend expects, personalized
    with my_state for a given connecting player (used for the direct send)."""
    rooms_now = await query("SELECT * FROM rooms WHERE id = %s", (room_id,))
    room_data = row_to_dict(rooms_now[0]) if rooms_now else {}

    players_rows = await query("SELECT * FROM players WHERE room_id = %s ORDER BY position", (room_id,))
    players = [row_to_dict(p) for p in players_rows]

    map_svg = ""
    try:
        map_path = FRONTEND_DIR / "assets" / "map" / "teg-map.svg"
        if map_path.exists():
            map_svg = map_path.read_text(encoding="utf-8")
    except Exception as e:
        log.warning(f"Could not load map SVG: {e}")

    return {
        "event": "state_update",
        "data": {
            "id": room_data.get("id"),
            "code": room_data.get("code"),
            "name": room_data.get("name"),
            "status": room_data.get("status"),
            "current_phase": room_data.get("current_phase"),
            "host_id": room_data.get("host_id"),
            "turn_number": room_data.get("turn_number"),
            "max_players": room_data.get("max_players"),
            "game_mode": room_data.get("game_mode"),
            "created_at": room_data.get("created_at"),
            "players": [
                {"id": p["id"], "name": p["name"], "color": p["color"],
                    "position": p["position"], "is_host": bool(p.get("is_host")),
                    "is_ready": bool(p.get("is_ready")), "armies_in_hand": p.get("armies_in_hand")}
                for p in players
            ],
            "countries": [],
            "continents": [],
            "map_svg": map_svg,
            "spectators": [],
            "my_state": {
                "player_id": player.get("id") if isinstance(player, dict) else None,
                "player_name": player.get("name") if isinstance(player, dict) else name,
                "color": player.get("color") if isinstance(player, dict) else "#FFFFFF",
                "armies": 0,
                "cards": 0,
                "objective": None,
                "is_host": bool(player.get("is_host")) if isinstance(player, dict) else False,
            },
        },
    }

async def broadcast_room_state(room_id: int):
    """Send every connected client in the room its own personalized state
    (so each client's my_state/is_host stays correct)."""
    conns = list(manager.rooms.get(room_id, []))
    for c in conns:
        try:
            rows = await query("SELECT * FROM players WHERE id = %s", (c["player_id"],))
            player = row_to_dict(rows[0]) if rows else {"name": c["name"]}
            payload = await build_state_payload(room_id, c["name"], player)
            await c["ws"].send_text(json.dumps(payload, default=str))
        except Exception:
            log.exception(f"Failed sending state to a client in room {room_id}")

async def reassign_host_if_needed(room_id: int, left_player_id: int):
    """If the player leaving was host, promote the next player (by position)."""
    rooms_now = await query("SELECT * FROM rooms WHERE id = %s", (room_id,))
    if not rooms_now:
        return
    room_now = row_to_dict(rooms_now[0])
    if room_now.get("host_id") != left_player_id:
        return

    remaining = await query("SELECT * FROM players WHERE room_id = %s ORDER BY position", (room_id,))
    if not remaining:
        await execute("UPDATE rooms SET host_id = NULL WHERE id = %s", (room_id,))
        return

    new_host = remaining[0]
    await execute("UPDATE players SET is_host = 0 WHERE room_id = %s", (room_id,))
    await execute("UPDATE players SET is_host = 1 WHERE id = %s", (new_host["id"],))
    await execute("UPDATE rooms SET host_id = %s WHERE id = %s", (new_host["id"], room_id))
    log.info(f"Host reassigned in room {room_id}: new host = {new_host['name']}")

# =============================================================================
# WebSocket
# =============================================================================
@app.websocket("/ws/{room_id}")
async def ws_endpoint(websocket: WebSocket, room_id: int, name: str = "player", spectate: bool = False):
    log.info(f"WS connect: room={room_id} name={name}")
    await websocket.accept()

    player_id_for_conn = None
    try:
        # Cargar room
        rooms = await query("SELECT * FROM rooms WHERE id = %s", (room_id,))
        if not rooms:
            await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Room not found"}}))
            await websocket.close()
            return
        room = row_to_dict(rooms[0])

        # Find or create player by name
        existing_p = await query("SELECT * FROM players WHERE room_id = %s AND name = %s", (room_id, name))
        if existing_p:
            player = row_to_dict(existing_p[0])
        else:
            # Count and create new
            count_rows = await query("SELECT COUNT(*) as c FROM players WHERE room_id = %s", (room_id,))
            count = count_rows[0]["c"] if count_rows else 0
            if count >= 6:
                await websocket.send_text(json.dumps({"event":"error","data":{"message":"Room full"}}))
                return
            color_map = {1:"#FF5733",2:"#33C1FF",3:"#FFBD33",4:"#7D33FF",5:"#33FF57",6:"#FF33A8"}
            color = color_map.get(count+1,"#FFFFFF")
            pid = await execute("""
                INSERT INTO players (room_id, name, color, position, status, armies_in_hand, is_host, is_ready, joined_at)
                VALUES (%s, %s, %s, %s, 'active', 0, %s, 1, NOW())
            """, (room_id, name, color, count+1, 1 if count==0 else 0))
            if count == 0:
                await execute("UPDATE rooms SET host_id = %s WHERE id = %s", (pid, room_id))
            rows = await query("SELECT * FROM players WHERE id = %s", (pid,))
            player = row_to_dict(rows[0]) if rows else {}

        player_id_for_conn = player.get("id")
        manager.add(room_id, websocket, player_id_for_conn, name)

        # Send personalized state to the newly connected client
        state = await build_state_payload(room_id, name, player)
        await websocket.send_text(json.dumps(state, default=str))
        log.info(f"WS sent state_update: room={room_id}, players={len(state['data']['players'])}")

        # Let everyone else in the room know a new player joined
        await broadcast_room_state(room_id)

        # Loop
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Invalid JSON"}}))
                continue

            if not isinstance(msg, dict):
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": "Expected a JSON object"}}))
                continue

            evt = msg.get("event", "")
            data = msg.get("data", {})

            if evt == "ping":
                await websocket.send_text(json.dumps({"event": "pong", "data": {}}))

            elif evt == "join_room":
                await broadcast_room_state(room_id)

            elif evt == "start_game":
                await execute("UPDATE rooms SET status = 'in_progress', current_phase = 'reinforce', started_at = NOW() WHERE id = %s", (room_id,))

                map_svg = ""
                try:
                    map_path = FRONTEND_DIR / "assets" / "map" / "teg-map.svg"
                    if map_path.exists():
                        map_svg = map_path.read_text(encoding="utf-8")
                except Exception as e:
                    log.warning(f"Could not load map SVG: {e}")

                players_now = await query("SELECT * FROM players WHERE room_id = %s ORDER BY position", (room_id,))
                players_list = [
                    {"id": p["id"], "name": p["name"], "color": p["color"],
                        "position": p["position"], "is_host": bool(p.get("is_host")),
                        "is_ready": bool(p.get("is_ready")), "armies_in_hand": p.get("armies_in_hand")}
                    for p in players_now
                ]

                for c in list(manager.rooms.get(room_id, [])):
                    my_row = next((p for p in players_now if p["id"] == c["player_id"]), None)
                    game_started_payload = {
                        "event": "game_started",
                        "data": {
                            "game_id": room_id,
                            "room": {"id": room_id, "name": room["name"]},
                            "phase": "reinforce",
                            "current_player_id": players_list[0]["id"] if players_list else None,
                            "countries": [],
                            "continents": [],
                            "borders": [],
                            "map_svg": map_svg,
                            "players": players_list,
                            "spectators": [],
                            "my_state": {
                                "player_id": my_row["id"] if my_row else None,
                                "player_name": my_row["name"] if my_row else c["name"],
                                "color": my_row["color"] if my_row else "#FFFFFF",
                                "armies": my_row.get("armies_in_hand", 0) if my_row else 0,
                                "cards": 0,
                                "objective": None,
                                "is_host": bool(my_row.get("is_host")) if my_row else False,
                            },
                        }
                    }
                    try:
                        await c["ws"].send_text(json.dumps(game_started_payload, default=str))
                    except Exception:
                        log.exception(f"Failed sending game_started to a client in room {room_id}")

            elif evt == "send_chat":
                await manager.broadcast(room_id, {
                    "event": "chat_message",
                    "data": {
                        "sender": name,
                        "message": data.get("message", ""),
                        "timestamp": datetime.now().isoformat(),
                    }
                })

            else:
                await websocket.send_text(json.dumps({"event": "error", "data": {"message": f"Unknown event: {evt}"}}))

    except WebSocketDisconnect:
        log.info(f"WS disconnect: room={room_id}")
    except Exception as e:
        log.exception(f"WS error: {e}")
    finally:
        manager.remove(room_id, websocket)
        if player_id_for_conn is not None:
            try:
                await execute("DELETE FROM players WHERE id = %s", (player_id_for_conn,))
                await reassign_host_if_needed(room_id, player_id_for_conn)
                await broadcast_room_state(room_id)
            except Exception:
                log.exception(f"Failed cleaning up player {player_id_for_conn} in room {room_id}")

# =============================================================================
# Frontend catch-all
# =============================================================================
@app.get("/")
async def root():
    return FileResponse(str(FRONTEND_DIR / "index.html"))

from fastapi.responses import FileResponse

@app.get("/{path:path}")
async def serve_frontend(path: str):
    full = FRONTEND_DIR / path
    if full.exists() and full.is_file():
        return FileResponse(str(full))
    return FileResponse(str(FRONTEND_DIR / "index.html"))


# =============================================================================
# Main
# =============================================================================
if __name__ == "__main__":
    import uvicorn
    log.info("=" * 60)
    log.info("TEG UNIFIED SERVER (sin docker, sin nginx)")
    log.info(f"Frontend: {FRONTEND_DIR}")
    log.info(f"DB: 127.0.0.1:3307/teg_web")
    log.info(f"URL: http://localhost:8765")
    log.info("=" * 60)
    uvicorn.run(app, host="0.0.0.0", port=8765, reload=False, log_level="info")
