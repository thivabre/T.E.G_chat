/**
 * TEG Web - Game Board Logic
 * Main game client handling WebSocket, state, and board interactions
 */

import { $, $$, $$$, createElement, apiGet, apiPost, createWebSocket, showToast, escapeHtml, formatTime, generateId, getPlayerColor, getContrastColor, EventEmitter } from './utils.js?v=110';
import { renderBoard, updateBoard, setBoardInteractive, panTo, zoomTo, resetView, setPlayerColors, setAdjacency } from './board-renderer.js?v=110';
import { initChat, sendChatMessage, openPrivateChat, closePrivateChat } from './chat.js?v=110';

// ============================================================================
// Game State
// ============================================================================

const gameState = {
  // Connection
  ws: null,
  connected: false,
  reconnecting: false,

  // Room & Game
  roomId: null,
  gameId: null,
  playerId: null,
  playerName: null,
  isHost: false,
  isSpectator: false,

  // Game Data
  players: [],
  spectators: [],
  currentPlayerId: null,
  currentPhase: 'waiting',
  phaseTimer: 0,
  turnTimeLimit: 0,

  // Board
  countries: new Map(),
  continents: new Map(),
  borders: new Map(),

  // My State
  myCountries: [],
  myCards: [],
  selectedCountry: null,
  attackFrom: null,
  fortifyFrom: null,

  // Phase
  pendingReinforcements: 0,
  selectedCards: new Set(),

  // UI
  zoomLevel: 1,
  panX: 0,
  panY: 0,
};

// Event emitter for UI updates
const events = new EventEmitter();

// ============================================================================
// DOM Elements
// ============================================================================

const elements = {
  // Header
  gameRoomName: $('#gameRoomName'),
  gameCode: $('#gameCode'),
  phaseLabel: $('#phaseLabel'),
  phaseTimer: $('#phaseTimer'),
  timerValue: $('#timerValue'),
  turnPlayerName: $('#turnPlayerName'),
  chatBadge: $('#chatBadge'),
  chatToggleBtn: $('#chatToggleBtn'),
  menuBtn: $('#menuBtn'),
  changeNameBtn: $('#changeNameBtn'),
  closeGameMenuBtn: $('#closeGameMenuBtn'),

  // Sidebar
  myAvatar: $('#myAvatar'),
  myName: $('#myName'),
  myCountries: $('#myCountries'),
  myArmies: $('#myArmies'),
  myCards: $('#myCards'),
  objectiveCard: $('#objectiveCard'),
  objectiveText: $('#objectiveText'),
  phaseActionsCard: $('#phaseActionsCard'),
  phaseActionsContent: $('#phaseActionsContent'),
  cardsCard: $('#cardsCard'),
  cardCount: $('#cardCount'),
  tradeValue: $('#tradeValue'),
  cardsGrid: $('#cardsGrid'),
  tradeCardsBtn: $('#tradeCardsBtn'),
  tradeBtnText: $('#tradeBtnText'),
  diceCard: $('#diceCard'),
  diceResult: $('#diceResult'),
  playersList: $('#playersList'),
  playerCount: $('#playerCount'),
  spectatorsCard: $('#spectatorsCard'),
  spectatorCount: $('#spectatorCount'),
  spectatorsList: $('#spectatorsList'),
  gameLog: $('#gameLog'),
  clearLogBtn: $('#clearLogBtn'),

  // Board
  boardWrapper: $('#boardWrapper'),
  gameBoard: $('#gameBoard'),
  boardLoading: $('#boardLoading'),
  zoomInBtn: $('#zoomInBtn'),
  zoomOutBtn: $('#zoomOutBtn'),
  resetViewBtn: $('#resetViewBtn'),
  zoomLevel: $('#zoomLevel'),

  // Modals
  combatModal: $('#combatModal'),
  attackerTerritory: $('#attackerTerritory'),
  defenderTerritory: $('#defenderTerritory'),
  attackerDiceBtns: $('#attackerDiceBtns'),
  defenderDiceBtns: $('#defenderDiceBtns'),
  attackerDiceCount: $('#attackerDiceCount'),
  defenderDiceCount: $('#defenderDiceCount'),
  attackerArmies: $('#attackerArmies'),
  defenderArmies: $('#defenderArmies'),
  cancelCombatBtn: $('#cancelCombatBtn'),
  confirmCombatBtn: $('#confirmCombatBtn'),

  fortifyModal: $('#fortifyModal'),
  fortifyFromDisplay: $('#fortifyFromDisplay'),
  fortifyToDisplay: $('#fortifyToDisplay'),
  fortifyArmiesInput: $('#fortifyArmiesInput'),
  fortifyArmiesSlider: $('#fortifyArmiesSlider'),
  cancelFortifyBtn: $('#cancelFortifyBtn'),
  confirmFortifyBtn: $('#confirmFortifyBtn'),

  tradeModal: $('#tradeModal'),
  currentTradeValue: $('#currentTradeValue'),
  tradeCardsGrid: $('#tradeCardsGrid'),
  selectedCount: $('#selectedCount'),
  cancelTradeBtn: $('#cancelTradeBtn'),
  confirmTradeBtn: $('#confirmTradeBtn'),

  gameMenuModal: $('#gameMenuModal'),
  menuLeaveBtn: $('#menuLeaveBtn'),
  menuSurrenderBtn: $('#menuSurrenderBtn'),

  gameOverModal: $('#gameOverModal'),
  winnerIcon: $('#winnerIcon'),
  winnerText: $('#winnerText'),
  winnerDetails: $('#winnerDetails'),
  gameStats: $('#gameStats'),
  returnToLobbyBtn: $('#returnToLobbyBtn'),
  startGameCard: $('#startGameCard'),
  startGameBtn: $('#startGameBtn'),
  waitingText: $('#waitingText'),
};

// ============================================================================
// Initialization
// ============================================================================

export async function initGame() {
  // Get room ID from URL
  const params = new URLSearchParams(window.location.search);
  gameState.roomId = params.get('room');
  gameState.playerName = params.get('name');
  gameState.isSpectator = params.get('spectate') === 'true';

  if (!gameState.roomId || !gameState.playerName) {
    showToast('Parámetros inválidos', 'error');
    setTimeout(() => window.location.href = '/', 2000);
    return;
  }

  // Load room info
  await loadRoomInfo();

  // Initialize chat
  initChat(gameState, events, sendWS, elements, addLogEntry);

  // Setup event listeners
  setupEventListeners();

  // Connect WebSocket
  connectWebSocket();

  // Start timer update loop
  startTimerLoop();
}

async function loadRoomInfo() {
  try {
    console.log('[loadRoomInfo] Loading room:', gameState.roomId);
    const room = await apiGet(`/rooms/${gameState.roomId}`);
    console.log('[loadRoomInfo] Room loaded:', room);
    gameState.gameId = room.game_id;
    gameState.turnTimeLimit = room.turn_time_limit || 0;
    // Find current player in room data to set playerId and isHost
    let myPlayer = room.players.find(p => p.name === gameState.playerName);
    if (myPlayer) {
      gameState.playerId = myPlayer.id;
      gameState.isHost = (myPlayer.id === room.host_id);
    }
    // Note: if I'm not in room.players yet (WS hasn't inserted me into the
    // DB), leave isHost as-is (false) — the WS state_update that follows
    // will set it correctly once the server knows about me.

    if (elements.gameRoomName) elements.gameRoomName.textContent = room.name;
    const currentNameEl = document.getElementById('currentUserName');
    if (currentNameEl && gameState.playerName) currentNameEl.textContent = gameState.playerName;
    if (elements.gameCode) elements.gameCode.textContent = `Código: ${room.code}`;

    // Update player list
    updatePlayersList(room.players, room.spectators);

    // Show waiting / start card based on room status
    console.log('[loadRoomInfo] Room status:', room.status, 'isHost:', gameState.isHost);
    if (room.status === 'waiting') {
      if (elements.startGameCard) elements.startGameCard.style.display = 'block';
      if (elements.startGameBtn) elements.startGameBtn.style.display = gameState.isHost ? 'block' : 'none';
      if (elements.waitingText) elements.waitingText.textContent = 'Esperando jugadores...';
      console.log('[loadRoomInfo] Showing waiting screen - isHost:', gameState.isHost);
    } else {
      if (elements.startGameCard) elements.startGameCard.style.display = 'none';
      console.log('[loadRoomInfo] Room started - hiding waiting screen');
    }
  } catch (error) {
    console.error('[loadRoomInfo] ERROR:', error.message);
    showToast('Error cargando la sala: ' + error.message, 'error');
    // NO REDIRECT - just show error and stay
    console.log('[loadRoomInfo] STAYING in game despite error');
  }
}

function connectWebSocket() {
  const wsUrl = `${window.WS_BASE || ''}/ws/${gameState.roomId}?name=${encodeURIComponent(gameState.playerName)}&spectate=${gameState.isSpectator}`;

  gameState.ws = createWebSocket(wsUrl, {
    onOpen: onWebSocketOpen,
    onMessage: onWebSocketMessage,
    onClose: onWebSocketClose,
    onError: onWebSocketError,
    reconnect: true,
    reconnectInterval: 3000,
    maxReconnectAttempts: 10,
  });
}

function onWebSocketOpen() {
  gameState.connected = true;
  gameState.reconnecting = false;
  console.log('WebSocket connected');

  // Join room to receive updates
  sendWS({
    event: 'join_room',
    data: {
      room_id: parseInt(gameState.roomId) || 0,
      as_spectator: false
    }
  });
}

function onWebSocketClose(event) {
  gameState.connected = false;
  console.log('WebSocket closed:', event.code, event.reason);

  if (!gameState.reconnecting) {
    showToast('Conexión perdida. Reintentando...', 'warning');
    gameState.reconnecting = true;
  }
}

function onWebSocketError(error) {
  console.error('WebSocket error:', error);
}

function onWebSocketMessage(data) {
  handleServerEvent(data);
}

function sendWS(message) {
  if (gameState.ws && gameState.connected) {
    // gameState.ws es el wrapper de createWebSocket (utils.js), cuyo
    // .send() ya hace JSON.stringify internamente — no volver a
    // stringificar acá, o se manda un string-dentro-de-un-string y el
    // servidor lo rechaza con "Expected a JSON object".
    return gameState.ws.send(message);
  }
  return false;
}

// ============================================================================
// Event Handlers
// ============================================================================

function handleServerEvent(event) {
  const type = event.event || event.type;
  const payload = event.data || event.payload;

  switch (type) {
    case 'room_update':
      handleRoomUpdate(payload);
      break;
    case 'game_started':
      handleGameStarted(payload);
      break;
    case 'state_update':
      handleStateUpdate(payload);
      break;
    case 'turn_change':
      handleTurnChange(payload);
      break;
    case 'phase_change':
      handlePhaseChange(payload);
      break;
    case 'combat_result':
      handleCombatResult(payload);
      break;
    case 'card_drawn':
      handleCardDrawn(payload);
      break;
    case 'cards_traded':
      handleCardsTraded(payload);
      break;
    case 'objective_complete':
      handleObjectiveComplete(payload);
      break;
    case 'game_over':
      handleGameOver(payload);
      break;
    case 'chat_message':
      handleChatMessage(payload);
      break;
    case 'player_eliminated':
      handlePlayerEliminated(payload);
      break;
    case 'error':
      showToast(payload.message, 'error');
      break;
    default:
      console.log('Unhandled event:', type, payload);
  }
}

function handleRoomUpdate(payload) {
  updatePlayersList(payload.players, payload.spectators);

  // Check if I'm in the player list
  const me = payload.players.find(p => p.name === gameState.playerName);
  if (me) {
    gameState.playerId = me.id;
    gameState.isHost = me.is_host;
  }

  // Show start game card for host when waiting
  const isWaiting = payload.status === 'waiting';
  if (elements.startGameCard) {
    elements.startGameCard.style.display = isWaiting ? 'block' : 'none';
  }
  if (elements.startGameBtn && isWaiting && gameState.isHost) {
    elements.startGameBtn.style.display = 'block';
  } else if (elements.startGameBtn) {
    elements.startGameBtn.style.display = 'none';
  }
}

function handleGameStarted(payload) {
  gameState.gameId = payload.game_id;

  // La partida ya arrancó: ocultar el cartel/botón de "Iniciar Partida"
  // ya mismo. Antes esto solo lo hacía handleStateUpdate, así que el
  // cartel quedaba visible (aunque la partida ya estuviera en curso)
  // hasta el próximo state_update — que en la práctica llegaba recién
  // con la primera colocación de refuerzo.
  if (elements.startGameCard) elements.startGameCard.style.display = 'none';
  if (elements.startGameBtn) elements.startGameBtn.style.display = 'none';

  gameState.countries = new Map(payload.countries.map(c => [c.id, c]));
  gameState.continents = new Map(payload.continents.map(c => [c.id, c]));
  // payload.borders llega como [{from, to}, ...] con una entrada por cada
  // dirección — agrupar en Map<countryId, countryId[]> (lista de vecinos).
  gameState.borders = new Map();
  (payload.borders || []).forEach(b => {
    if (!gameState.borders.has(b.from)) gameState.borders.set(b.from, []);
    gameState.borders.get(b.from).push(b.to);
  });
  setAdjacency(Object.fromEntries(gameState.borders));

  // Initialize board
  initializeBoard(payload);

  // Update UI
  updateMyInfo(payload.my_state);
  updatePlayersList(payload.players, payload.spectators);
  applyTurnState(payload.phase, payload.current_player_id);
  addLogEntry('system', '¡La partida ha comenzado!');

  showToast('Partida iniciada', 'success');
}

// Setea currentPlayerId/currentPhase y muestra/oculta los botones de fase
// correspondientes. Se llama tanto desde game_started/state_update (para
// que una reconexión quede sincronizada aunque no llegue un turn_change
// nuevo) como desde handleTurnChange.
function applyTurnState(phase, currentPlayerId) {
  if (phase === undefined || currentPlayerId === undefined) return;
  gameState.currentPlayerId = currentPlayerId;
  gameState.currentPhase = phase;

  const currentPlayer = gameState.players.find(p => p.id === currentPlayerId);
  if (elements.turnPlayerName) elements.turnPlayerName.textContent = currentPlayer ? currentPlayer.name : '—';

  updatePhaseUI(phase, currentPlayerId);

  const isMyTurn = currentPlayerId === gameState.playerId;
  if (isMyTurn && !gameState.isSpectator) {
    showPhaseActions(phase);
  } else {
    hidePhaseActions();
  }
}

function initializeBoard(payload) {
  // Render the SVG board
  renderBoard(payload.map_svg, gameState.countries, gameState.continents);

  // Pintar de una: colores reales por dueño + cantidad de ejércitos.
  // Antes esto no se llamaba acá, así que el tablero quedaba con el
  // relleno crudo del SVG hasta que llegara el próximo state_update.
  updateBoard(gameState.countries);

  // Hide loading, show board
  elements.boardLoading.style.display = 'none';
  elements.gameBoard.style.display = 'block';

  // Setup board interactions
  setBoardInteractive(handleCountryClick, handleCountryHover);
}

function handleStateUpdate(payload) {
  // If server sends full SVG string, inject directly
  if (payload.map_svg && typeof payload.map_svg === 'string' && payload.map_svg.length > 100) {
    const container = document.getElementById('gameBoard');
    if (container) {
      container.innerHTML = payload.map_svg;
      container.style.display = 'block';
      console.log('[handleStateUpdate] Injected SVG from server');
    }
  }

  const loadingEl = document.getElementById('boardLoading');
  if (loadingEl) loadingEl.style.display = 'none';

  // Update room info in header
  if (payload.name || payload.code) {
    const gameRoomNameEl = document.getElementById('gameRoomName');
    const gameCodeEl = document.getElementById('gameCode');
    if (gameRoomNameEl && payload.name) gameRoomNameEl.textContent = payload.name;
    if (gameCodeEl && payload.code) gameCodeEl.textContent = `Código: ${payload.code}`;
  }

  // Set player identity from my_state or find in players list
  if (payload.my_state) {
    gameState.playerId = payload.my_state.player_id;
    gameState.isHost = !!payload.my_state.is_host;
    gameState.myColor = payload.my_state.color;
  } else if (payload.players && gameState.playerName) {
    const me = payload.players.find(p => p.name === gameState.playerName);
    if (me) {
      gameState.playerId = me.id;
      gameState.isHost = !!me.is_host;
      gameState.myColor = me.color;
    }
  }

  // Show/hide start game card and button
  if (payload.status === 'waiting') {
    const startGameCard = document.getElementById('startGameCard');
    const startGameBtn = document.getElementById('startGameBtn');
    const waitingText = document.getElementById('waitingText');
    if (startGameCard) startGameCard.style.display = 'block';
    if (startGameBtn) startGameBtn.style.display = gameState.isHost ? 'block' : 'none';
    if (waitingText) waitingText.textContent = 'Esperando jugadores...';
  } else {
    const startGameCard = document.getElementById('startGameCard');
    if (startGameCard) startGameCard.style.display = 'none';
  }

  gameState.countries = new Map((payload.countries || []).map(c => [c.id, c]));
  updateBoard(gameState.countries);
  updateMyInfo(payload.my_state);
  updatePlayersList(payload.players, payload.spectators);
  if (payload.status === 'in_progress' || payload.phase) {
    // payload.borders también puede venir en un state_update de partida en
    // curso (p.ej. al reconectar); reconstruir el mapa de adyacencia igual
    // que en handleGameStarted si vino incluido.
    if (payload.borders) {
      gameState.borders = new Map();
      payload.borders.forEach(b => {
        if (!gameState.borders.has(b.from)) gameState.borders.set(b.from, []);
        gameState.borders.get(b.from).push(b.to);
      });
      setAdjacency(Object.fromEntries(gameState.borders));
    }
    if (payload.continents) {
      gameState.continents = new Map(payload.continents.map(c => [c.id, c]));
    }
    applyTurnState(payload.phase, payload.current_player_id);
  }
}

function handleTurnChange(payload) {
  gameState.phaseTimer = payload.time_remaining || 0;
  const currentPlayer = gameState.players.find(p => p.id === payload.current_player_id);

  applyTurnState(payload.phase, payload.current_player_id);

  addLogEntry('system', `Turno de ${currentPlayer?.name || '—'} (${getPhaseName(payload.phase)})`);
}

function handlePhaseChange(payload) {
  gameState.currentPhase = payload.phase;
  gameState.phaseTimer = payload.time_remaining || 0;

  updatePhaseUI(payload.phase, gameState.currentPlayerId);

  const isMyTurn = gameState.currentPlayerId === gameState.playerId;
  if (isMyTurn && !gameState.isSpectator) {
    showPhaseActions(payload.phase);
  } else {
    hidePhaseActions();
  }

  addLogEntry('system', `Fase: ${getPhaseName(payload.phase)}`);
}

function handleCombatResult(payload) {
  showDiceResult(payload);

  // Update board
  payload.countries.forEach(c => {
    gameState.countries.set(c.id, c);
  });
  updateBoard(gameState.countries);

  // Log
  const attacker = payload.attacker_country;
  const defender = payload.defender_country;
  addLogEntry('combat', `${payload.attacker_name} atacó ${defender.name} desde ${attacker.name}: ${payload.attacker_losses} vs ${payload.defender_losses} bajas`);

  if (payload.conquered) {
    addLogEntry('combat', `¡${payload.attacker_name} conquistó ${defender.name}!`);
    showToast(`¡Conquistaste ${defender.name}!`, 'success');
  }
}

function handleCardDrawn(payload) {
  gameState.myCards.push(payload.card);
  updateCardsUI();
  addLogEntry('system', `Robaste una carta: ${getCardTypeName(payload.card.type)}`);
}

function handleCardsTraded(payload) {
  // Remove traded cards
  payload.traded_card_ids.forEach(id => {
    gameState.myCards = gameState.myCards.filter(c => c.id !== id);
  });
  updateCardsUI();

  // Add reinforcement armies
  gameState.pendingReinforcements += payload.armies_received;
  updateMyInfo({ pending_reinforcements: gameState.pendingReinforcements });

  addLogEntry('trade', `Canjeaste cartas por ${payload.armies_received} ejércitos`);
  showToast(`¡Recibiste ${payload.armies_received} ejércitos!`, 'success');
}

function handleObjectiveComplete(payload) {
  addLogEntry('system', `¡${payload.player_name} completó su objetivo: ${payload.objective_description}!`);
  showToast(`${payload.player_name} completó su objetivo`, 'info');
}

function handleGameOver(payload) {
  showGameOver(payload);
}

function handleChatMessage(payload) {
  // Handled by chat.js
  events.emit('chat_message', payload);
}

function handlePlayerEliminated(payload) {
  addLogEntry('eliminated', `${payload.player_name} ha sido eliminado`);
  showToast(`${payload.player_name} fue eliminado`, 'warning');
}

// ============================================================================
// UI Updates
// ============================================================================

function updatePlayersList(players, spectators) {
  gameState.players = players || [];
  gameState.spectators = spectators || [];

  // Mantener el color del mapa sincronizado con el color real de cada
  // jugador (el mismo que se ve en la lista de jugadores).
  setPlayerColors(Object.fromEntries(gameState.players.map(p => [p.id, p.color])));

  // Players list
  if (elements.playersList) if (elements.playersList) elements.playersList.innerHTML = '';
  gameState.players.forEach(player => {
    const item = createPlayerItem(player);
    if (elements.playersList) elements.playersList.appendChild(item);
  });
  if (elements.playerCount) elements.playerCount.textContent = gameState.players.length;

  // Spectators
  if (gameState.spectators.length > 0) {
    if (elements.spectatorsCard) elements.spectatorsCard.style.display = 'block';
    if (elements.spectatorsList) elements.spectatorsList.innerHTML = '';
    gameState.spectators.forEach(spec => {
      const item = createSpectatorItem(spec);
      if (elements.spectatorsList) elements.spectatorsList.appendChild(item);
    });
    if (elements.spectatorCount) elements.spectatorCount.textContent = gameState.spectators.length;
  } else {
    if (elements.spectatorsCard) elements.spectatorsCard.style.display = 'none';
  }
}

function createPlayerItem(player) {
  const isCurrentTurn = player.id === gameState.currentPlayerId;
  const isMe = player.id === gameState.playerId;
  const isEliminated = player.eliminated;

  const item = createElement('div', {
    class: `player-item ${isCurrentTurn ? 'current-turn' : ''} ${isEliminated ? 'eliminated' : ''}`,
    style: isMe ? '' : 'cursor: pointer;',
    title: isMe ? '' : `Susurrar a ${player.name}`,
    onclick: isMe ? undefined : () => openPrivateChat(player.id, player.name),
  });

  const avatar = createElement('div', {
    class: 'player-avatar',
    style: `background: ${player.color || getPlayerColor(player.position)}`,
  }, player.name.charAt(0).toUpperCase());

  const info = createElement('div', { class: 'player-info' });
  const name = createElement('div', { class: 'player-name' }, escapeHtml(player.name));
  if (isMe) {
    const youBadge = createElement('span', { class: 'badge badge-primary', style: 'font-size: 0.6rem; margin-left: 4px;' }, 'Tú');
    name.appendChild(youBadge);
  }
  info.appendChild(name);

  const stats = createElement('div', { class: 'player-stats' });
  stats.appendChild(createElement('span', { class: 'stat' }, `${player.countries_count || 0} 🌍`));
  stats.appendChild(createElement('span', { class: 'stat' }, `${player.total_armies || 0} ⚔`));
  stats.appendChild(createElement('span', { class: 'stat' }, `${player.cards_count || 0} 🃏`));
  info.appendChild(stats);

  const badges = createElement('div', { class: 'flex gap-sm' });
  if (player.is_host) {
    badges.appendChild(createElement('span', { class: 'host-badge' }, 'Host'));
  }
  if (isEliminated) {
    badges.appendChild(createElement('span', { class: 'eliminated-badge' }, 'Eliminado'));
  }
  if (isCurrentTurn && !isEliminated) {
    badges.appendChild(createElement('span', { class: 'badge badge-primary', style: 'font-size: 0.6rem;' }, 'Turno'));
  }

  item.append(avatar, info, badges);
  return item;
}

function createSpectatorItem(spec) {
  const item = createElement('div', { class: 'spectator-item' });

  const avatar = createElement('div', {
    class: 'spectator-avatar',
    style: `background: ${getPlayerColor(Math.abs(hashCode(spec.name)) % 6)}`,
  }, spec.name.charAt(0).toUpperCase());

  const name = createElement('span', {}, escapeHtml(spec.name));

  item.append(avatar, name);
  return item;
}

function hashCode(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

function updateMyInfo(myState) {
  if (!myState) return;

  // Merge: solo pisar los campos que realmente vienen en el objeto, para
  // que llamadas parciales (p.ej. tras canjear cartas, que solo manda
  // pending_reinforcements) no borren el resto del estado ya cargado.
  if (myState.countries !== undefined) gameState.myCountries = myState.countries;
  if (myState.cards !== undefined) gameState.myCards = myState.cards;
  if (myState.pending_reinforcements !== undefined) gameState.pendingReinforcements = myState.pending_reinforcements;
  if (myState.next_trade_value !== undefined) gameState.nextTradeValue = myState.next_trade_value;

  elements.myCountries.textContent = gameState.myCountries.length;
  if (myState.total_armies !== undefined) elements.myArmies.textContent = myState.total_armies;
  elements.myCards.textContent = gameState.myCards.length;

  // Objective
  if (myState.objective && !gameState.isSpectator) {
    elements.objectiveCard.style.display = 'block';
    elements.objectiveText.textContent = myState.objective.description;
  }
}

function updatePhaseUI(phase, currentPlayerId) {
  const isMyTurn = currentPlayerId === gameState.playerId;

  elements.phaseLabel.textContent = getPhaseName(phase);
  elements.phaseLabel.style.color = getPhaseColor(phase);

  // Timer
  if (gameState.turnTimeLimit > 0) {
    elements.phaseTimer.style.display = 'flex';
    updateTimerDisplay();
  } else {
    elements.phaseTimer.style.display = 'none';
  }

  // Show/hide cards and actions
  if (isMyTurn && !gameState.isSpectator) {
    elements.cardsCard.style.display = 'block';
    elements.phaseActionsCard.style.display = 'block';
  } else {
    elements.cardsCard.style.display = 'none';
    elements.phaseActionsCard.style.display = 'none';
  }
}

function getPhaseName(phase) {
  const names = {
    waiting: 'Esperando',
    setup: 'Reparto Inicial',
    reinforce: 'Refuerzo',
    attack: 'Ataque',
    fortify: 'Reagrupar',
    trade: 'Canje',
    ended: 'Terminada',
  };
  return names[phase] || phase;
}

function getPhaseColor(phase) {
  const colors = {
    waiting: '#a0a0a0',
    setup: '#3498db',
    reinforce: '#2ecc71',
    attack: '#e74c3c',
    fortify: '#3498db',
    trade: '#d4a843',
    ended: '#9b59b6',
  };
  return colors[phase] || '#a0a0a0';
}

function updateTimerDisplay() {
  const timer = gameState.phaseTimer;
  elements.timerValue.textContent = formatTime(timer);

  elements.phaseTimer.classList.remove('warning', 'danger');
  if (timer <= 10) {
    elements.phaseTimer.classList.add('danger');
  } else if (timer <= 30) {
    elements.phaseTimer.classList.add('warning');
  }
}

function startTimerLoop() {
  setInterval(() => {
    if (gameState.phaseTimer > 0 && gameState.turnTimeLimit > 0) {
      gameState.phaseTimer--;
      updateTimerDisplay();
    }
  }, 1000);
}

function showPhaseActions(phase) {
  elements.phaseActionsContent.innerHTML = '';

  switch (phase) {
    case 'setup':
      renderSetupActions();
      break;
    case 'reinforce':
      renderReinforceActions();
      break;
    case 'attack':
      renderAttackActions();
      break;
    case 'fortify':
      renderFortifyActions();
      break;
  }
}

function hidePhaseActions() {
  elements.phaseActionsContent.innerHTML = '';
}

function renderSetupActions() {
  if (gameState.pendingReinforcements > 0) {
    const hint = createElement('div', { class: 'phase-hint' },
      `Coloca ${gameState.pendingReinforcements} ejércitos en tus países. Click en un país tuyo para añadir.`
    );
    elements.phaseActionsContent.appendChild(hint);
  } else {
    const hint = createElement('div', { class: 'phase-hint' },
      'Esperando a que todos coloquen sus ejércitos iniciales...'
    );
    elements.phaseActionsContent.appendChild(hint);
  }
}

function renderReinforceActions() {
  const hint = createElement('div', { class: 'phase-hint' },
    gameState.pendingReinforcements > 0
      ? `Tienes ${gameState.pendingReinforcements} ejércitos para colocar. Click en un país tuyo para añadir.`
      : 'Ya colocaste todos tus ejércitos. Podés terminar la fase de refuerzo.'
  );
  elements.phaseActionsContent.appendChild(hint);

  // El botón de terminar solo debe aparecer cuando YA NO quedan
  // refuerzos por colocar (el backend rechaza end_reinforce si todavía
  // hay pendientes) — antes esta condición estaba invertida y el botón
  // desaparecía justo cuando el jugador terminaba de colocar todo.
  if (gameState.pendingReinforcements === 0) {
    const btn = createElement('button', {
      class: 'phase-action-btn primary',
      onclick: () => sendWS({ event: 'end_reinforce', data: {} }),
    }, 'Terminar Refuerzo');
    elements.phaseActionsContent.appendChild(btn);
  }
}

function renderAttackActions() {
  const hint = createElement('div', { class: 'phase-hint' },
    'Selecciona un país tuyo con 2+ ejércitos, luego un país enemigo adyacente para atacar.'
  );
  elements.phaseActionsContent.appendChild(hint);

  const btn = createElement('button', {
    class: 'phase-action-btn danger',
    onclick: () => sendWS({ type: 'end_attack' }),
  }, 'Terminar Ataque');
  elements.phaseActionsContent.appendChild(btn);
}

function renderFortifyActions() {
  const hint = createElement('div', { class: 'phase-hint' },
    'Selecciona un país origen y uno destino (conectados por tus territorios) para mover ejércitos.'
  );
  elements.phaseActionsContent.appendChild(hint);

  const btn = createElement('button', {
    class: 'phase-action-btn',
    onclick: () => sendWS({ type: 'end_fortify' }),
  }, 'Terminar Turno');
  elements.phaseActionsContent.appendChild(btn);
}

function updateCardsUI() {
  elements.cardCount.textContent = gameState.myCards.length;
  elements.tradeValue.textContent = `Siguiente: ${gameState.nextTradeValue || 5}`;

  elements.cardsGrid.innerHTML = '';
  gameState.myCards.forEach(card => {
    const cardEl = createCardElement(card);
    elements.cardsGrid.appendChild(cardEl);
  });

  updateTradeButton();
}

function createCardElement(card) {
  const isWild = card.type === 'wild';
  const selected = gameState.selectedCards.has(card.id);

  const el = createElement('div', {
    class: `teg-card-mini ${selected ? 'selected' : ''}`,
    onclick: () => toggleCardSelection(card.id),
  });

  const iconMap = {
    infantry: '👣',
    cavalry: '🐎',
    artillery: '💣',
    wild: '⭐',
  };

  el.innerHTML = `
    <div class="card-icon">${iconMap[card.type] || '?'}</div>
    <div class="card-type">${getCardTypeName(card.type)}</div>
  `;

  return el;
}

function getCardTypeName(type) {
  const names = {
    infantry: 'Infantería',
    cavalry: 'Caballería',
    artillery: 'Artillería',
    wild: 'Comodín',
  };
  return names[type] || type;
}

function toggleCardSelection(cardId) {
  if (gameState.selectedCards.has(cardId)) {
    gameState.selectedCards.delete(cardId);
  } else if (gameState.selectedCards.size < 3) {
    gameState.selectedCards.add(cardId);
  }
  updateCardsUI();
  updateTradeButton();
}

function updateTradeButton() {
  const count = gameState.selectedCards.size;
  elements.tradeBtnText.textContent = `Canjear (${count}/3)`;
  elements.tradeCardsBtn.disabled = count !== 3;
}

function showDiceResult(payload) {
  elements.diceCard.classList.remove('hidden');

  const attackerDice = payload.attacker_dice || [];
  const defenderDice = payload.defender_dice || [];

  const renderDiceRow = (values, side) =>
    values.map((d, i) => `<div class="die ${side} rolling" data-final="${d}" data-idx="${i}">?</div>`).join('');

  elements.diceResult.innerHTML = `
    <div class="dice-roll">
      <span class="dice-roll-label">Atacante:</span>
      <div class="dice-values" id="diceRowAttacker">${renderDiceRow(attackerDice, 'attacker')}</div>
    </div>
    <div class="dice-roll">
      <span class="dice-roll-label">Defensor:</span>
      <div class="dice-values" id="diceRowDefender">${renderDiceRow(defenderDice, 'defender')}</div>
    </div>
    <div class="dice-outcome" id="diceOutcomeText"></div>
  `;

  // Animación: los dados "giran" mostrando valores al azar un rato antes
  // de asentarse en el resultado real que ya vino del servidor — el
  // resultado no depende de la animación, es puramente visual.
  const allDice = elements.diceResult.querySelectorAll('.die.rolling');
  const rollInterval = setInterval(() => {
    allDice.forEach(die => {
      die.textContent = String(1 + Math.floor(Math.random() * 6));
    });
  }, 80);

  setTimeout(() => {
    clearInterval(rollInterval);
    allDice.forEach(die => {
      die.textContent = die.dataset.final;
      die.classList.remove('rolling');
      die.classList.add('settled');
    });
    const outcomeEl = document.getElementById('diceOutcomeText');
    if (outcomeEl) {
      outcomeEl.textContent =
        `${payload.attacker_name} pierde ${payload.attacker_losses} | ${payload.defender_name} pierde ${payload.defender_losses}`;
    }
  }, 700);

  // Auto-hide after 3.5 seconds (700ms de animación + tiempo de lectura)
  setTimeout(() => {
    elements.diceCard.classList.add('hidden');
  }, 3500);
}

function addLogEntry(type, message) {
  const entry = createElement('div', { class: `log-entry ${type}` });
  const time = new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  entry.innerHTML = `
    <span class="log-time">[${time}]</span>
    <span class="log-message">${escapeHtml(message)}</span>
  `;

  elements.gameLog.insertBefore(entry, elements.gameLog.firstChild);

  // Limit log entries
  while (elements.gameLog.children.length > 100) {
    elements.gameLog.lastChild.remove();
  }
}

// ============================================================================
// Board Interactions
// ============================================================================

function handleCountryClick(countryId) {
  const country = gameState.countries.get(countryId);
  if (!country) return;

  const isMyCountry = country.owner_id === gameState.playerId;
  const isMyTurn = gameState.currentPlayerId === gameState.playerId;
  const phase = gameState.currentPhase;

  if (gameState.isSpectator) return;
  if (!isMyTurn) return;

  switch (phase) {
    case 'setup':
    case 'reinforce':
      if (isMyCountry && gameState.pendingReinforcements > 0) {
        placeArmies(countryId, 1);
      }
      break;

    case 'attack':
      handleAttackClick(countryId, isMyCountry);
      break;

    case 'fortify':
      handleFortifyClick(countryId, isMyCountry);
      break;
  }
}

let hoverTooltipTimeout = null;
let hoverTooltipEl = null;

function ensureHoverTooltip() {
  if (!hoverTooltipEl) {
    hoverTooltipEl = document.createElement('div');
    hoverTooltipEl.className = 'country-armies-tooltip hidden';
    document.body.appendChild(hoverTooltipEl);
  }
  return hoverTooltipEl;
}

function handleCountryHover(countryId, isHover, clientX, clientY) {
  const tooltip = ensureHoverTooltip();

  if (!isHover || countryId == null) {
    clearTimeout(hoverTooltipTimeout);
    hoverTooltipTimeout = null;
    tooltip.classList.add('hidden');
    tooltip.dataset.countryId = '';
    return;
  }

  // Se pidió que los ejércitos se vean "pasando el mouse por un par de
  // segundos" — se arranca el delay recién cuando el mouse entra a un país
  // nuevo, y se cancela si se va antes de que se cumpla.
  if (tooltip.dataset.countryId !== String(countryId)) {
    clearTimeout(hoverTooltipTimeout);
    tooltip.classList.add('hidden');
    tooltip.dataset.countryId = String(countryId);

    hoverTooltipTimeout = setTimeout(() => {
      const country = gameState.countries.get(countryId);
      if (!country) return;
      const owner = gameState.players.find(p => p.id === country.owner_id);
      tooltip.innerHTML = `
        <div class="tooltip-country-name">${escapeHtml(country.name)}</div>
        <div class="tooltip-armies">🎖️ ${country.armies} ejércitos</div>
        <div class="tooltip-owner">${owner ? escapeHtml(owner.name) : 'Sin dueño'}</div>
      `;
      tooltip.classList.remove('hidden');
    }, 1500);
  }

  if (typeof clientX === 'number' && typeof clientY === 'number') {
    tooltip.style.left = `${clientX + 16}px`;
    tooltip.style.top = `${clientY + 16}px`;
  }
}

function placeArmies(countryId, amount) {
  sendWS({
    type: 'place_armies',
    payload: { country_id: countryId, amount },
  });
  gameState.pendingReinforcements -= amount;
  updateMyInfo({ pending_reinforcements: gameState.pendingReinforcements });
}

function handleAttackClick(countryId, isMyCountry) {
  if (!gameState.attackFrom) {
    // Select attacker
    if (isMyCountry) {
      const country = gameState.countries.get(countryId);
      if (country && country.armies >= 2) {
        gameState.attackFrom = countryId;
        highlightValidTargets(countryId, 'attack');
        updateBoard(gameState.countries);
      } else {
        showToast('Necesitas al menos 2 ejércitos para atacar', 'warning');
      }
    }
  } else {
    // Select defender
    const fromCountry = gameState.countries.get(gameState.attackFrom);
    const toCountry = gameState.countries.get(countryId);

    if (fromCountry && toCountry && fromCountry.owner_id !== toCountry.owner_id) {
      // Check if adjacent
      const borders = gameState.borders.get(gameState.attackFrom) || [];
      if (borders.includes(countryId)) {
        openCombatModal(gameState.attackFrom, countryId);
      } else {
        showToast('Los países no son adyacentes', 'warning');
      }
    }
    clearHighlights();
    gameState.attackFrom = null;
  }
}

function handleFortifyClick(countryId, isMyCountry) {
  if (!gameState.fortifyFrom) {
    if (isMyCountry) {
      const country = gameState.countries.get(countryId);
      if (country && country.armies >= 2) {
        gameState.fortifyFrom = countryId;
        highlightValidTargets(countryId, 'fortify');
        updateBoard(gameState.countries);
      } else {
        showToast('Necesitas al menos 2 ejércitos para reagrupar', 'warning');
      }
    }
  } else {
    if (countryId === gameState.fortifyFrom) {
      clearHighlights();
      gameState.fortifyFrom = null;
      return;
    }

    const fromCountry = gameState.countries.get(gameState.fortifyFrom);
    const toCountry = gameState.countries.get(countryId);

    if (fromCountry && toCountry && fromCountry.owner_id === toCountry.owner_id) {
      // Check if connected through owned territories
      if (areConnected(gameState.fortifyFrom, countryId)) {
        openFortifyModal(gameState.fortifyFrom, countryId);
      } else {
        showToast('Los países no están conectados por tus territorios', 'warning');
      }
    }
    clearHighlights();
    gameState.fortifyFrom = null;
  }
}

function areConnected(fromId, toId) {
  // BFS through owned territories
  const visited = new Set();
  const queue = [fromId];
  const myId = gameState.playerId;

  while (queue.length > 0) {
    const current = queue.shift();
    if (current === toId) return true;
    if (visited.has(current)) continue;
    visited.add(current);

    const borders = gameState.borders.get(current) || [];
    for (const neighbor of borders) {
      const neighborCountry = gameState.countries.get(neighbor);
      if (neighborCountry && neighborCountry.owner_id === myId && !visited.has(neighbor)) {
        queue.push(neighbor);
      }
    }
  }
  return false;
}

function highlightValidTargets(countryId, type) {
  const country = gameState.countries.get(countryId);
  if (!country) return;

  const myId = gameState.playerId;

  if (type === 'attack') {
    // Adjacent enemy countries
    const borders = gameState.borders.get(countryId) || [];
    borders.forEach(neighborId => {
      const neighbor = gameState.countries.get(neighborId);
      if (neighbor && neighbor.owner_id !== myId) {
        neighbor._highlight = 'attack';
      }
    });
  } else if (type === 'fortify') {
    // All connected own countries
    const visited = new Set();
    const queue = [countryId];

    while (queue.length > 0) {
      const current = queue.shift();
      if (visited.has(current)) continue;
      visited.add(current);

      const currentCountry = gameState.countries.get(current);
      if (currentCountry && currentCountry.owner_id === myId) {
        if (current !== countryId) {
          currentCountry._highlight = 'fortify';
        }
        const borders = gameState.borders.get(current) || [];
        borders.forEach(n => queue.push(n));
      }
    }
  }

  updateBoard(gameState.countries);
}

function clearHighlights() {
  gameState.countries.forEach(c => {
    delete c._highlight;
  });
  updateBoard(gameState.countries);
}

// ============================================================================
// Modals
// ============================================================================

function openCombatModal(attackerId, defenderId) {
  const attacker = gameState.countries.get(attackerId);
  const defender = gameState.countries.get(defenderId);

  elements.attackerTerritory.textContent = `${attacker.name} (${attacker.armies} ejércitos)`;
  elements.defenderTerritory.textContent = `${defender.name} (${defender.armies} ejércitos)`;
  elements.attackerArmies.textContent = attacker.armies - 1; // Max dice = armies - 1
  elements.defenderArmies.textContent = Math.min(2, defender.armies);

  // Setup dice buttons
  setupDiceButtons(elements.attackerDiceBtns, Math.min(3, attacker.armies - 1), 'attacker');
  setupDiceButtons(elements.defenderDiceBtns, Math.min(2, defender.armies), 'defender');

  // Store for confirmation
  elements.combatModal.dataset.attackerId = attackerId;
  elements.combatModal.dataset.defenderId = defenderId;

  showModal('combatModal');
}

function setupDiceButtons(container, maxDice, prefix) {
  container.innerHTML = '';
  for (let i = 1; i <= maxDice; i++) {
    const btn = createElement('button', {
      class: 'dice-btn' + (i === maxDice ? ' active' : ''),
      'data-dice': i,
      onclick: (e) => selectDice(e.target, prefix),
    }, i);
    container.appendChild(btn);
  }
  // Set hidden input
  const input = prefix === 'attacker' ? elements.attackerDiceCount : elements.defenderDiceCount;
  input.value = maxDice;
}

function selectDice(btn, prefix) {
  const container = prefix === 'attacker' ? elements.attackerDiceBtns : elements.defenderDiceBtns;
  const input = prefix === 'attacker' ? elements.attackerDiceCount : elements.defenderDiceCount;

  container.querySelectorAll('.dice-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  input.value = btn.dataset.dice;
}

function openFortifyModal(fromId, toId) {
  const from = gameState.countries.get(fromId);
  const to = gameState.countries.get(toId);

  elements.fortifyFromDisplay.textContent = `${from.name} (${from.armies} ejércitos)`;
  elements.fortifyToDisplay.textContent = to.name;

  // Max armies to move = from.armies - 1
  const maxMove = from.armies - 1;
  elements.fortifyArmiesInput.max = maxMove;
  elements.fortifyArmiesInput.value = maxMove;
  elements.fortifyArmiesSlider.max = maxMove;
  elements.fortifyArmiesSlider.value = maxMove;

  elements.fortifyModal.dataset.fromId = fromId;
  elements.fortifyModal.dataset.toId = toId;

  showModal('fortifyModal');
}

function openTradeModal() {
  elements.currentTradeValue.textContent = gameState.nextTradeValue || 5;
  elements.tradeCardsGrid.innerHTML = '';

  gameState.myCards.forEach(card => {
    const cardEl = createElement('div', {
      class: `teg-card-mini ${gameState.selectedCards.has(card.id) ? 'selected' : ''}`,
      onclick: () => toggleTradeCardSelection(card.id),
    });
    cardEl.innerHTML = createCardElement(card).innerHTML;
    elements.tradeCardsGrid.appendChild(cardEl);
  });

  showModal('tradeModal');
}

function toggleTradeCardSelection(cardId) {
  if (gameState.selectedCards.has(cardId)) {
    gameState.selectedCards.delete(cardId);
  } else if (gameState.selectedCards.size < 3) {
    gameState.selectedCards.add(cardId);
  }
  elements.selectedCount.textContent = gameState.selectedCards.size;
  elements.confirmTradeBtn.disabled = gameState.selectedCards.size !== 3;

  // Update visual
  elements.tradeCardsGrid.querySelectorAll('.teg-card-mini').forEach((el, i) => {
    const card = gameState.myCards[i];
    if (card && gameState.selectedCards.has(card.id)) {
      el.classList.add('selected');
    } else {
      el.classList.remove('selected');
    }
  });
}

function showGameOver(payload) {
  const winnerName = payload.winner_name;
  elements.winnerText.textContent = winnerName ? `¡${winnerName} ha ganado!` : 'Partida finalizada';
  elements.winnerDetails.textContent = winnerName ? 'Último jugador en pie' : '';

  // Stats — el backend manda "players" (no "final_ranking") con
  // countries_count/total_armies/cards_count (no "countries").
  elements.gameStats.innerHTML = '';
  const ranking = [...(payload.players || [])].sort(
    (a, b) => (b.countries_count || 0) - (a.countries_count || 0)
  );
  ranking.forEach((player, index) => {
    const stat = createElement('div', { class: 'game-stat' });
    stat.innerHTML = `
      <span class="game-stat-label">${index + 1}º ${escapeHtml(player.name)}${player.id === payload.winner_id ? ' 👑' : ''}</span>
      <span class="game-stat-value">${player.countries_count || 0} países</span>
    `;
    elements.gameStats.appendChild(stat);
  });

  showModal('gameOverModal');
}

// ============================================================================
// Event Listeners
// ============================================================================

function setupEventListeners() {
  // Header
  elements.chatToggleBtn?.addEventListener('click', () => events.emit('toggle_chat'));
  elements.menuBtn?.addEventListener('click', () => showModal('gameMenuModal'));
  elements.changeNameBtn?.addEventListener('click', () => {
    const newName = prompt('Ingresá tu nuevo nombre:');
    if (newName && newName.trim()) {
      gameState.playerName = newName.trim();
      localStorage.setItem('playerName', gameState.playerName);
      const currentEl = document.getElementById('currentUserName');
      if (currentEl) currentEl.textContent = gameState.playerName;
      // Reconnect with new identity
      if (gameState.ws) gameState.ws.close();
      setTimeout(() => connectWebSocket(), 500);
    }
  });

  // Board controls
  elements.zoomInBtn?.addEventListener('click', () => zoomTo(gameState.zoomLevel * 1.2));
  elements.zoomOutBtn?.addEventListener('click', () => zoomTo(gameState.zoomLevel / 1.2));
  elements.resetViewBtn?.addEventListener('click', () => resetView());

  // Combat modal
  elements.cancelCombatBtn?.addEventListener('click', () => hideModal('combatModal'));
  elements.confirmCombatBtn?.addEventListener('click', confirmCombat);

  // Fortify modal
  elements.cancelFortifyBtn?.addEventListener('click', () => hideModal('fortifyModal'));
  elements.confirmFortifyBtn?.addEventListener('click', confirmFortify);

  // Trade modal
  elements.cancelTradeBtn?.addEventListener('click', () => hideModal('tradeModal'));
  elements.confirmTradeBtn?.addEventListener('click', confirmTrade);

  // Game menu
  elements.menuLeaveBtn?.addEventListener('click', leaveGame);
  elements.menuSurrenderBtn?.addEventListener('click', surrender);
  elements.closeGameMenuBtn?.addEventListener('click', () => hideModal('gameMenuModal'));

  // Game over
  elements.returnToLobbyBtn?.addEventListener('click', () => window.location.href = '/');

  // Start game (host only in waiting phase)
  elements.startGameBtn?.addEventListener('click', () => {
    if (gameState.connected) {
      sendWS({ event: 'start_game', data: { room_id: parseInt(gameState.roomId) } });
    }
  });

  // Clear log
  elements.clearLogBtn?.addEventListener('click', () => {
    elements.gameLog.innerHTML = '';
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      // Close modals
      document.querySelectorAll('.modal-overlay:not(.hidden)').forEach(m => m.classList.add('hidden'));
      // Clear selections
      clearHighlights();
      gameState.attackFrom = null;
      gameState.fortifyFrom = null;
    }
  });
}

function confirmCombat() {
  const attackerId = elements.combatModal.dataset.attackerId;
  const defenderId = elements.combatModal.dataset.defenderId;
  const attackerDice = parseInt(elements.attackerDiceCount.value);
  const defenderDice = parseInt(elements.defenderDiceCount.value);

  sendWS({
    type: 'attack',
    payload: {
      from_country_id: attackerId,
      to_country_id: defenderId,
      attacker_dice: attackerDice,
      defender_dice: defenderDice,
    },
  });

  hideModal('combatModal');
}

function confirmFortify() {
  const fromId = elements.fortifyModal.dataset.fromId;
  const toId = elements.fortifyModal.dataset.toId;
  const amount = parseInt(elements.fortifyArmiesInput.value);

  sendWS({
    type: 'fortify',
    payload: {
      from_country_id: fromId,
      to_country_id: toId,
      amount,
    },
  });

  hideModal('fortifyModal');
}

function confirmTrade() {
  const cardIds = Array.from(gameState.selectedCards);

  sendWS({
    type: 'trade_cards',
    payload: { card_ids: cardIds },
  });

  gameState.selectedCards.clear();
  updateTradeButton();
  hideModal('tradeModal');
}

function leaveGame() {
  sendWS({ type: 'leave_game' });
  hideModal('gameMenuModal');
  window.location.href = '/';
}

function surrender() {
  if (confirm('¿Estás seguro de que quieres rendirte?')) {
    sendWS({ type: 'surrender' });
    hideModal('gameMenuModal');
  }
}

// ============================================================================
// Modal Helpers (re-export from utils)
// ============================================================================

function showModal(modalId) {
  const modal = $(modalId);
  if (modal) {
    modal.classList.remove('hidden');
  }
}

function hideModal(modalId) {
  const modal = $(modalId);
  if (modal) {
    modal.classList.add('hidden');
  }
}

// Export for chat module
export { gameState, events, sendWS, elements, showToast, addLogEntry };