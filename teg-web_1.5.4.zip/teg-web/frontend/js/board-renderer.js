/**
 * TEG Web - Board Renderer
 * Handles SVG map rendering, interactions, zoom/pan
 */

import { $, createElement } from './utils.js?v=111';

// ============================================================================
// Board State
// ============================================================================

const boardState = {
  svg: null,
  countriesGroup: null,
  labelsGroup: null,
  armiesGroup: null,
  continentsGroup: null,

  // Transform
  scale: 1,
  translateX: 0,
  translateY: 0,
  minScale: 0.3,
  maxScale: 4,

  // Interaction
  isPanning: false,
  lastPanX: 0,
  lastPanY: 0,
  clickCountryCallback: null,
  hoverCountryCallback: null,

  // Data
  countries: new Map(),
  continents: new Map(),
  // id_usuario -> color real asignado por el backend (Usuarios.color).
  // Se usa en vez del hash de getPlayerColorForId cuando está disponible,
  // para que el color en el mapa coincida con el de la lista de jugadores.
  playerColors: {},
  // country_id -> [country_id, ...] vecinos según las reglas del juego
  // (viene de payload.borders — no necesariamente coincide con "tocarse"
  // visualmente en el mapa, así que las fronteras se dibujan como líneas
  // conectoras bajo demanda, no como bordes compartidos fijos).
  adjacency: {},
  bordersGroup: null,
};

// Recibe el mapa de adyacencia real del juego (country_id -> [vecinos]),
// para poder dibujar las líneas de frontera al pasar el mouse/seleccionar.
export function setAdjacency(adjacencyMap) {
  boardState.adjacency = adjacencyMap || {};
}

// Recibe el color real de cada jugador (llamar cada vez que se actualiza
// la lista de jugadores, p.ej. desde updatePlayersList en game.js).
export function setPlayerColors(colorsByPlayerId) {
  boardState.playerColors = colorsByPlayerId || {};
}

// ============================================================================
// Public API
// ============================================================================

export function renderBoard(mapSvg, countries, continents) {
  const container = $('#gameBoard');
  if (!container) return;

  // Parse and inject SVG
  container.innerHTML = mapSvg;
  boardState.svg = container;

  // Store data
  boardState.countries = countries;
  boardState.continents = continents;

  // Get or create groups
  boardState.countriesGroup = $('#countries') || createGroup('countries');
  boardState.labelsGroup = $('#labels') || createGroup('labels');
  boardState.armiesGroup = $('#armies') || createGroup('armies');
  boardState.continentsGroup = $('#continents') || createGroup('continents');
  boardState.bordersGroup = $('#borders') || createGroup('borders');

  // Ensure groups are in correct order
  const groupsOrder = ['continents', 'countries', 'armies', 'labels'];
  groupsOrder.forEach((id, index) => {
    const group = $(id);
    if (group) {
      group.style.vectorEffect = 'non-scaling-stroke';
    }
  });

  // Setup interaction
  setupInteraction();

  // Initial view
  resetView();
}

function createGroup(id) {
  const group = createElementNS('g', { id });
  boardState.svg.appendChild(group);
  return group;
}

function createElementNS(tag, attrs = {}) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(attrs).forEach(([key, value]) => {
    if (key === 'class') {
      el.className.baseVal = value;
    } else {
      el.setAttribute(key, value);
    }
  });
  return el;
}

export function updateBoard(countries) {
  boardState.countries = countries;
  renderCountries();
  renderArmies();
  renderLabels();
}

export function setBoardInteractive(onClick, onHover) {
  boardState.clickCountryCallback = onClick;
  boardState.hoverCountryCallback = onHover;
}

export function panTo(x, y) {
  boardState.translateX = x;
  boardState.translateY = y;
  applyTransform();
}

export function zoomTo(scale) {
  scale = Math.max(boardState.minScale, Math.min(boardState.maxScale, scale));
  boardState.scale = scale;
  applyTransform();
  updateZoomDisplay();
}

export function resetView() {
  boardState.scale = 1;
  boardState.translateX = 0;
  boardState.translateY = 0;
  applyTransform();
  updateZoomDisplay();
}

export function getTransform() {
  return { scale: boardState.scale, x: boardState.translateX, y: boardState.translateY };
}

// ============================================================================
// Rendering
// ============================================================================

function renderCountries() {
  if (!boardState.countriesGroup) return;

  boardState.countries.forEach(country => {
    const path = $(`country-${country.id}`);
    if (path) {
      // Update classes based on state
      updateCountryPath(path, country);
    }
  });
}

function updateCountryPath(path, country) {
  // Owner color: usar el color real asignado al jugador (viene de
  // Usuarios.color en el backend) si lo tenemos; si no, un hash como
  // respaldo, para que nunca queden todos los países del mismo color.
  const ownerColor = country.owner_id
    ? (boardState.playerColors[country.owner_id] || getPlayerColorForId(country.owner_id))
    : '#3d3d3d';

  path.style.fill = ownerColor;
  path.style.stroke = '#1a1a1a';
  path.style.strokeWidth = '1.5';

  // Highlight classes
  path.classList.remove('selected', 'valid-target', 'enemy', 'neutral');
  if (country._highlight === 'attack') {
    path.classList.add('valid-target', 'attack');
  } else if (country._highlight === 'fortify') {
    path.classList.add('valid-target', 'fortify');
  } else if (country.owner_id === boardState.myPlayerId) {
    path.classList.add('selected');
  } else if (country.owner_id && country.owner_id !== boardState.myPlayerId) {
    path.classList.add('enemy');
  } else {
    path.classList.add('neutral');
  }
}

function renderArmies() {
  if (!boardState.armiesGroup) return;

  // Clear existing
  boardState.armiesGroup.innerHTML = '';

  boardState.countries.forEach(country => {
    if (country.armies > 0) {
      const centroid = getCountryCentroid(country.id);
      if (centroid) {
        const text = createElementNS('text', {
          class: 'army-count',
          x: centroid.x,
          y: centroid.y,
          'text-anchor': 'middle',
          'dominant-baseline': 'central',
          'font-size': '12px',
          'font-weight': '700',
          fill: '#1a1a1a',
          'paint-order': 'stroke',
          'stroke': 'white',
          'stroke-width': '3px',
        }, country.armies.toString());
        boardState.armiesGroup.appendChild(text);
      }
    }
  });
}

function renderLabels() {
  if (!boardState.labelsGroup) return;

  // Clear existing
  boardState.labelsGroup.innerHTML = '';

  boardState.countries.forEach(country => {
    const centroid = getCountryCentroid(country.id);
    if (centroid && country.name.length < 15) {
      const text = createElementNS('text', {
        class: 'country-name',
        x: centroid.x,
        y: centroid.y + 18,
        'text-anchor': 'middle',
        'dominant-baseline': 'central',
        'font-size': '9px',
        'font-weight': '600',
        fill: '#f5f5f5',
        'paint-order': 'stroke',
        'stroke': '#1a1a1a',
        'stroke-width': '2px',
      }, country.name);
      boardState.labelsGroup.appendChild(text);
    }
  });
}

function getCountryCentroid(countryId) {
  const path = $(`country-${countryId}`);
  if (!path) return null;

  try {
    const bbox = path.getBBox();
    return { x: bbox.x + bbox.width / 2, y: bbox.y + bbox.height / 2 };
  } catch (e) {
    return null;
  }
}

// ============================================================================
// Interaction
// ============================================================================

function setupInteraction() {
  if (!boardState.svg) return;

  // Wheel zoom
  boardState.svg.addEventListener('wheel', handleWheel, { passive: false });

  // Mouse pan
  boardState.svg.addEventListener('mousedown', handleMouseDown);
  window.addEventListener('mousemove', handleMouseMove);
  window.addEventListener('mouseup', handleMouseUp);

  // Touch pan/zoom
  boardState.svg.addEventListener('touchstart', handleTouchStart, { passive: false });
  boardState.svg.addEventListener('touchmove', handleTouchMove, { passive: false });
  boardState.svg.addEventListener('touchend', handleTouchEnd);

  // Click on countries
  boardState.svg.addEventListener('click', handleClick);

  // Hover
  boardState.svg.addEventListener('mousemove', handleHover);
}

function handleWheel(e) {
  e.preventDefault();

  const rect = boardState.svg.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;

  // Convert to SVG coordinates
  const svgPoint = screenToSvg(mouseX, mouseY);

  const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
  const newScale = Math.max(boardState.minScale, Math.min(boardState.maxScale, boardState.scale * zoomFactor));

  // Zoom towards mouse position
  boardState.translateX = svgPoint.x - (svgPoint.x - boardState.translateX) * (newScale / boardState.scale);
  boardState.translateY = svgPoint.y - (svgPoint.y - boardState.translateY) * (newScale / boardState.scale);
  boardState.scale = newScale;

  applyTransform();
  updateZoomDisplay();
}

function handleMouseDown(e) {
  if (e.button !== 0) return; // Only left click
  if (e.target.closest('.country')) return; // Don't pan when clicking country

  boardState.isPanning = true;
  boardState.lastPanX = e.clientX;
  boardState.lastPanY = e.clientY;
  boardState.svg.style.cursor = 'grabbing';
}

function handleMouseMove(e) {
  if (!boardState.isPanning) return;

  const dx = e.clientX - boardState.lastPanX;
  const dy = e.clientY - boardState.lastPanY;

  boardState.translateX += dx / boardState.scale;
  boardState.translateY += dy / boardState.scale;

  boardState.lastPanX = e.clientX;
  boardState.lastPanY = e.clientY;

  applyTransform();
}

function handleMouseUp() {
  boardState.isPanning = false;
  boardState.svg.style.cursor = 'grab';
}

function handleTouchStart(e) {
  if (e.touches.length === 1) {
    // Pan
    boardState.isPanning = true;
    boardState.lastPanX = e.touches[0].clientX;
    boardState.lastPanY = e.touches[0].clientY;
  } else if (e.touches.length === 2) {
    // Pinch zoom - store initial distance
    boardState.initialPinchDist = getPinchDistance(e.touches[0], e.touches[1]);
    boardState.initialScale = boardState.scale;
    boardState.isPanning = false;
  }
}

function handleTouchMove(e) {
  e.preventDefault();

  if (e.touches.length === 1 && boardState.isPanning) {
    const dx = e.touches[0].clientX - boardState.lastPanX;
    const dy = e.touches[0].clientY - boardState.lastPanY;

    boardState.translateX += dx / boardState.scale;
    boardState.translateY += dy / boardState.scale;

    boardState.lastPanX = e.touches[0].clientX;
    boardState.lastPanY = e.touches[0].clientY;

    applyTransform();
  } else if (e.touches.length === 2 && boardState.initialPinchDist) {
    const currentDist = getPinchDistance(e.touches[0], e.touches[1]);
    const scale = boardState.initialScale * (currentDist / boardState.initialPinchDist);
    zoomTo(scale);
  }
}

function handleTouchEnd(e) {
  boardState.isPanning = false;
  boardState.initialPinchDist = null;
}

function getPinchDistance(touch1, touch2) {
  const dx = touch1.clientX - touch2.clientX;
  const dy = touch1.clientY - touch2.clientY;
  return Math.sqrt(dx * dx + dy * dy);
}

function handleClick(e) {
  const countryPath = e.target.closest('.country');
  if (countryPath && boardState.clickCountryCallback) {
    const countryId = Number(countryPath.dataset.countryId);
    if (countryId) {
      showBordersFor(countryId);
      boardState.clickCountryCallback(countryId);
    }
  }
}

function handleHover(e) {
  const countryPath = e.target.closest('.country');
  if (countryPath && boardState.hoverCountryCallback) {
    const countryId = Number(countryPath.dataset.countryId);
    if (countryId) {
      showBordersFor(countryId);
      boardState.hoverCountryCallback(countryId, true, e.clientX, e.clientY);
    }
  } else if (boardState.hoverCountryCallback) {
    clearBorderHighlight();
    boardState.hoverCountryCallback(null, false, e.clientX, e.clientY);
  }
}

// Dibuja líneas conectoras (al estilo TEG clásico, para pasos no
// contiguos como Alaska-Kamchatka) entre el país indicado y sus vecinos
// reales de juego, y resalta esos vecinos. Se llama al pasar el mouse o
// al hacer click sobre un país — no se dibuja todo el grafo de una,
// porque con conexiones entre continentes quedaría un enredo ilegible.
function showBordersFor(countryId) {
  if (!boardState.bordersGroup) return;
  clearBorderHighlight();

  const neighbors = boardState.adjacency[countryId] || [];
  const fromCentroid = getCountryCentroid(countryId);
  if (!fromCentroid) return;

  neighbors.forEach(neighborId => {
    const toCentroid = getCountryCentroid(neighborId);
    if (!toCentroid) return;

    const line = createElementNS('line', {
      x1: fromCentroid.x, y1: fromCentroid.y,
      x2: toCentroid.x, y2: toCentroid.y,
      class: 'border-preview-line',
    });
    boardState.bordersGroup.appendChild(line);

    const neighborPath = $(`country-${neighborId}`);
    if (neighborPath) neighborPath.classList.add('border-preview-neighbor');
  });

  const originPath = $(`country-${countryId}`);
  if (originPath) originPath.classList.add('border-preview-origin');
}

function clearBorderHighlight() {
  if (boardState.bordersGroup) boardState.bordersGroup.innerHTML = '';
  document.querySelectorAll('.border-preview-neighbor').forEach(el => el.classList.remove('border-preview-neighbor'));
  document.querySelectorAll('.border-preview-origin').forEach(el => el.classList.remove('border-preview-origin'));
}

// ============================================================================
// Helpers
// ============================================================================

function applyTransform() {
  if (!boardState.svg) return;

  const transform = `translate(${boardState.translateX} ${boardState.translateY}) scale(${boardState.scale})`;
  boardState.svg.style.transform = transform;
  boardState.svg.style.transformOrigin = '0 0';
}

function updateZoomDisplay() {
  const zoomEl = $('#zoomLevel');
  if (zoomEl) {
    zoomEl.textContent = `${Math.round(boardState.scale * 100)}%`;
  }
}

function screenToSvg(screenX, screenY) {
  const svg = boardState.svg;
  const pt = svg.createSVGPoint();
  pt.x = screenX;
  pt.y = screenY;
  const transformed = pt.matrixTransform(svg.getScreenCTM().inverse());
  return { x: transformed.x, y: transformed.y };
}

function getPlayerColorForId(playerId) {
  // Respaldo por si un país no tiene color real asignado todavía (no
  // debería pasar en juego normal, pero evita que todo salga del mismo
  // color si playerColors no llegó a cargarse a tiempo).
  const colors = [
    '#e74c3c', // Red
    '#3498db', // Blue
    '#2ecc71', // Green
    '#f1c40f', // Yellow
    '#e67e22', // Orange
    '#9b59b6', // Purple
  ];
  // playerId llega como número desde el backend — convertir a string
  // antes de usar .length/.charCodeAt (si no, el loop nunca corre y
  // siempre devuelve colors[0] para TODOS los jugadores).
  const idStr = String(playerId);
  let hash = 0;
  for (let i = 0; i < idStr.length; i++) {
    hash = ((hash << 5) - hash) + idStr.charCodeAt(i);
    hash |= 0;
  }
  return colors[Math.abs(hash) % colors.length];
}

// Store myPlayerId for highlighting
export function setMyPlayerId(playerId) {
  boardState.myPlayerId = playerId;
}