/**
 * TEG Web - Chat Module
 * Handles general chat, private whispers, and chat UI
 */

import { $, $$, $$$, createElement, showToast, escapeHtml, formatRelativeTime, EventEmitter, hideModal, showModal } from './utils.js?v=111';

// These will be set when initChat is called
let gameState, events, sendWS, elements, addLogEntry;

// ============================================================================
// Chat State
// ============================================================================

const chatState = {
  generalMessages: [],
  privateChats: new Map(), // playerId -> { messages: [], unread: number, otherPlayer: {} }
  activeTab: 'general',
  activePrivateChat: null,
  unreadGeneral: 0,
  unreadPrivateTotal: 0,
};

// ============================================================================
// DOM Elements (referenced from game.js)
// ============================================================================

const chatElements = {
  chatPanel: $('#chatPanel'),
  chatOverlay: $('#chatOverlay'),
  chatToggleBtn: $('#chatToggleBtn'),
  closeChatBtn: $('#closeChatBtn'),
  chatTabs: $$$('.chat-tab'),
  generalChatPanel: $('#generalChatPanel'),
  privateChatPanel: $('#privateChatPanel'),
  generalMessages: $('#generalMessages'),
  privateChatsList: $('#privateChatsList'),
  generalChatForm: $('#generalChatForm'),
  generalChatInput: $('#generalChatInput'),
  generalBadge: $('#generalBadge'),
  privateBadge: $('#privateBadge'),
};

// ============================================================================
// Initialization
// ============================================================================

export function initChat(gameStateRef, eventsRef, sendWSRef, elementsRef, addLogEntryRef) {
  // Store references
  gameState = gameStateRef;
  events = eventsRef;
  sendWS = sendWSRef;
  elements = elementsRef;
  addLogEntry = addLogEntryRef;
  
  // Setup tab switching
  if (chatElements.chatTabs && chatElements.chatTabs.length > 0) {
    chatElements.chatTabs.forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });
  }

  // Chat toggle: the toggle button is wired centrally via the 'toggle_chat'
  // event (see initChat's eventsRef.on below) — don't also bind it here
  // directly, or a single click would open+close in the same tick.
  if (chatElements.closeChatBtn) chatElements.closeChatBtn.addEventListener('click', closeChat);
  if (chatElements.chatOverlay) chatElements.chatOverlay.addEventListener('click', closeChat);

  // General chat form
  if (chatElements.generalChatForm) chatElements.generalChatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    sendGeneralMessage();
  });

  // Listen for chat events from game
  eventsRef.on('chat_message', handleIncomingChatMessage);
  eventsRef.on('toggle_chat', toggleChat);
}

function switchTab(tabName) {
  chatState.activeTab = tabName;

  // Update tabs
  chatElements.chatTabs.forEach(tab => {
    const isActive = tab.dataset.tab === tabName;
    tab.classList.toggle('active', isActive);
    tab.setAttribute('aria-selected', isActive);
  });

  // Update panels
  chatElements.generalChatPanel.classList.toggle('active', tabName === 'general');
  chatElements.privateChatPanel.classList.toggle('active', tabName === 'private');

  // Clear badge for active tab
  if (tabName === 'general') {
    chatState.unreadGeneral = 0;
    updateGeneralBadge();
  } else if (tabName === 'private') {
    if (chatState.activePrivateChat) {
      const chat = chatState.privateChats.get(chatState.activePrivateChat);
      if (chat) {
        chat.unread = 0;
        updatePrivateChatsList();
      }
    }
  }
}

function toggleChat() {
  const isHidden = chatElements.chatPanel.classList.contains('hidden');

  if (isHidden) {
    openChat();
  } else {
    closeChat();
  }
}

function openChat() {
  chatElements.chatPanel.classList.remove('hidden');
  chatElements.chatOverlay.classList.remove('hidden');

  // Focus input
  setTimeout(() => {
    chatElements.generalChatInput.focus();
  }, 100);
}

function closeChat() {
  chatElements.chatPanel.classList.add('hidden');
  chatElements.chatOverlay.classList.add('hidden');
}

// ============================================================================
// General Chat
// ============================================================================

function sendGeneralMessage() {
  const message = chatElements.generalChatInput.value.trim();
  if (!message) return;

  sendWS({
    event: 'send_chat',
    data: {
      channel: 'general',
      message,
    },
  });

  chatElements.generalChatInput.value = '';
}

function handleIncomingChatMessage(payload) {
  const { channel, sender_id, sender_name, message, timestamp, recipient_id } = payload;
  const isOwn = sender_id === gameState.playerId;

  if (channel === 'general') {
    addGeneralMessage(sender_id, sender_name, message, timestamp, isOwn);
  } else if (channel === 'private') {
    const otherPlayerId = isOwn ? recipient_id : sender_id;
    const otherPlayerName = isOwn ? payload.recipient_name : sender_name;
    addPrivateMessage(otherPlayerId, otherPlayerName, sender_id, sender_name, message, timestamp, isOwn);
  }
}

function addGeneralMessage(senderId, senderName, message, timestamp, isOwn) {
  const msg = {
    senderId,
    senderName,
    message,
    timestamp,
    isOwn,
  };
  chatState.generalMessages.push(msg);

  renderGeneralMessage(msg);

  // Update badge if not active
  if (chatState.activeTab !== 'general' || chatElements.chatPanel.classList.contains('hidden')) {
    chatState.unreadGeneral++;
    updateGeneralBadge();
  }

  // Scroll to bottom if near bottom
  autoScrollGeneral();
}

function renderGeneralMessage(msg) {
  const el = createElement('div', {
    class: `chat-message ${msg.isOwn ? 'own' : ''}`,
  });

  const time = new Date(msg.timestamp).toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
  });

  el.innerHTML = `
    <div class="chat-message-header">
      <span class="chat-sender ${msg.isOwn ? 'own' : 'other'}">${escapeHtml(msg.senderName)}${msg.isOwn ? ' (tú)' : ''}</span>
      <span class="chat-time">${time}</span>
    </div>
    <div class="chat-message-content">${escapeHtml(msg.message)}</div>
  `;

  chatElements.generalMessages.appendChild(el);
}

function autoScrollGeneral() {
  const container = chatElements.generalMessages;
  const isNearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
  if (isNearBottom) {
    container.scrollTop = container.scrollHeight;
  }
}

function updateGeneralBadge() {
  if (chatState.unreadGeneral > 0) {
    chatElements.generalBadge.textContent = chatState.unreadGeneral > 99 ? '99+' : chatState.unreadGeneral;
    chatElements.generalBadge.style.display = 'flex';
  } else {
    chatElements.generalBadge.style.display = 'none';
  }
  updateChatToggleBadge();
}

// ============================================================================
// Private Chat
// ============================================================================

export function openPrivateChat(playerId, playerName) {
  if (!chatState.privateChats.has(playerId)) {
    chatState.privateChats.set(playerId, {
      messages: [],
      unread: 0,
      otherPlayer: { id: playerId, name: playerName },
    });
  }

  chatState.activePrivateChat = playerId;
  chatState.privateChats.get(playerId).unread = 0;

  switchTab('private');
  openChat();
  renderPrivateChat(playerId);
  updatePrivateChatsList();
}

export function sendChatMessage(channel, message) {
  if (!message || !message.trim()) return;
  sendWS({
    event: 'send_chat',
    data: {
      channel: channel || 'general',
      message: message.trim(),
    },
  });
}

export function closePrivateChat(playerId) {
  if (chatState.activePrivateChat === playerId) {
    chatState.activePrivateChat = null;
    renderPrivateChatsList();
  }
}

function addPrivateMessage(otherPlayerId, otherPlayerName, senderId, senderName, message, timestamp, isOwn) {
  let chat = chatState.privateChats.get(otherPlayerId);
  if (!chat) {
    chat = {
      messages: [],
      unread: 0,
      otherPlayer: { id: otherPlayerId, name: otherPlayerName },
    };
    chatState.privateChats.set(otherPlayerId, chat);
  }

  const msg = {
    senderId,
    senderName,
    message,
    timestamp,
    isOwn,
  };
  chat.messages.push(msg);

  // Render if this is the active chat
  if (chatState.activePrivateChat === otherPlayerId) {
    renderPrivateMessage(msg);
    autoScrollPrivate();
  } else {
    chat.unread++;
    chatState.unreadPrivateTotal++;
    updatePrivateChatsList();
    updatePrivateBadge();
  }
}

function renderPrivateChatsList() {
  const container = chatElements.privateChatsList;

  if (chatState.privateChats.size === 0) {
    container.innerHTML = `
      <div class="empty-chats">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
          <circle cx="9" cy="7" r="4"/>
          <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
        </svg>
        <p>No hay conversaciones privadas</p>
        <p style="font-size: 0.85rem; margin-top: var(--spacing-xs);">Haz clic en un jugador para susurrar</p>
      </div>
    `;
    return;
  }

  container.innerHTML = '';

  chatState.privateChats.forEach((chat, playerId) => {
    const isActive = playerId === chatState.activePrivateChat;
    const lastMsg = chat.messages[chat.messages.length - 1];

    const item = createElement('div', {
      class: `private-chat-item ${isActive ? 'active-chat' : ''} ${chat.unread > 0 ? 'unread' : ''}`,
      onclick: () => openPrivateChat(playerId, chat.otherPlayer.name),
    });

    const avatarColor = getPlayerColorForId(playerId);
    const avatar = createElement('div', {
      class: 'private-chat-avatar',
      style: `background: ${avatarColor}`,
    }, chat.otherPlayer.name.charAt(0).toUpperCase());

    const info = createElement('div', { class: 'private-chat-info' });
    info.appendChild(createElement('div', { class: 'private-chat-name' }, escapeHtml(chat.otherPlayer.name)));

    if (lastMsg) {
      const preview = createElement('div', { class: 'private-chat-last-message' });
      preview.textContent = `${lastMsg.isOwn ? 'Tú: ' : ''}${escapeHtml(lastMsg.message)}`;
      info.appendChild(preview);
    }

    const meta = createElement('div', { class: 'flex gap-sm items-center' });
    if (lastMsg) {
      meta.appendChild(createElement('span', { class: 'private-chat-time' }, formatRelativeTime(lastMsg.timestamp)));
    }
    if (chat.unread > 0) {
      meta.appendChild(createElement('span', { class: 'private-chat-unread' }, chat.unread > 99 ? '99+' : chat.unread));
    }
    info.appendChild(meta);

    item.append(avatar, info);
    container.appendChild(item);
  });
}

function renderPrivateChat(playerId) {
  const chat = chatState.privateChats.get(playerId);
  if (!chat) return;

  const container = chatElements.privateChatsList;
  container.innerHTML = '';

  // Back button
  const backBtn = createElement('button', {
    class: 'btn btn-secondary btn-sm mb-md',
    style: 'width: 100%;',
    onclick: () => {
      chatState.activePrivateChat = null;
      renderPrivateChatsList();
    },
  }, '← Volver a conversaciones');
  container.appendChild(backBtn);

  // Messages
  const messagesContainer = createElement('div', { class: 'chat-messages', style: 'flex: 1; overflow-y: auto; padding: var(--spacing-md);' });
  chat.messages.forEach(msg => {
    const el = createPrivateMessageElement(msg);
    messagesContainer.appendChild(el);
  });
  container.appendChild(messagesContainer);

  // Input form
  const form = createElement('form', {
    class: 'chat-input-form',
    onsubmit: (e) => {
      e.preventDefault();
      sendPrivateMessage(playerId, input.value.trim());
      input.value = '';
    },
  });

  const input = createElement('input', {
    class: 'input-field chat-input',
    placeholder: `Susurrar a ${escapeHtml(chat.otherPlayer.name)}...`,
    maxlength: '500',
    autocomplete: 'off',
  });

  const sendBtn = createElement('button', {
    type: 'submit',
    class: 'btn btn-icon btn-primary',
    'aria-label': 'Enviar',
  });
  sendBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';

  form.append(input, sendBtn);
  container.appendChild(form);

  // Scroll to bottom
  setTimeout(() => {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }, 50);
}

function createPrivateMessageElement(msg) {
  const el = createElement('div', {
    class: `chat-message private ${msg.isOwn ? 'own' : ''}`,
  });

  const time = new Date(msg.timestamp).toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
  });

  el.innerHTML = `
    <div class="chat-message-header">
      <span class="chat-sender ${msg.isOwn ? 'own' : 'other'}">${msg.isOwn ? 'Tú' : escapeHtml(msg.senderName)}</span>
      <span class="chat-time">${time}</span>
    </div>
    <div class="chat-message-content">${escapeHtml(msg.message)}</div>
  `;

  return el;
}

function renderPrivateMessage(msg) {
  const container = chatElements.privateChatsList.querySelector('.chat-messages');
  if (!container) return;

  const el = createPrivateMessageElement(msg);
  container.appendChild(el);
}

function autoScrollPrivate() {
  const container = chatElements.privateChatsList.querySelector('.chat-messages');
  if (container) {
    container.scrollTop = container.scrollHeight;
  }
}

function sendPrivateMessage(recipientId, message) {
  if (!message) return;

  const chat = chatState.privateChats.get(recipientId);
  if (!chat) return;

  sendWS({
    event: 'send_chat',
    data: {
      channel: 'private',
      message,
      recipient_id: recipientId,
    },
  });
}

function updatePrivateChatsList() {
  // Items are built via addEventListener (not inline onclick attributes),
  // so querying by [onclick*="..."] never matches anything — just redraw
  // the conversations list. Skip the redraw while a specific chat thread
  // is open, so we don't yank the user back to the list mid-conversation.
  if (chatState.activePrivateChat === null) {
    renderPrivateChatsList();
  }
}

function updatePrivateBadge() {
  if (chatState.unreadPrivateTotal > 0) {
    chatElements.privateBadge.textContent = chatState.unreadPrivateTotal > 99 ? '99+' : chatState.unreadPrivateTotal;
    chatElements.privateBadge.style.display = 'flex';
  } else {
    chatElements.privateBadge.style.display = 'none';
  }
  updateChatToggleBadge();
}

function updateChatToggleBadge() {
  const totalUnread = chatState.unreadGeneral + chatState.unreadPrivateTotal;
  if (totalUnread > 0) {
    chatElements.chatToggleBtn.querySelector('.chat-badge').textContent = totalUnread > 99 ? '99+' : totalUnread;
    chatElements.chatToggleBtn.querySelector('.chat-badge').style.display = 'flex';
  } else {
    chatElements.chatToggleBtn.querySelector('.chat-badge').style.display = 'none';
  }
}

function getPlayerColorForId(playerId) {
  const colors = [
    '#e74c3c', '#3498db', '#2ecc71', '#f1c40f', '#e67e22', '#9b59b6'
  ];
  const idStr = String(playerId);
  let hash = 0;
  for (let i = 0; i < idStr.length; i++) {
    hash = ((hash << 5) - hash) + idStr.charCodeAt(i);
    hash |= 0;
  }
  return colors[Math.abs(hash) % colors.length];
}